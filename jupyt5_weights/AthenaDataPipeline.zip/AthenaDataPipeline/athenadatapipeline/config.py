import logging
import yaml

LOGGER = logging.getLogger(__name__)

def load_conf(conf_path):
    """
    Loads conf.yaml file

    Parameters
    ----------
    conf_path : str

    Returns
    -------
    conf : dict
    """
    try:
        with open(conf_path, 'r') as fin:
            return yaml.load(fin, Loader=yaml.FullLoader)
    except (FileNotFoundError, yaml.YAMLError) as err:
        LOGGER.critical(f'Could not load log file {conf_path}, raised {err}')
