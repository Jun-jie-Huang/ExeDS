from itertools import product
from pathlib import Path
import tokenizers
import logging

from athenadatapipeline import load_zip_json

LOGGER = logging.getLogger(__name__)

def prepare(json_lz4_filename, Collater, toke_prefix, subdir="fairseq", head=None):
    """
    Tokenizes the sources and targets and creates new files to place tokenized data
    Parameters
    ----------
    json_lz4_filename : string
        filepath containing the datafile that holds file_dict for each file .json.lz4
    Collater : class object
        Collater, or any language specific subclass of Collater
    toke_prefix :
        the prefix of the files that will be arguments to the tokenizer
    subdir : default = "fairseq"
        the file tokenized data will be saved in
    head : integer
        to perform prepare on the first head files
    """
    tokenizer = tokenizers.ByteLevelBPETokenizer(
        toke_prefix + "-vocab.json", toke_prefix + "-merges.txt"
    )

    json_lz4_filename = Path(json_lz4_filename)
    old_directory, name = json_lz4_filename.parent, json_lz4_filename.name
    old_directory /= "split/" + Collater.task_label
    new_directory, name = json_lz4_filename.parent, json_lz4_filename.name
    new_directory /= subdir + "/" + Collater.task_label

    if not new_directory.exists():
        new_directory.mkdir(parents=True)
    name = name[: name.find(json_lz4_filename.suffixes[0])]

    subsets = ["train", "val", "test"]
    for sub, dataset in product(subsets, Collater.dataset_labels):
        fname_prefix = f"{name}.{sub}.{dataset}"
        fname = fname_prefix + ".json.gz"
        new_file_home = str(new_directory) + "/" + fname_prefix
        LOGGER.info(f"opening {new_file_home}")
        with open(new_file_home, "w") as f_p:
            lines = list(load_zip_json(old_directory / fname, head=head))
            for tok_sent in tokenizer.encode_batch(lines):
                f_p.write(" ".join(tok_sent.tokens) + "\n")
