"""
Usage: 
    contains serializer functions for javascript
"""
from pathlib import Path
import logging
from tqdm import tqdm
from source_parser import load_zip_json

LOGGER = logging.getLogger(__name__)

DATA_DIR = Path('/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context')
JSON_GZ = DATA_DIR / 'javascript-context-2020-07-22-0605.json.lz4'

def serialize_docstring_and_sig(method_dict):
    if not method_dict["docstring"]:
        return method_dict["signature"]
    docstring = format_cstyle_docstring(method_dict["docstring"])
    signature = method_dict["signature"]
    doc_sig = docstring + "\n" + signature
    return doc_sig


def serialize_body(method_dict):
    return method_dict["body"]


def serialize_docstring(method_dict):
    # empty docstring
    if not method_dict["docstring"]:
        return method_dict["docstring"]
    docstring = format_cstyle_docstring(method_dict["docstring"])
    return docstring


def serialize_signature(method_dict):
    return method_dict["signature"]


def serialize_sig_and_body(method_dict):
    sig = method_dict["signature"]
    body = method_dict["body"]
    return sig + " " + body


def serialize_docstring_and_body(method_dict):
    if not method_dict["docstring"]:
        return method_dict["body"]
    docstring = format_cstyle_docstring(method_dict["docstring"])
    body = method_dict["body"]
    docstring_body = docstring + "\n" + body
    return docstring_body


def format_cstyle_docstring(docstring):
    """
    Puts docstring into desired style
    Parameters
    ----------
    docstring : string
        representing a docstring of a JavaScript method
    Returns
    -------
    docstring : string
        /**
         * line1
         * line2
         */
    """
    docstring_lines = docstring.split("\n")
    docstring_lines = [line.strip() for line in docstring_lines]
    length = len(docstring_lines)
    for i, line in enumerate(docstring_lines):
        if line.endswith(":") and i < length - 1 and docstring_lines[i + 1]:
            docstring_lines[i + 1] = "\t" + docstring_lines[i + 1]
        if line.startswith("@") and i < length - 1:
            if not docstring_lines[i + 1].startswith("@") and docstring_lines[i + 1]:
                docstring_lines[i + 1] = "\t" + docstring_lines[i + 1]
    docstring_lines[1:-1] = [
        " * " + line if line else " *" + line for line in docstring_lines[1:-1]
    ]
    docstring_lines[0] = "/**" + docstring_lines[0]
    docstring_lines[-1] += " */"
    docstring = "\n".join(docstring_lines)
    return docstring

FOLD_MAP={
        'sig': serialize_signature,
        'docstring': serialize_docstring,
        'body': serialize_body,
        'sig_and_docstring': serialize_docstring_and_sig,
        'sig_and_body': serialize_sig_and_body,
        'docstring_and_body': serialize_docstring_and_body
}

def serialize_dat(dat):
    return {label: FOLD_MAP[label](dat) for label in FOLD_MAP}