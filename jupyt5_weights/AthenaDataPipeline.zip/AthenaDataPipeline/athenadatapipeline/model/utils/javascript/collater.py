"""
collater.py

Usage : JavaScript specific collaters, used to prepare data to train model with different tasks
"""
from athenadatapipeline.collater import Collater
from athenadatapipeline.model.utils.javascript import serialize_body, serialize_signature, serialize_docstring_and_sig, serialize_sig_and_body, serialize_docstring

class JavaScriptSignatureBody(Collater):
    """
    Class that inherits from Collater class in athenadatapipeline/collater.py
    Used to serialize and format file_specific data into a dictionary
    model task : method generation when given docstring (optional), signature and body
    """
    dataset_labels = ('signature', 'body')
    task_label = "sig_body_method_generation"

    @property
    def datasets(self):
        return self.dataset_labels

    @property
    def get_task_label(self):
        return self.task_label

    def collate(self, file_dict):
        """
        Parameters
        ----------
        file_dict : Dict[str, Union[str, List, Dict]]
            schema format used in source_parser

        Returns
        -------
        one_source_target_dict : Dict[str, List[str]]
        """
        one_source_target_dict = {}
        serialized_source_list = []
        serialized_target_list = []
        for method_dict in file_dict["methods"]:
            serialized_source = serialize_docstring_and_sig(method_dict)
            serialized_target = serialize_body(method_dict)
            serialized_source_list.append(serialized_source)
            serialized_target_list.append(serialized_target)
        for class_dict in file_dict["classes"]:
            for method_dict in class_dict["methods"]:
                serialized_source = serialize_docstring_and_sig(method_dict)
                serialized_target = serialize_body(method_dict)
                serialized_source_list.append(serialized_source)
                serialized_target_list.append(serialized_target)

        one_source_target_dict[self.dataset_labels[0]] = serialized_source_list
        one_source_target_dict[self.dataset_labels[1]] = serialized_target_list
        return one_source_target_dict

class JavaScriptMethodDocstring(Collater):
    """
    Class that inherits from Collater class in athenadatapipeline/collater.py
    Used to serialize and format file_specific data into a dictionary
    model task : docstring generation when given signature and body
    """
    dataset_labels = ('method', 'docstring')
    task_label = "method_docstring_generation"

    @property
    def datasets(self):
        return self.dataset_labels

    @property
    def get_task_label(self):
        return self.task_label

    def collate(self, file_dict):
        """
        Parameters
        ----------
        file_dict : Dict[str, Union[str, List, Dict]]
            schema format used in source_parser

        Returns
        -------
        one_source_target_dict : Dict[str, List[str]]
        """
        one_source_target_dict = {}
        serialized_source_list = []
        serialized_target_list = []
        for method_dict in file_dict["methods"]:
            if serialize_docstring(method_dict):
                serialized_source = serialize_sig_and_body(method_dict)
                serialized_target = serialize_docstring(method_dict)
                serialized_source_list.append(serialized_source)
                serialized_target_list.append(serialized_target)
        for class_dict in file_dict["classes"]:
            for method_dict in class_dict["methods"]:
                if serialize_docstring(method_dict):
                    serialized_source = serialize_sig_and_body(method_dict)
                    serialized_target = serialize_docstring(method_dict)
                    serialized_source_list.append(serialized_source)
                    serialized_target_list.append(serialized_target)

        one_source_target_dict[self.dataset_labels[0]] = serialized_source_list
        one_source_target_dict[self.dataset_labels[1]] = serialized_target_list
        return one_source_target_dict

class JavaScriptSignatureBodyandMethodDocstring(Collater):
    """
    Class that inherits from Collater class in athenadatapipeline/collater.py
    Used to serialize and format file_specific data into a dictionary
    multi task model
        task one : method generation when given docstring (optional), signature and body
        task two : docstring generation when given signature and body
    """
    #dataset_labels = ('signature', 'body', 'method', 'docstring')
    dataset_labels = ('source', 'target')
    task_label = "sig_body_method_and_method_docstring_generation"

    @property
    def datasets(self):
        return self.dataset_labels

    @property
    def get_task_label(self):
        return self.task_label

    def collate(self, file_dict):
        """
        Parameters
        ----------
        file_dict : Dict[str, Union[str, List, Dict]]
            schema format used in source_parser

        Returns
        -------
        one_source_target_dict : Dict[str, List[str]]
        """
        one_source_target_dict = {}
        serialized_source_list = []
        serialized_target_list = []
        for method_dict in file_dict["methods"]:
            serialized_source_one = "//target body\n" + serialize_docstring_and_sig(method_dict)
            serialized_target_one = serialize_body(method_dict)
            if serialize_docstring(method_dict):
                serialized_source_two = "//target docstring\n" + serialize_sig_and_body(method_dict)
                serialized_target_two = serialize_docstring(method_dict)
                serialized_source_list.append(serialized_source_two)
                serialized_target_list.append(serialized_target_two)
            serialized_source_list.append(serialized_source_one)
            serialized_target_list.append(serialized_target_one)
        for class_dict in file_dict["classes"]:
            for method_dict in class_dict["methods"]:
                serialized_source_one = "//target body\n" + serialize_docstring_and_sig(method_dict)
                serialized_target_one = serialize_body(method_dict)
                if serialize_docstring(method_dict):
                    serialized_source_two = "//target docstring\n" + serialize_sig_and_body(method_dict)
                    serialized_target_two = serialize_docstring(method_dict)
                    serialized_source_list.append(serialized_source_two)
                    serialized_target_list.append(serialized_target_two)
                serialized_source_list.append(serialized_source_one)
                serialized_target_list.append(serialized_target_one)

        one_source_target_dict[self.dataset_labels[0]] = serialized_source_list
        one_source_target_dict[self.dataset_labels[1]] = serialized_target_list
        return one_source_target_dict
        
