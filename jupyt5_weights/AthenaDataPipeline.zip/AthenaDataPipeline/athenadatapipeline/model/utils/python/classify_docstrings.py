"""
classify_docstrings.py

author: Colin Clement
date: 2020-04-14

This module classifies python docstrings into common styles.
Use classify_docstrings.get_class to classify docstring,
or classify_docstrings.multi_classify to get all possible classed
satisfied (for debugging the class identification).
"""

import re

#TODO: test new template detectors


def detect_numpydoc(docstring):
    """
    Return True if numpydoc detected (this docstring is numpydoc style!)

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_numpydoc : True/False
    """
    allowed_sections = {
        "Parameters",
        "Attributes",
        "Methods",
        "Returns",
        "Yields",
        "Other Parameters",
        "Raises",
        "Warns",
        "See Also",
        "Notes",
        "References",
        "Examples",
    }
    lines = docstring.splitlines()
    for i, line in enumerate(lines):
        if line.strip() in allowed_sections:
            if i + 1 < len(lines) and set(lines[i + 1].strip()) == set("-"):
                return True
            # relaxation of numpydoc but a common user pattern
            if i + 1 < len(lines) and set(lines[i + 1].strip()) == set("="):
                return True
    return False


RE_REST_PARAM = re.compile(
    r"^(:(?:param|type|raises) [\S]+[ \S]*:)[\S ]*$", flags=re.M | re.I
)
RE_REST_RETURN = re.compile(r"^(:(?:return|returns|rtype):)[\S ]*$", flags=re.M | re.I)


def detect_rest(docstring):
    """
    Return True if restructuredtext style is detected

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_reST : True/False
    """
    return bool(RE_REST_PARAM.search(docstring)) or bool(
        RE_REST_RETURN.search(docstring)
    )


def detect_rest_template(docstring, cutoff=0.3):
    """
    Test whether docstring is an empty restructuredtext style template
    containing mostly just headers and argument statements but without
    summaries or argument annotation

    Parameters
    ----------
    docstring : str
        input docstring to be tested
    cutoff : float
        fraction of remaining characters after removing
        the headers and argument tags, below which
        defines whether a docstring is a template
    """
    template_removed = RE_REST_PARAM.sub('', docstring)
    template_removed = RE_REST_RETURN.sub('', docstring)
    if len(template_removed) / max(len(docstring), 1) < cutoff:
        return True
    return False


RE_JAVADOC_PARAM = re.compile(r"^(@(?:param|raises) [\S]+:)[\S ]*$", flags=re.M | re.I)
RE_JAVADOC_RETURN = re.compile(
    r"^(@(?:return|returns|rtype):)[\S ]*$", flags=re.M | re.I
)


def detect_javadoc(docstring):
    """
    Return True if javadoc style is detected

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_javadoc : True/False
    """
    return bool(RE_JAVADOC_PARAM.search(docstring)) or bool(
        RE_JAVADOC_RETURN.search(docstring)
    )


def detect_javadoc_template(docstring, cutoff=0.3):
    """
    Test whether docstring is an empty javadoc style template containing mostly
    just headers and argument statements but without summaries or argument
    annotation

    Parameters
    ----------
    docstring : str
        input docstring to be tested
    cutoff : float
        fraction of remaining characters after removing
        the headers and argument tags, below which
        defines whether a docstring is a template
    """
    template_removed = RE_JAVADOC_PARAM.sub('', docstring)
    template_removed = RE_JAVADOC_RETURN.sub('', docstring)
    if len(template_removed) / max(len(docstring), 1) < cutoff:
        return True
    return False


RE_GOOGLE_PARAM = re.compile(r"^\s+(?:[A-Za-z0-9]+):", flags=re.M)
RE_GOOGLE_SECTION = re.compile(r"^(?:Args|Returns|Yields|Raises):$", flags=re.M)


def detect_google(docstring):
    """
    Return True if google style is detected

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_google : True/False
    """
    return bool(RE_GOOGLE_SECTION.search(docstring))


def detect_google_template(docstring, cutoff=0.3):
    """
    Test whether docstring is an empty google style template containing mostly
    just headers and argument statements but without summaries or argument
    annotation

    Parameters
    ----------
    docstring : str
        input docstring to be tested
    cutoff : float
        fraction of remaining characters after removing
        the headers and argument tags, below which
        defines whether a docstring is a template
    """
    template_removed = RE_GOOGLE_PARAM.sub('', docstring)
    if len(template_removed) / max(len(docstring), 1) < cutoff:
        return True
    return False


def detect_oneline(docstring):
    """
    Return True if oneline style is detected. Ignores empty lines.

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_oneline : True/False
    """
    return bool(len(list(filter(lambda x: x, docstring.splitlines()))) == 1)


def detect_oneparagraph(docstring):
    """
    Return True if one-paragraph style is detected.
    Ignores leading and terminating empty lines.

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    is_one_paragraph : True/False
    """
    lines = docstring.strip().splitlines()
    if len(lines) > 1:
        return all(docstring.splitlines())
    return False


DOCSTRING_TYPES = {  # order matters!
    "oneline": detect_oneline,
    "numpydoc": detect_numpydoc,
    "google": detect_google,
    "restructuredtext": detect_rest,
    "javadoc": detect_javadoc,
    "oneparagraph": detect_oneparagraph,
}  # 'other' implied as last


def multi_classify(docstring):
    """
    Return all classes which this docstring satisfies,
    of if none satisfied then return only ('other').
    Useful for debugging class definitions, the first class
    in the tuple is 'the class' used

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    labels : tuple(str)
        tuple of class labels which were positively identified
    """
    labels = []
    docstring = docstring.strip()
    for label, detector in DOCSTRING_TYPES.items():
        if detector(docstring):
            labels.append(label)
    if len(labels) == 0:
        labels.append("other")
    return tuple(labels)


def get_class(docstring):
    """
    Get the style class of the docstring, which can be
    one of the keys of DOCSTRING_TYPES or 'other'

    Parameters
    ----------
    docstring : str
        string containing method docstring

    Returns
    -------
    class_label : str
        class label
    """
    label = "other"
    docstring = docstring.strip()
    for lab, detector in DOCSTRING_TYPES.items():
        if detector(docstring):
            label = lab
            break
    return label


DEFAULT_FALSE = lambda s, c: False
DOCSTRING_TEMPLATE_TESTS = {
        "oneline": DEFAULT_FALSE,
        "numpydoc": DEFAULT_FALSE,  # most numpydocs are not templates
        "google": detect_google_template,
        "restructuredtext": detect_rest_template,
        "javadoc": detect_javadoc_template,
        "oneparagraph": DEFAULT_FALSE,
        "other": DEFAULT_FALSE,
}


def is_template(docstring, style=None, cutoff=0.3):
    """
    Test whether docstring is an empty template containing
    mostly just headers and argument statements but without
    summaries or argument annotation

    Parameters
    ----------
    docstring : str
        input docstring to be tested
    (optional)
    style : str
        one of the prescribed styles, options are
        the keys of `DOCSTRING_TEMPLATE_TESTS`
    cutoff : float
        fraction of remaining characters after removing
        the headers and argument tags, below which
        defines whether a docstring is a template
    """
    if style is None:
        style = get_class(docstring)
    return DOCSTRING_TEMPLATE_TESTS[style](docstring, cutoff)
