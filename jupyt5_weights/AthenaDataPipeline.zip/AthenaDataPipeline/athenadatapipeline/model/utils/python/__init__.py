import logging
from collections import defaultdict, OrderedDict
from tqdm import tqdm
from tokenizers import ByteLevelBPETokenizer
from doctest import DocTestParser

from contextlib import ExitStack
from textwrap import dedent, indent

from athenadatapipeline import load_zip_json
from athenadatapipeline.model.utils.python.classify_docstrings import get_class
from athenadatapipeline.model.utils.python.normalization import normalize, NORMALIZE_LABEL

LOGGER = logging.getLogger(__name__)

CRAWLDIRS = [
        '/smartml-athena/src-data/python/ziBjatNZRky2slnfFbZg2A/Git/1.0/',
        '/smartml-athena/all-git-repos',
        '/bigdata/git-repos/python',
    ]

def remove_examples(docstring):
    """
    Remove examples in docstrings
    """
    p = DocTestParser()
    not_tests = []
    try:
        for example in p.parse(docstring):
            if isinstance(example, str):
                not_tests.append(example)
        return ''.join(not_tests)
    except ValueError:
        return docstring

NORMALIZE_LABEL.pop('user_handle', None)  # conflicts with javadoc style

def clean_docstring(docstring):
    """
    Remove doctests, normalize common patterns, fix unicode
    """
    docstring = remove_examples(docstring)
    cleaned = normalize(fix_text(docstring), norm_label=NORMALIZE_LABEL)
    if len(cleaned) < 0.2 * len(docstring):
        return ''
    return cleaned

def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == "\n":
        return f'"""\n{docstring}\n"""'
    else:
        return f'"""{docstring}"""'

def serialize_sig(dat):
    return dat[0]

def serialize_sig_schema(method_dict):
    return method_dict['signature']

def serialize_docstring(dat):
    if not dat[1]:  # empty docstring
        return dat[1]
    cleaned = clean_docstring(dat[1])
    if cleaned:
        return indent(code_format_docstring(cleaned), " " * 4)
    return cleaned  # emptied by cleaning

def format_docstring(docstring, n_indents=4, clean=False):
    if not docstring.strip(): # empty docstring
        return docstring
    if clean:
        docstring = clean_docstring(docstring)
    if docstring:
        return indent(code_format_docstring(docstring), " " * n_indents)
    return docstring # emptied by cleaning

def serialize_body(dat):
    return indent(dat[2], " " * 4)

def serialize_sig_and_body(dat):
    return "\n".join([dat[0], indent(dat[2], " " * 4),])


def serialize_sig_and_docstring(dat):
    docstring = serialize_docstring(dat)
    if not docstring:
        return dat[0]
    return "\n".join([dat[0], serialize_docstring(dat)])


def serialize_docstring_and_body(dat):
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    if not docstring:
        return body
    return "\n".join([serialize_docstring(dat), body])


FOLD_MAP = {
    "sig": serialize_sig,
    "docstring": serialize_docstring,
    "body": serialize_body,
    "sig_and_docstring": serialize_sig_and_docstring,
    "sig_and_body": serialize_sig_and_body,
    "docstring_and_body": serialize_docstring_and_body,
}


def serialization_mapping(dat):
    '''
    A dictionary mapping of various data folds (modalities), including, signature, docstring, body to
    corresponding serializer functions.
    '''
    return OrderedDict({label: FOLD_MAP[label](dat) for label in FOLD_MAP})


def decompress_name(filepath):
    nameparts = filepath.name.split(".")
    return ".".join([n for n in nameparts if not n in ["json", "gz"]])


def prepare(
    datafiles, vocab, merges, tasks, valid_name_map, subdir="fairseq", batch_size=10000
):
    tokenizer = ByteLevelBPETokenizer(str(vocab), str(merges))

    for df in tqdm(datafiles, desc="Subset", position=1):
        LOGGER.info(f"Processing {df.name}")
        directory = df.parent / subdir
        if not directory.exists():
            directory.mkdir(parents=True)
        prefix = df.name.split(".")[0]

        with ExitStack() as stack:  # with open block for lists of files
            savestreams = dict()
            subset = df.name.split(".")[1]
            if subset == "train":
                # NOTE: all features in one training set
                for lab in ("src", "tgt"):
                    name = f"{prefix}.{subset}.{lab}"
                    savestreams[subset + lab] = stack.enter_context(
                        open(directory / name, "w")
                    )
                    LOGGER.info(f"Opened {name} for writing")
            else:
                # NOTE: separate src, tgt test/valid files for each 'feature'
                for abbrev in valid_name_map.values():
                    for lab in ("src", "tgt"):
                        subset_label = subset + "_" + abbrev
                        name = f"{prefix}.{subset_label}.{lab}"
                        savestreams[subset + abbrev + lab] = stack.enter_context(
                            open(directory / name, "w")
                        )
                        LOGGER.info(f"Opened {name} for writing")

            savedict = defaultdict(list)  # save strings for batch tokenization
            for i, dat in enumerate(tqdm(load_zip_json(df), desc="Examples")):
                for (src_label, tgt_label), abbrev in valid_name_map.items():
                    src = dat[src_label]
                    tgt = dat[tgt_label]

                    # docstring skip task examples with missing docstrings
                    if "docstring" in src_label + tgt_label:
                        if not dat["docstring"]:
                            continue

                    tgt_imperative = f"# target {tgt_label} "
                    if "docstring" in tgt_label:
                        docstring = dedent(dat["docstring"]).replace('"""', "").strip()
                        style = get_class(docstring)
                        tgt_imperative += f"style {style}"

                    src = tgt_imperative + "\n" + src

                    for d, lab in zip([src, tgt], ["src", "tgt"]):
                        # NOTE: DAWN'S TOKENIZER REQUIRES THIS
                        d = d.replace("\n", "NEWLINE")
                        key = subset + abbrev + lab
                        if subset == "train":  # all features in one training set
                            key = subset + lab
                        savedict[key].append(d)

                # write results to disk periodically
                if i and i % batch_size == 0:
                    for key in savedict:
                        # parallel tokenization
                        for tok in tokenizer.encode_batch(savedict[key]):
                            savestreams[key].write(" ".join(tok.tokens) + "\n")
                    savedict = defaultdict(list)
