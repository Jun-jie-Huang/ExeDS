"""
normalization.py

author: Colin Clement
date: 2019-11-05

This module contains methods for detecting and normalizing features of pull request comments
in the CrawlData dataset.

Common patterns are searched for and replaced by special tokens, including:
    * unicode characters
    * 40 hex characters representing commit hashes  -- <commit_hash>
    * URLs                                          -- <url>
    * @<username>                                   -- <user_handle>
    * emails                                        -- <email_address>
    * Windows/Unix **absolute** file paths          -- <file_path>
"""

import re

COMMIT_HASH_RE = r"[a-f0-9]{40}"
VSTS_GUID_RE = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
USER_HANDLE_RE = r"(?<=@)[A-Za-z0-9_\-]+"  # works for GitHub user handles

# from https://emailregex.com, relaxed by removing the '^' from the beginning and
# '$' from the end, added optional link 'mailto:' prepend
EMAIL_RE = r"(mailto:)?[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"

# from urlregex.com, modified to not capture trailing ')' from markdown or parentheticals
URL_RE = r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+\#]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+(?<!\))"

# WINDOWS_PATH_RE = r"\b(?:[a-zA-Z]:)?\\(\.\./|[a-zA-Z0-9_/\-\\])*\.[a-zA-Z0-9]+\b"
WINDOWS_PATH_RE = r"[a-zA-Z]:\\[\\\S|*\S]?.*"
# Exclude git reference 'paths', i.e. 'refs/heads/...'
UNIX_PATH_RE = r"(?<!\w)\/([A-z0-9-_+]+\/)*[A-z0-9]+(\.[a-zA-Z0-9]+)+"
PATH_RE = "{}|{}".format(WINDOWS_PATH_RE, UNIX_PATH_RE)

# Matches anything not ASCII or general punctuation (for emdashes, etc)
NON_ASCII_PUNC_RE = r"([^\u0000-\u007f\u2000-\u206f]+)"
CODEBLOCK_RE = (
    r"(```[\w]*\n[\s\S]*\n```)"  # matches ```js\n multi-line block \n code ```
)
INLINE_CODE_RE = r"(`.*`)"  # matches "`inline code`"
MD_TABLE_RE = (
    r"(\|(?:.*\|)*(?:.*)\|\n?)"  # matches MD tables like "| col1 | col2 | col3 |"
)
REMOVE_RE = "|".join([NON_ASCII_PUNC_RE, CODEBLOCK_RE, INLINE_CODE_RE, MD_TABLE_RE,])

NORMALIZE_LABEL = {
    "commit_hash": re.compile(COMMIT_HASH_RE),
    "guid": re.compile(VSTS_GUID_RE),
    "email_address": re.compile(
        EMAIL_RE
    ),  # NOTE: Important that email precedes url and user_handle
    "url": re.compile(URL_RE),  # NOTE: Important that url precedes file_path
    "file_path": re.compile(PATH_RE),
    "user_handle": re.compile(USER_HANDLE_RE),
    "": re.compile(REMOVE_RE),  # replace with nothing!
}


def _normalize_mapping(token_label):
    """ Wrap non-empty token_label string with angle brackets """
    if token_label:
        return "<{}>".format(token_label)
    return token_label


def normalize(string, norm_label=None):
    """
    Apply the normalizations defined by replaing matches from regex methods in norm_label
    with special token mappings in norm_mapping

    Parameters
    ----------
        string : str
        norm_label (optional) : dict[special_type] = compiled_regex_match
            defaults to NORMALIZE_LABEL

    Returns
    -------
        normed_string : str

    Examples
    --------

    >>> normalize('Great job, @sample_userhandle!')
    'Great job, @<user_handle>!'

    >>> normalize('Check out commit 72a5fd6dd19f36cecd0ab663302f31b94936ebb7 in blah')
    'Check out commit <commit_hash> in blah'

    >>> normalize('The author @coclemen can be reached at coclemen@microsoft.com and they are cool')
    'The author @<user_handle> can be reached at <email_address> and they are cool'

    >>> normalize('The repo url is https://github.com/username/reponame')
    'The repo url is <url>'

    >>> normalize(r"Check out this windows file C:\\home\\user\\downloads\\stuff.txt")
    'Check out this windows file <file_path>'

    >>> normalize('and here is a unix file path /home/user/username/file.csv')
    'and here is a unix file path <file_path>'

    >>> normalize('hey @d00d check out this file stuff.txt, email me at mailto:me@website.com')
    'hey @<user_handle> check out this file stuff.txt, email me at <email_address>'

    >>> normalize('Here is a reference and not a path refs/heads/test.yes')
    'Here is a reference and not a path refs/heads/test.yes'
    """
    if norm_label is None:
        norm_label = NORMALIZE_LABEL
    for label, re_match in norm_label.items():
        string = re_match.sub(_normalize_mapping(label), string)
    return string
