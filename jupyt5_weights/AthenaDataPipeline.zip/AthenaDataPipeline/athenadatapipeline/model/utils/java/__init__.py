import logging
from collections import defaultdict, OrderedDict
from tqdm import tqdm
from tokenizers import ByteLevelBPETokenizer
from doctest import DocTestParser

from contextlib import ExitStack
from textwrap import dedent, indent

from athenadatapipeline import load_zip_json
from athenadatapipeline.model.utils.java.normalization import normalize, NORMALIZE_LABEL

LOGGER = logging.getLogger(__name__)

NORMALIZE_LABEL.pop('user_handle', None)  # conflicts with javadoc style

def clean_docstring(docstring):
    """
    Remove doctests, normalize common patterns, fix unicode
    """
    cleaned = normalize(fix_text(docstring), norm_label=NORMALIZE_LABEL)
    if len(cleaned) < 0.2 * len(docstring):
        return ''
    return cleaned

def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == "\n":
        reduced_docstring = docstring.strip()
        formatted_docstring = "/**\n"
        for line in reduced_docstring.splitlines():
            formatted_docstring += "* " + line.strip() +"\n"
        formatted_docstring += "*/"
        return formatted_docstring
    else:
        return "// " + docstring.strip()

def format_docstring(docstring, n_indents=0, clean=False):
    if not docstring.strip(): # empty docstring
        return docstring
    if clean:
        docstring = clean_docstring(docstring)
    if docstring:
        return indent(code_format_docstring(docstring), " " * n_indents)
    return docstring # emptied by cleaning
