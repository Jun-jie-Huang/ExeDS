"""
model_init.py

author: Colin Clement
date: 2020-04-07

Container classes for initializing and pre-/post-processing
text for interactively using fairseq/huggingface transformer models
"""

from pathlib import Path
import torch
from textwrap import indent, dedent

from tokenizers import ByteLevelBPETokenizer
from fairseq.models.transformer import TransformerModel

from collections import namedtuple

Args = namedtuple('Args',
        [
            'model_name_or_path',
	    'data_name_or_path',
            'tokenizer_prefix',
            'checkpoint_file',
            'pre_replace'
        ]
)

def code_format_docstring(docstring):
    """Format docstring into indented, triple-quote delimited string"""
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == '\n':
        return indent(f'"""\n{docstring}\n"""', ' ' * 4)
    return indent(f'"""{docstring}"""', ' ' * 4)

def generate_method(example, model, **kwargs):
    """
    Generate method body from signature and docstring using
    a translation model. If signature is empty, only the docstring
    is used to predict the method body and docstring. If docstring
    is empty, only signature is used to predict method body. If both
    are empty, an empty string is returned and no inference occurs.
    NOTE: If a non-empty body is provided, the model will attempt
    to complete the body with that as a prompt!

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    beam : int, optional
    temperature : float, optional

    Returns
    -------
    method_body : str
        predicted body string, indented by four spaces,
        and predicted signature if the signature is not provided
    """
    if example[0]:
        parts = ['# target body', example[0]]
    elif example[1]:  # predict signature too if missing
        parts = ['# target sig_and_body']
    else:
        return ''  # missing essential information
    if example[1]:
        parts.append(code_format_docstring(example[1]))

    inference_step_args = {}
    # partial body complete if signature and non-trivial body present
    if example[0] and example[2]:
        body = indent(example[2], ' ' * 4)
        # Fairseq model encode appends EOS token by default!
        # unsqueeze necessary as fairseq does the same to the prompt
        prefix_tokens = model.model.encode(model.encode(body))[:-1].unsqueeze(0)
        if torch.cuda.is_available():
            prefix_tokens = prefix_tokens.cuda()
        inference_step_args['prefix_tokens'] = prefix_tokens
        kwargs['inference_step_args'] = inference_step_args

    return model.translate('\n'.join(parts), **kwargs)


DOCSTRING_STYLES = {
        'oneline',
        'numpydoc',
        'google',
        'restructuredtext',
        'javadoc',
        'oneparagraph',
        'other'
}


def generate_docstring(example, model, style='numpydoc'):
    """
    Generate method docstring from signature and docstring using
    a translation model. Can provide signature, signature and method,
    or method. If element is missing, expects an empty string.

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    style : str, optional
        must be element of DOCSTRING_STYLES, default 'numpydoc'

    Returns
    -------
    docstring : str
        predicted docstring, indented by four spaces and triple quote
        delimited
    """
    assert style in DOCSTRING_STYLES
    parts = [f'# target docstring style {style}']
    if not example[0] and not example[2]:
        return ''
    if example[0]:
        parts.append(example[0])
    if example[2]:
        parts.append(dedent(indent(example[2], ' ' * 4)))
    return model.translate('\n'.join(parts), beam=7, temperature=1.)


class ModelInterface:
    """
    Contains the skeleton of pre- and post-processing
    for method-docstring translation
    """

    post_replace = {
        "Ġ": " ",
        "Ċ": "\n",
        "ĉ": "\t",
        "NEWLINE": "\n",
        "<user_handle>": "param",
    }
    pre_replace = dict([])

    def encode(self, method_text):
        """pre-process and tokenize to prepare for model"""

    def decode(self, hypothesis):
        """Remove whitespace and other encodings"""
        for src, tgt in self.post_replace.items():
            hypothesis = hypothesis.replace(src, tgt)
        return hypothesis

    def get_hypothesis(self, encoded, **kwargs):
        """get hypothesis from model using encoded source"""

    def translate(self, method_text, **kwargs):
        """translate method_text into a docstring"""
        return self.decode(self.get_hypothesis(self.encode(method_text), **kwargs))


class FairseqModelInterface(ModelInterface):
    """
    Contains the pre-processing and model loading for
    a fairseq transformer translation model
    """

    def load_model(self, args):
        """
        Initialize fairseq translation model

        Parameters
        ----------
        datadir : str, path
            directory containing the fairseq-preprocessed source and
            target dictionaries
        checkpont : str, path
            path to fairseq checkpoint weights
        tokenizer_prefix : str, path
            prefix path to which '-vocab.json' and '-merges.txt' will
            be appended to find the merges/vocab files for the tokenizer
        pre_replace : dict (optional)
            an optional dict mapping strings to be applied before tokenization
        """
        self.pre_replace = getattr(args, 'pre_replace', dict([]))

        vocab = str(args.tokenizer_prefix) + "-vocab.json"
        merges = str(args.tokenizer_prefix) + "-merges.txt"
        self.tokenizer = ByteLevelBPETokenizer(vocab, merges)

        self.model = TransformerModel.from_pretrained(
                args.model_name_or_path,
                checkpoint_file=args.checkpoint_file,
                data_name_or_path=args.data_name_or_path,
        )
        if torch.cuda.is_available():
            self.model.cuda()

    def encode(self, method_text):
        """encode source method_text for model consumption"""
        for src, tgt in self.pre_replace.items():
            method_text.replace(src, tgt)
        return " ".join(self.tokenizer.encode(method_text).tokens)

    def get_hypothesis(self, encoded, **kwargs):
        """obtain hypothesis output from model"""
        if "beam" not in kwargs:
            kwargs["beam"] = 7
        if "temperature" not in kwargs:
            kwargs["temperature"] = 1.0
        return self.model.translate(encoded, **kwargs).replace(" ", "")


if False:  # __name__ == "__main__":
    TEST_METHOD = '''def add_insect(self, insect):
    if insect.is_ant:
        if (self.ant is None):
            self.ant = insect
        elif self.ant.can_contain(insect):
            self.ant.ant = insect
        elif insect.can_contain(self.ant):
            insect.ant = self.ant
            self.ant = insect
        else:
            assert (self.ant is None), 'Two ants in {0}'.format(self)
    else:
        self.bees.append(insect)
    insect.place = self'''

    ROOT = Path(
        "/smartml-athena/processed-data/fundef-docstrings/split/"
        "translate-method-docstring"
    )
    MODEL_PATH = ROOT / "fairseq/2020-02-25/"
    DATA_PATH = str(ROOT / "fairseq/binary_javadoc_problems")
    TOKENIZER_PREFIX = str(
        ROOT / "python-func-def-docstrings-2020-02-21-2026_bytelevelbpe_30000"
    )

    args = Args(
            model_name_or_path=MODEL_PATH,
            data_name_or_path=DATA_PATH,
            tokenizer_prefix=TOKENIZER_PREFIX,
            checkpoint_file='checkpoint_best.pt',
            pre_replace={}
    )

    MODEL = FairseqModelInterface()
    MODEL.load_model(args)
