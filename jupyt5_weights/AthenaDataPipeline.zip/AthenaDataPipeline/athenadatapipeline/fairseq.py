import string
from pathlib import Path
from collections import defaultdict

from textwrap import dedent

REPLACE = {chr(ord(f) + 256): f for f in string.whitespace}
REPLACE.update(**{
    "NEWLINE": "\n",
    "<user_handle>": "param",
    #NOTE: this removes 'mask' tokens!
    "madeupword0000": "",
})


def decode(incode):
    """decode GPT-style BytePair BPE tokenized data to string literal"""
    incode = "".join(incode.split())
    for r, f in REPLACE.items():
        incode = incode .replace(r, f)
    return incode


def _parse(outlines):
    """Reads gathered fairseq-generate lines, returns src, hyp, tgt, logprobs"""
    return {
            'src': decode("".join(outlines['S'][1:])),
            'hyp': decode("".join(outlines['H'][2:])),
            'tgt': decode("".join(outlines['T'][1:])),
            'logprobs': list(map(float, outlines['P'][1:]))
    }


def parse_generation(filepath):
    """
    Parse files from fairseq-generate into a list of examples.

    Parameters
    ----------
    filepath : str

    Returns
    -------
    examples : List[Dict]
        [
            {'src': '...', 'tgt': '...', 'hyp': '...', 'logprobs': [-.01, -0.2, ...]},
            ...
        ]
    """
    gathered = defaultdict(dict)
    with Path(filepath).open() as fin:
        for line in fin:
            if line[0] in ("S", "T", "H", "P"):
                tokens = line.split()
                gathered[int(tokens[0].split("-")[1])][line[0]] = tokens
    return [_parse(gathered[k]) for k in gathered]


def _decode_generation(tokens, line_type):
    if line_type == 'src':
        return decode("".join(tokens[1:]))
    if line_type == 'tgt':
        return decode("".join(tokens[1:]))
    if line_type == 'hyp':
        return decode("".join(tokens[2:]))
    if line_type == 'logprobs':
        return sum(map(float, tokens[1:]))


def iter_parse_generation(filepath):
    """
    Parse files from fairseq-generate into a list of examples.

    Parameters
    ----------
    filepath : str

    Yields
    -------
    examples : Dict[str, Union[str, list[str]]]
        [
            {'src': '...', 'tgt': '...', 'hyp': ['...', ], 'logprobs': [[-.01, -0.2, ...], ...]},
            ...
        ]
    """
    label_map = {"S": 'src', "T": 'tgt', "H": 'hyp', "P": "logprobs"}
    gathered = {}
    index = -1

    with Path(filepath).open() as fin:
        for line in fin:
            if not line[0] in label_map:
                continue
            label = label_map[line[0]]

            tokens = line.split()
            next_index = int(tokens[0].split("-")[1])
            decoded = _decode_generation(tokens, label)

            if next_index == index:
                if label in gathered:
                    try:
                        gathered[label].append(decoded)
                    except AttributeError:
                        gathered[label] = [gathered[label], decoded]
                else:
                    if isinstance(decoded, list):
                        gathered[label] = [decoded]
                    else:
                        gathered[label] = decoded
            else:
                if index > 0:
                    yield gathered
                gathered = {label: decoded}
                index = next_index


def form_method_hypothesis(generated, startphrase="# target", endphrase="# end"):
    src = generated['src']
    hyp = generated['hyp']
    tgt = generated['tgt']
    src_lines = src.splitlines()
    start, end = 0, len(src_lines) + 1
    for i, line in enumerate(src_lines):
        if line.lstrip().startswith(startphrase):
            start = i
        elif line.lstrip().startswith(endphrase):
            end = i
    src_prefix = "\n".join(src_lines[start:end] + [''])
    return dedent(src_prefix + hyp), dedent(src_prefix + tgt)
