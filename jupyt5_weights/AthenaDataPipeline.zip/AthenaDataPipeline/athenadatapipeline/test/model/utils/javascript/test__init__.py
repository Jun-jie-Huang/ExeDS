import pytest
from athenadatapipeline.model.utils.javascript import (
    fix_docstring,
    serialize_body,
    serialize_docstring,
    serialize_docstring_and_body,
    serialize_docstring_and_sig,
    serialize_sig_and_body,
    serialize_signature,
)
import sys


@pytest.mark.parametrize(
    "source, target",
    [
        (" add edge to the graph", "/**add edge to the graph */"),
        (
            "\n this docstring is comprised of \n multiple lines for the purpose\n of testing the docstring function\n to see what happens\n",
            "/**\n * this docstring is comprised of\n * multiple lines for the purpose\n * of testing the docstring function\n * to see what happens\n */",
        ),
        (
            "\n Given solution is O(n*sum) Time complexity and O(sum) Space complexity\n",
            "/**\n * Given solution is O(n*sum) Time complexity and O(sum) Space complexity\n */",
        ),
        (
            "\n Find the maximum non-adjacent sum of the integers in the nums input list\n :param nums: Array of Numbers\n :return: The maximum non-adjacent sum\n ",
            "/**\n * Find the maximum non-adjacent sum of the integers in the nums input list\n * :param nums: Array of Numbers\n * :return: The maximum non-adjacent sum\n */",
        ),
        (
            "\n @Find the maximum non-adjacent sum of the integers in the nums input list\n @:param nums: Array of Numbers\n :return: The maximum non-adjacent sum\n ",
            "/**\n * @Find the maximum non-adjacent sum of the integers in the nums input list\n * @:param nums: Array of Numbers\n * \t:return: The maximum non-adjacent sum\n */",
        ),
        (
            "\n @Find the maximum non-adjacent sum of the integers in the nums input list\n\n @:param nums: Array of Numbers\n :return: The maximum non-adjacent sum\n ",
            "/**\n * @Find the maximum non-adjacent sum of the integers in the nums input list\n *\n * @:param nums: Array of Numbers\n * \t:return: The maximum non-adjacent sum\n */",
        ),
    ],
)
def test_fix_docstring(source, target):
    docstring = fix_docstring(source)
    print(docstring)
    print("target")
    print(target)
    original_stdout = sys.stdout
    with open("fileone.txt", "w") as fp:
        sys.stdout = fp
        print(docstring)
        sys.stdout = original_stdout
    with open("filetwo.txt", "w") as f:
        sys.stdout = f
        print(target)
        sys.stdout = original_stdout
    assert docstring == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "/**get the dimensions of the rectangle object */\nget dimension()",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "function $w(string)",
        ),
        (
            {
                "original_string": "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "signature": "function $H(object)",
                "default_arguments": {},
                "body": "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$H",
                "docstring": "",
            },
            "function $H(object)",
        ),
    ],
)
def test_serialize_docstring_and_sig(source, target):
    doc_sig = serialize_docstring_and_sig(source)
    print(doc_sig)
    print("target")
    print(target)
    assert doc_sig == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "{\n    return {width: this.width, height: this.height};\n  }",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
        ),
    ],
)
def test_serialize_body(source, target):
    body = serialize_body(source)
    print(body)
    assert body == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "/**get the dimensions of the rectangle object */",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "",
        ),
        (
            {
                "original_string": "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "signature": "function $H(object)",
                "default_arguments": {},
                "body": "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$H",
                "docstring": "",
            },
            "",
        ),
    ],
)
def test_serialize_docstring(source, target):
    docstring = serialize_docstring(source)
    assert docstring == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "get dimension()",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "function $w(string)",
        ),
        (
            {
                "original_string": "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "signature": "function $H(object)",
                "default_arguments": {},
                "body": "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$H",
                "docstring": "",
            },
            "function $H(object)",
        ),
    ],
)
def test_seriailize_signature(source, target):
    sig = serialize_signature(source)
    assert sig == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "function $w(string) {\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
        ),
        (
            {
                "original_string": "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "signature": "function $H(object)",
                "default_arguments": {},
                "body": "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$H",
                "docstring": "",
            },
            "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
        ),
    ],
)
def test_serialize_sig_and_body(source, target):
    sig_body = serialize_sig_and_body(source)
    assert sig_body == target


@pytest.mark.parametrize(
    "source, target",
    [
        (
            {
                "attributes": {"decorator": []},
                "body": "{\n    return {width: this.width, height: this.height};\n  }",
                "original_string": "get dimension() {\n    return {width: this.width, height: this.height};\n  }",
                "docstring": "get the dimensions of the rectangle object",
                "default_arguments": {},
                "name": "get dimension",
                "signature": "get dimension()",
                "syntax_pass": True,
            },
            "/**get the dimensions of the rectangle object */\n{\n    return {width: this.width, height: this.height};\n  }",
        ),
        (
            {
                "original_string": "function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "signature": "function $w(string)",
                "default_arguments": {},
                "body": "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$w",
                "docstring": "",
            },
            "{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}",
        ),
        (
            {
                "original_string": "function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "signature": "function $H(object)",
                "default_arguments": {},
                "body": "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
                "syntax_pass": True,
                "attributes": {"keywords": "function"},
                "name": "$H",
                "docstring": "",
            },
            "{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}",
        ),
    ],
)
def test_serialize_docstring_and_body(source, target):
    docstring_body = serialize_docstring_and_body(source)
    assert docstring_body == target


# @pytest.mark.parametrize(
#     "source, target",
#     [
#         ({'attributes' : {'decorator' : []}, 'body' : '{\n    return {width: this.width, height: this.height};\n  }', "original_string" : 'get dimension() {\n    return {width: this.width, height: this.height};\n  }', "docstring" : "get the dimensions of the rectangle object", "default_arguments" : {}, "name" : "get dimension", "signature" : "get dimension()", "syntax_pass" : True},),
#         ({'original_string': 'function $w(string){\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}', 'signature': 'function $w(string)','default_arguments': {},'body': '{\n  string = string.strip();\n  return string ? string.split(/\\s+/) : [];\n}','syntax_pass': True, 'attributes': {'keywords': 'function'}, 'name': '$w', 'docstring': ''},),
#         ({'original_string': 'function $H(object) {\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}','signature': 'function $H(object)', 'default_arguments': {}, 'body': '{\n  var hash = Object.extend({}, object || {});\n  Object.extend(hash, Enumerable);\n  Object.extend(hash, Hash);\n  return hash;\n}', 'syntax_pass': True, 'attributes': {'keywords': 'function'}, 'name': '$H', 'docstring': ''},)
#     ]
# )
#     ({'attributes' : {'decorator' : []}, 'body' : '{\n    return {width: this.width, height: this.height};\n  }', "original_string" : 'get dimension() {\n    return {width: this.width, height: this.height};\n  }', "docstring" : "get the dimensions of the rectangle object", "default_arguments" : {}, "name" : "get dimension", "signature" : "get dimension()", "syntax_pass" : True},'/**get the dimensions of the rectangle object */\nget dimension() {\n    return {width: this.width, height: this.height};\n  }'),
