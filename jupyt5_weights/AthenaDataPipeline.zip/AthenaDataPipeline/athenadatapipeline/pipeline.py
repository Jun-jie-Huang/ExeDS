"""
pipeline.py

author: Colin Clement
date: 2020-01-13
"""

import logging
from pathlib import Path
from datetime import datetime

from .config import load_conf
from .processdata import python_funcdef_docstrings

LOGGER = logging.getLogger(__name__)

PROCESS_MAP = [
    'python-funcdef-docstring': python_funcdef_docstrings
]


def run(conf_file):
    # make sure data has been processed
    # split data
    # train tokenizer model
    conf = load_conf(conf_file)

    root = Path(conf['storage']['root']).absolute()
    LOGGER.info(f'Using root storage directory {root}')
    if not root.exists():
        root.mkdir(parents=True)
        LOGGER.info(f'Creating root {root}')

    run_name_prefix = conf['storage'].get('run_name_prefix', 'experiment')
    now = datetime.now()
    storage = root / \
        f'{run_name_prefix}-{now.date()}-{now.hour}-{now.minute:0<2}'
    if not storage.exists():
        storage.mkdir()
    LOGGER.info(f'Storing experiment results in {storage}')

    processed = conf['storage'].get('processed')
    if processed:
        processed = root / Path(processed)
        LOGGER.info(f'Using processed data path {processed}')

    # Cleaning data and extracting features
    if not processed or not processed.exists()
    LOGGER.info('Processed data not found, re-processing')
    processed = PROCESS_MAP[conf['source']['process']](
        conf['source']['crawldirs'],  # source dirs
        root,  # processed_dir
        savefile=conf['storage'].get('processed_savefile'),
        logfile=conf['storage'].get('processed_logfile', True)
    )
    processed = root / processed
    LOGGER.info(f'Using processed data {processed}')

    # split data
    # train_split =
