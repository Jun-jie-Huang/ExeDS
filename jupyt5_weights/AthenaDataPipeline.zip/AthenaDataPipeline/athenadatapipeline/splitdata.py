"""
splitdata.py

author: Colin Clement
date: 2020-01-11-12

"""

import json
import gzip
import random
import hashlib
import logging
from pathlib import Path
from multiprocessing import Pool
from itertools import islice, product, repeat, chain
from functools import partial
from contextlib import ExitStack
from collections import defaultdict
from textwrap import indent

from tqdm import tqdm
import psutil

from ray.util import ActorPool
import ray

from athenadatapipeline import load_zip_json
from athenadatapipeline.model.utils.python import serialize_body, serialize_docstring

LOGGER = logging.getLogger(__name__)


def _get_repo_name(crawldirs, crawldirs_split, file_path):
    """
    Get the 'name' of the repo of a given file.
    Assumes that one of crawldirs is a subpath of file_path. When it finds
    which crawldir file_path belongs to, it returns the highest level
    directory name of file_path contained in crawldir.

    Parameters
    ----------
    crawldirs : list[Path]
        list of directories containing source data
    crawldirs_split : list[list]
        each path in crawldir split
    file_path : Path
        file_path of file to find repo name of

    Returns
    -------
    repo_name : str
        string uniquely specifying repo name containing file_path
    """
    for cdir, cdir_split in zip(crawldirs, crawldirs_split):
        if str(cdir) in str(file_path):
            return Path(file_path).parts[len(cdir_split)]
    return ""


def split_serialize_legacy(
        json_gz_filename,
        crawldirs,
        datasets=('methods', 'docstring'),  # 'srs', 'tgt'
        serializers=(serialize_body, serialize_docstring),
        dir_suffix='split',
        keepempty=False,
        head=None,
    ):
    LOGGER.info(f"Loading {json_gz_filename}")
    data = load_zip_json(json_gz_filename, head=head)

    repo_assignments = repo_split([d[0] for d in data], crawldirs)
    crawldirs_split = [Path(cdir).parts for cdir in crawldirs]
    repo_name = partial(_get_repo_name, crawldirs, crawldirs_split)

    json_gz_filename = Path(json_gz_filename)
    directory, name = json_gz_filename.parent, json_gz_filename.name
    directory /= dir_suffix
    if not directory.exists():
        directory.mkdir(parents=True, exist_ok=True)
    name = name[: name.find(json_gz_filename.suffixes[0])]
    LOGGER.info(f"Saving prefix {name}")

    subsets = ['train', 'val', 'test']
    with ExitStack() as stack:  # basically a with open block for lists of files
        savestreams = dict()
        for sub, dataset in product(subsets, datasets):
            fname = f"{name}.{sub}.{dataset}.json.gz"
            LOGGER.info(f"Opening file {fname}")
            savestreams[sub + dataset] = stack.enter_context(
                    gzip.open(directory / fname, "wb")
            )
        for d in data:
            sub = subsets[repo_assignments[repo_name(d[0])]]
            for example in d[1]:

                for dataset, serializer in zip(datasets, serializers):
                    if all(map(lambda x: len(x) > 0, example)) or keepempty:
                        savestreams[sub + dataset].write(
                                (json.dumps(serializer(example)) + "\n").encode('utf-8')
                                )


def repo_split(
    filenames, crawldirs, seed=3165559177, proportions=(0.90, 0.05),
):
    """
    Split files in `filename` by e.g. proportions=[train, val, test] and saves a
    file in the same directory as `filename`.  This function splits file
    features by repository to prevent leakage of domain knowledge into
    generalization error estimated on the test set. See `_get_repo_name` for
    details.

    This function saves each data set in filenames formed by by replacing or
    appending the extensions '.train', '.val', and '.test' to `filename` for
    each each respective data set.

    Parameters
    ----------
    filenames : List[str]
        all filenames which were crawled
    crawldirs : list[str]
        list of directories crawled, used for identifying which files are in shared
        repositories (assuming repositories share some part of their directory path),
        so that we can prevent data leakage if we just randomly split on the file-level
    seed : int
        for predictable random data splitting
    proportions : list
        list of of len(list) == 2 floats in (0, 1.). The elements must sum to
        less than one. The first element is the proportion of training data,
        the second element is the proportion of validation data, and the remaining
        proportion is for the test set

    Returns
    -------
    repo_assignment : dict
        repo_assignment[repo_name] = 0, 1 or 2 (train, test, val set)
        [train, test, val] split of file names
    """
    assert len(proportions) == 2, "len(proportions) must be 2"
    assert sum(proportions) < 1.0, "sum(proportions) should be no more than 1.0"

    random.seed(seed)
    crawldirs_split = [Path(cdir).parts for cdir in crawldirs]
    repo_name = partial(_get_repo_name, crawldirs, crawldirs_split)

    cumululative = [sum(proportions[: i + 1]) for i in range(len(proportions))]
    split = [[], [], []]  # train val test comments

    repo_names = sorted(set(map(repo_name, filenames)))

    repo_assignments = dict()
    for repo in repo_names:
        rnd = random.random()
        if rnd < cumululative[0]:
            repo_assignments[repo] = 0
        elif rnd < cumululative[1]:
            repo_assignments[repo] = 1
        else:
            repo_assignments[repo] = 2

    return repo_assignments


def static_hash(str_tuple):
    """
    hash a tuple of bytes or objects serializable with str, get
    consistent results across runs
    without the hack of turning off the python hash seed
    """
    md5 = hashlib.md5()
    for strn in str_tuple:
        md5.update(str(strn).encode("utf-8"))
    return md5.hexdigest()


def split_serialize(
    json_lz4_filename,
    Collater,
    collater_args,
    source_only=False,
    head=None,
    thin=None,
    combine_training=True,
    combine_testval=False,
    num_workers=1024,
    run_name_prefix='splitserialized',
    proportions=(0.9, 0.05),
):
    """
    Read structured schema data and use the collater object to serialize it,
    splitting data by repositories into training/testing/validation sets.

    Parameters
    ----------
    json_lz4_filename : str/Path
        Path to jsonlines lz4/gzip file saved by source_parser
    Collater : athenadatapipeline.collater.Collater
        collater class which handles processing data examples into
        tokenized source-target pairs of strings
    collater_args : Tuple
        args handed to Collater for instantiation

    (optional)
    source_only : True/False
        whether the processed data only has a source and no target,
        e.g. for de-noising tasks
    head : int
        only load and process the first head items in json_lz4_filename
    thin : int
        only load and process every 1/thin items in json_lz4_filename
    combine_training : True/False
        whether to merge all dataset types produced by the Collater
        into one training source and target file pair
    combine_testval : True/False
        whether to merge all dataset types produced by the Collater
        into one testing/validation source and target file pair
    num_workers : int
        the number of concurrent tasks for multiprocessing. Generally
        a large number compared to the number of CPUs if each collated
        task is fast.
    run_name_prefix: str
        the name of the directory created in the source data directory
    proportions : Tuple[int]
        tuple containing (train, test) fractions (remaining fraction,
        1-train-test is saved for validation.
    """
    assert len(proportions) == 2, "len(proportions) must be 2"
    assert sum(proportions) < 1.0, "sum(proportions) should be no more than 1.0"
    cumululative = [sum(proportions[: i + 1]) for i in range(len(proportions))]
    repo_subset = {}
    split_repo = defaultdict(list)

    directory, name = json_lz4_filename.parent, json_lz4_filename.name
    directory /= f"{run_name_prefix}/{Collater.task_label}"
    if not directory.exists():
        directory.mkdir(parents=True, exist_ok=True)

    # takes off the .json.* suffixes
    name = name[: name.find(json_lz4_filename.suffixes[-2])]
    LOGGER.info(f"Saving prefix {name}")

    def file_key(subset, label, suffix):
        if subset == 'train' and combine_training:
            return f'train.{suffix}'
        if subset in ('test', 'val') and combine_testval:
            return f'{subset}.{suffix}'
        return f'{subset}.{label}.{suffix}'

    def file_name(name, subset, label, suffix):
        if subset == 'train' and combine_training:
            fname = f'{name}.train'
        elif subset in ('test', 'val') and combine_testval:
            fname = f'{name}.{subset}'
        else:
            fname = f'{name}.{subset}_{label}'
        if suffix:
            fname += f'.{suffix}'
        return fname

    source_labels = Collater.source_labels
    target_labels = source_labels if source_only else Collater.target_labels
    msg = 'source_labels and target_labels attributes of Collater must be equal length'
    assert len(source_labels) == len(target_labels), (
            'source_labels and target_labels attributes of Collater must be equal length'
    )
    suffixes = [''] if source_only else ['src', 'tgt']

    subsets = ["train", "val", "test"]
    with ExitStack() as stack:  # basically a with open block for lists of files
        savestreams = dict()
        bytes_written = dict()

        for subset, (src_label, tgt_label) in product(
                subsets, zip(source_labels, target_labels)
            ):

            task_label = src_label if source_only else f'{src_label}_to_{tgt_label}'

            for suffix in suffixes:
                key = file_key(subset, task_label, suffix)

                if key not in savestreams:
                    fname = file_name(name, subset, task_label, suffix)
                    LOGGER.info(f"Opening file {fname}")
                    savestreams[key] = stack.enter_context(open(directory / fname, "w"))
                    bytes_written[key] = 0

        ray.init()
        RemoteCollater = ray.remote(Collater)
        pool = ActorPool([
            RemoteCollater.remote(*collater_args) for i in range(psutil.cpu_count())
        ])

        datiter = load_zip_json(json_lz4_filename, head=head, thin=thin)
        for file_dict in islice(datiter, num_workers):
            pool.submit(lambda a, v: a.collate.remote(v), file_dict)

        pbar = tqdm()
        while True:
            try:
                file_collated = pool.get_next_unordered()
                pbar.update(1)
            except StopIteration:
                break

            for file_dict in islice(datiter, 1):  # handles end of generator nicely
                pool.submit(lambda a, v: a.collate.remote(v), file_dict)

            repo_name = file_collated['url']
            if not repo_name in repo_subset:
                repo_bin = int(static_hash(repo_name), 16) % 100 / 100
                if repo_bin < cumululative[0]:
                    repo_assignment = 'train'
                elif repo_bin < cumululative[1]:
                    repo_assignment = 'val'
                else:
                    repo_assignment = 'test'
                repo_subset[repo_name] = repo_assignment
                split_repo[repo_assignment].append(repo_name)

            subset = repo_subset[repo_name]
            for src_label, tgt_label in zip(source_labels, target_labels):
                task_label = src_label if source_only else f'{src_label}_to_{tgt_label}'

                for src, tgt in zip(file_collated[src_label], file_collated[tgt_label]):
                    if not src or not tgt:
                        continue  # skip pairs with empty source or target

                    for out, suffix in zip([src, tgt], suffixes):
                        key = file_key(subset, task_label, suffix)
                        bytes_written[key] += savestreams[key].write(out + "\n")

        pbar.close()

    splitname = directory / f'{name}.split.json'
    with open(splitname, 'w') as fout:
        json.dump(split_repo, fout)
        LOGGER.info(f"Wrote repo split assignment to {splitname}")

    for subset, (src_label, tgt_label) in product(
            subsets,
            zip(Collater.source_labels, Collater.target_labels)
        ):

        task_label = f'{src_label}_to_{tgt_label}'
        for suffix in ['src', 'tgt']:
            key = file_key(subset, task_label, suffix)
            fname = file_name(name, subset, task_label, suffix)
            LOGGER.info(f"Bytes_written to file {fname} = {bytes_written[key]}")
