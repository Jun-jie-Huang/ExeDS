"""
collater.py
Usage : collater class used to help prepare model data for training
"""

from typing import List, Dict, Union
from abc import ABC, abstractmethod
import tokenizers


class Collater(ABC):
    """
    Class used to keep file and task specific information used to split data
    into training, testing, validating groups
    """

    # matches pairs of source-target dataset labels, e.g. "signature" and "body"
    source_labels = ()
    target_labels = ()  # name of multiple test/valid sets too
    task_label = ""

    def __init__(self, tok_prefix):
        self.tok_prefix = tok_prefix
        self.tokenizer = tokenizers.ByteLevelBPETokenizer(
            self.tok_prefix + "-vocab.json", self.tok_prefix + "-merges.txt"
        )

    @property
    def datasets(self):
        """
        dataset_labels = (str1, str2)
            str1 : sourc_type
            str2 : target_type
        """
        return self.source_labels + self.target_labels

    @abstractmethod
    def _collate(self, file_dict) -> Dict[str, Union[str, List, Dict]]:
        """Implement this method following 'collate'"""

    def collate(self, file_dict) -> Dict[str, Union[str, List, Dict]]:
        """
        Parameters
        ----------
        file_dict : Dict[str, Union[str, List, Dict]]
            the schema (from source_parser) of one specific file
        Returns
        -------
        collated_data: Dict[str, List[str]]
            collated_data[dataset_label] =
                {
                    'url' : repo_url_for_splitting,
                    'sourcetypes' : list_of_sources,
                    'targettypes' : list_of_targets
                }
        """
        return self._collate(file_dict)
