"""
train_vocab.py

author: Colin Clement
date: 2020-01-13

"""

import logging
from pathlib import Path

import tokenizers

from athenadatapipeline import load_zip_json

LOGGER = logging.getLogger(__name__)

MODEL_DICT = {'bytelevelbpe': tokenizers.ByteLevelBPETokenizer}


def textify(filename):
    """ take json.gz filename, save as text file suitable for training tokenizer """
    path = Path(filename)
    nameparts = path.name.split('.')
    nameparts.remove('json'); nameparts.remove('gz')
    savename = path.parent / '.'.join(nameparts)  # split off .json.gz extensions

    with savename.open('w') as fout:
        for example in load_zip_json(filename):
            if isinstance(example, str):
                fout.write(example + '\n')
            elif isinstance(example, list) or isinstance(example, tuple):
                for d in example:
                    fout.write(example + '\n')
            else:
                raise NotImplementedError(
                        "Individual entries are type {type(example)}."
                        "Only str, list, or tuple are currently implemented"
                        )
    return savename


def train(
        file_paths,
        vocab_size,
        save_dir=None,
        save_prefix=None,
        model_type=None,
        special_tokens=None,
):
    """
    Train a sentencepiece model.

    Parameters
    ----------
    file_paths : list[str/Path]
        list of paths to training data. If json files are provided, tries
        to flatten them using `crawlercrawler.splitdata.textify`
    vocab_size : int
        target vocabulary size
    save_prefix : str (optional)
        default save_prefix is the prefix of train_data with
        vocab_size and model_type appended.
    model_type : str (optional)
        'bpe' or 'unigram'
    special_tokens : list (optional)
        list of strings (tokens) which the tokenizer
        should not split. By default includes
            '<s>' - beginning of 'sentence'
            '</s>' - end of 'sentence'
            '<pad>' - padding
            '<mask>' - mask for masked language modeling
            '<eof>' - end of file

    Returns
    -------
    model_prefix : str
        the prefix string, tokenizer saves
        model_prexix-merges.txt and model_prefix-vocab.json. If
        model_prefix = None is given, will return model_prefix
        appending model_type and vocab_size to train_data basename
    """
    model_type = model_type or 'bytelevelbpe'
    if save_prefix is None:
        prefix = Path(file_paths[0]).name.split('.')[0]
        save_prefix = Path(f"{prefix}_{model_type}_{vocab_size}")
        LOGGER.info(f'Tokenizer save_prefix {save_prefix}')

    if save_dir is None:
        save_dir = Path(file_paths[0]).parent

    tokenizer = MODEL_DICT[model_type]()
    LOGGER.info(f'Training model type {model_type}')

    if special_tokens is None:
        special_tokens = []

    text_file_paths = []
    to_cleanup = []
    for fil in file_paths:
        fil = Path(fil)
        if 'json' in fil.name:
            LOGGER.info(f'Flattening json file {fil} to text')
            txt_path = textify(fil)
            text_file_paths.append(txt_path)
            to_cleanup.append(txt_path)
        else:
            text_file_paths.append(fil)
    
    special_tokens += ['<s>', '</s>', '<pad>', '<mask>', '<unk>']
    tokenizer.train(
            files=list(map(str, text_file_paths)),
            vocab_size=vocab_size,
            min_frequency=2,
            special_tokens=special_tokens,
            )

    for fil in to_cleanup:
        if fil.exists():
            LOGGER.info(f'Cleaning up flattened json file {fil}')
            fil.unlink()

    LOGGER.info(f'Saving model to {save_dir}/{save_prefix}')
    tokenizer.save(str(save_dir), str(save_prefix))
    return save_dir / save_prefix
