import logging
from pathlib import Path

from crawlercrawler.dothecrawl import CrawlCrawler
from crawlercrawler.observers import ExtractFuncDefDocstrings

LOGGER = logging.getLogger(__name__)


def python_funcdef_docstrings(
        crawldirs, processed_dir, savefile=None, logfile=True, **kwargs
):
    """
    Extract python function definition and docstrings from all python files in
    crawldirsa and store the results in processed_dir.

    Parameters
    ----------
    crawldirs : list
        list of directories to process
    processed_dir : Path/str
        save data in this directory

    Returns
    -------
    savefile : str
        location of processed data
    """

    processed_dir = Path(processed_dir)
    if not processed_dir.exists():
        processed_dir.mkdir()

    observer = ExtractFuncDefDocstrings(processed_dir=processed_dir)

    crawler = CrawlCrawler(
        observers=[observer], crawldirs=crawldirs, writelogs=True, **kwargs
    )
    crawler.walk()

    return observer.savefile
