/scripts/gpt2_method_gen/split.py ---> split into train/val/test on repo level, exactly like Colin does
/scripts/gpt2_method_gen/prepare_for_fairseq.py ---> add in spaces between tokens (that's how fairseq wants it) and add newlines between examples (it is nice because fairseq will then have "end of sample" tokens for prediction)

1) To do split: 
    1) python scripts/gpt2_method_gen/split.py 
    Change datasets = ("methods",)
    and serializers
    and keepempty

    2) python scripts/gpt2_method_gen/prepare_for_fairseq.py 

2) /nbs/preprocessing_for_gpt2_training_demo.ipynb ---> fairseq-preprocess (+ fairseq-train examples)

3) rsync_blob.sh

4) submit to AML

/nbs/examineDataPreprocess.ipynb ---> see that preprocess is what is expected





=================testing=================

scripts/model_init_test.py ---> like Colin's model_init.py, modified to do gpt2 huggingface; interestingly, uses .translate() still
scripts/scratch.py ---> ipython scratch for model_init.py
scripts/fairseq_generate_test.sh ---> examples of running generate; really just need run python 
scripts/generate.py ---> was copied from fairseq repo for interactive debugging (as opposed to cli)


#nbs/evaluate_models.ipynb ---> imports scripts/model_init_test.py and generates text files (1) targets (2) hypotheses. Then takes in those files and computes Rouge, BLEU, etc. Rouge jackknife style like Colin

scripts/gpt2_method_gen/split.py ---> modified to create jsonlines files with [src, tgt] for methods in /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval

scripts/eval_gpt2.py ---> write out test set, with hypotheses added 