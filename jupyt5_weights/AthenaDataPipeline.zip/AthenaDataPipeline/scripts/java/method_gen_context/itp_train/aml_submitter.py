#!/usr/bin/env python
"""
aml_submitter.py

NOTE: this script requires AML SDK 1.15+

This script launches fairseq-train jobs on AML Kubernetes clusters with one or
more GPUs and one or more nodes.

Example usage for multi-node fairseq training:
  python aml_submitter.py conf.yaml --node_count=2
"""

import logging
from pathlib import Path
import argparse
import azureml.core

from azureml.telemetry import set_diagnostics_collection

set_diagnostics_collection(send_diagnostics=True)

from azureml.core import Datastore, Experiment
from azureml.core.workspace import Workspace
from azureml.data.data_reference import DataReference
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.core.runconfig import MpiConfiguration

from azureml.core import ScriptRunConfig
from azureml.core.environment import Environment

from azureml.contrib.core.k8srunconfig import K8sComputeConfiguration
from azureml.contrib.core.compute.k8scompute import AksCompute

from aml_conf_parser import load_specified_conf

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)-15s %(name)-5s %(levelname)-8s %(message)s",
)
LOGGER = logging.getLogger("aml_submitter")
LOGGER.setLevel(logging.INFO)
LOGGER.info("SDK version: %s", azureml.core.VERSION)


def initialize_workspace():
    """Initialize the AML workspace from the local config.json file"""
    ws = Workspace.from_config()
    LOGGER.info(
        "\n".join(
            [
                "",
                f"Workspace name: {ws.name}",
                f"Azure region: {ws.location}",
                f"Subscription id: {ws.subscription_id}",
                f"Resource group: {ws.resource_group}",
            ]
        )
    )
    return ws


def determine_cluster_name(ws):
    """Find cluster name in workspace"""
    for _, target in ws.compute_targets.items():
        if isinstance(target, AksCompute):
            return target.name


def get_or_create_cluster(
    ws,
    max_nodes=4,
    idle_seconds_before_scaledown=600,
    vm_size="STANDARD_NC24rs_v3",
):
    """Select cluster to run on"""
    cluster_name = "v100-32gb-wus2"  # determine_cluster_name(ws)
    LOGGER.info(f"Cluster name {cluster_name}")
    LOGGER.info(f"Will submit jobs to {cluster_name} compute target")
    try:
        compute_target = ComputeTarget(workspace=ws, name=cluster_name)
        LOGGER.info("Found existing compute target.")
    except ComputeTargetException:
        LOGGER.info("Creating a new compute target...")
        compute_config = AmlCompute.provisioning_configuration(
            vm_size=vm_size,
            max_nodes=max_nodes,
            idle_seconds_before_scaledown=idle_seconds_before_scaledown,
        )

        # create the cluster
        compute_target = ComputeTarget.create(ws, cluster_name, compute_config)
        compute_target.wait_for_completion(show_output=True)
    return compute_target


def get_or_create_datastore(
    ws,
    datastore_name=None,
    container_name=None,
    account_name=None,
    account_key=None,
    create_if_not_exists=False,
):
    """Get DataStore object for interacting with mounted Blob storage"""
    try:
        ds = Datastore.get_default(ws)
        LOGGER.info("Found existing datastore.")
    except:
        LOGGER.ingo("Creating a new datastore...")
        ds = Datastore.register_azure_blob_container(
            workspace=ws,
            datastore_name=datastore_name,
            container_name=container_name,
            account_name=account_name,
            account_key=account_key,
            create_if_not_exists=create_if_not_exists,
        )
    return ds


def create_configuration(
    workspace,
    args,
    conf,
    input_data,
    script_params,
    project_folder=".",
):
    """Create ScriptRunConfig object for this experiment"""
    arguments = [str(input_data)]
    data_references = {input_data.data_reference_name: input_data.to_config()}
    for name, value in script_params.items():
        arguments.append(name)
        if value:
            arguments.append(str(value))
        if isinstance(value, DataReference):
            data_references[value.data_reference_name] = value.to_config()

    LOGGER.info(
        "Command with arguments:\n\t fairseq-train {}".format(
            " ".join(map(str, arguments))
        )
    )

    compute_target = get_or_create_cluster(workspace)
    LOGGER.info(compute_target.get_status())

    myenv = Environment(
        workspace=ws,
        name="aml_submitter",
    )
    myenv.docker.enabled = True
    myenv.docker.base_image = conf["cluster"][
        "docker"
    ]  # Using a public image published on Dockerhub
    myenv.python.user_managed_dependencies = True

    scriptrun_kwargs = {
        "script": args["entry_script"],
        "environment": myenv,
        "compute_target": compute_target,
        "arguments": arguments,
    }

    k8_config_args = {
        "gpu_count": args["gpu_count"],
        "enable_ssh": conf["cluster"]["use_ssh"],
        "ssh_public_key": conf["cluster"]["public_key"],
    }

    if args["node_count"] > 1:
        # Using MPI to execute a distributed run
        LOGGER.info("Using MPI for multinode job")
        scriptrun_kwargs["distributed_job_config"] = MpiConfiguration(
            args["process_count_per_node"], args["node_count"]
        )
        # according to K8 docs, gpu_count is better be left unset when running multinode
        k8_config_args.pop("gpu_count", None)

    src = ScriptRunConfig(project_folder, **scriptrun_kwargs)
    src.run_config.data_references = data_references

    compute_config = K8sComputeConfiguration()
    compute_config.configuration = k8_config_args
    src.run_config.cmk8scompute = compute_config

    return src


def parse_args():
    """
    Parse the args passed from the command line specifiying the specific yaml to load
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "config_file",
        type=str,
        help="Yaml config file. See conf.yaml.examples",
    )
    parser.add_argument(
        "--cluster_name",
        type=str,
        default="v100-32gb-wus2",
        help="Cluster name, string. Check which clusters are already avaialbe in the AML workspace",
    )
    parser.add_argument(
        "--entry_script",
        type=str,
        default='fairseq_train.py',
        help="Name of the script to submit, default is wrapped fairseq_train",
    )
    parser.add_argument(
        "--node_count",
        type=int,
        default=1,
        help="Number of nodes. If greater than 1, MPI will be enabled",
    )
    parser.add_argument(
        "--gpu_count",
        type=int,
        default=8,
        help="Number of GPUs to use (per node or total??)",
    )
    parser.add_argument(
        "--max_run_duration_seconds",
        type=int,
        default=2592000,
        help="Maximum run duration in seconds, default is 30 days",
    )
    parser.add_argument(
        "--process_count_per_node",
        type=int,
        default=8,
        help="Number of tasks per node. If your job is serial -- 1, if it is parallel, then up to NGPUs per node (4 in case of NC24_v3 SKU)",
    )
    parser.add_argument(
        "--image_name",
        type=str,
        default="asvyatko/fairseqmax:20.07-py3-noray",
        help="Docker image name. E.g. asvyatko/fairseqmax:latest",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Do not submit job but print logging information",
    )
    return vars(parser.parse_args())


if __name__ == "__main__":
    args = parse_args()

    conf = load_specified_conf(args["config_file"])
    LOGGER.info(conf)

    LOGGER.info("Create or access existing AML workspace")
    ws = initialize_workspace()
    experiment = Experiment(ws, name=conf["cluster"]["experiment"]["name"])
    previous_runs = list(experiment.get_runs())  # previous runs of this experiment

    LOGGER.info("Create data references in default AML datastore")
    ds = get_or_create_datastore(ws)

    script_params = {}
    # required
    save_dir = Path(conf["script_params_special"]["save_dir"])
    script_params["--save-dir"] = DataReference(
        datastore=ds,
        data_reference_name="save_dir",
        path_on_datastore=str(save_dir.parent / (save_dir.name + f'_{len(previous_runs)+1}')),
    )

    # optional
    try:
        tbpath = Path(conf["script_params_special"]["tboard_dir"])
        script_params["--tensorboard-logdir"] = DataReference(
            datastore=ds,
            data_reference_name="tboard_dir",
            #  append run number of experiment to keep from over-writing tensorboard accumulators
            path_on_datastore=str(tbpath.parent / (tbpath.name + f'_{len(previous_runs)+1}')),
        )
    except KeyError:
        LOGGER.info("Specify folder for tensorboard logging.")

    try:
        script_params["--restore-file"] = DataReference(
            datastore=ds,
            data_reference_name="restore_file",
            path_on_datastore=conf["script_params_special"]["restore_file"],
        )
    except KeyError:
        LOGGER.info("No warmstart file to restore from")

    if "script_params" in conf.keys():
        script_params.update(conf["script_params"])  # add rest of params

    # required
    input_data = DataReference(
        datastore=ds,
        data_reference_name="input_data",
        path_on_datastore=conf["script_params_special"]["input_data"],
    )

    src = create_configuration(
        ws,
        args,
        conf,
        input_data,
        script_params,
    )

    # submit experiment
    if not args["debug"]:
        run = experiment.submit(src, tags=conf.get("tags", None))
        LOGGER.info(run)
