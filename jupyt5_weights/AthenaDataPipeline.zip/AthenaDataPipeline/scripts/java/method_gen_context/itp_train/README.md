# Steps

1. Run fairseq preprocessing
2. Upload preprocessed data on ITP datastore
3. Set data and results paths as well as training params in the `conf.yaml` file
4. Submit the training job


# Example usage
```
python aml_submitter.py --entry_script train.py --config_file conf.yaml 
```
