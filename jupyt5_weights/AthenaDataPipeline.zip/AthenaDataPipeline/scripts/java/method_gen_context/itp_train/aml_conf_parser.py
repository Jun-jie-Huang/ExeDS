# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import yaml
import errno
import os


def parameters(input_file):
    """
    Parse yaml file of configuration parameters.
    """
    with open(input_file, "r") as yaml_file:
        params = yaml.load(yaml_file, Loader=yaml.FullLoader)
    return params


def load_specified_conf(conf_path: str):
    """
    Loads a particular conf.yaml file as specified.
    :param conf_path: path to conf file to load (requires (.yaml) extension)
    :return: dict of parameters of specified conf.yaml file
    """
    if os.path.exists(conf_path):
        return parameters(conf_path)
    else:
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), conf_path)
