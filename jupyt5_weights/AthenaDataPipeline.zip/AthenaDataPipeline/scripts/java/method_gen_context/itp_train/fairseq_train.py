"""
aml_fairseq_train.py

This wraps the underlying CLI for fairseq-train with functions which
set the MPI environment variables correctly for AML to run multi-node jobs

This script can be used for single-node, non-MPI jobs by setting the environment
variable USE_MPI to 0/1 in the Environment object in the submission script

see: https://azure.github.io/azureml-examples/docs/cheatsheet/distributed-training/
for more details on setting these environment variables for MPI distributed jobs
"""

import os
from fairseq_cli.train import cli_main

DEBUG = False


def set_environment_variables(single_node=False, master_port=6105, debug=DEBUG):
    os.environ["LOCAL_RANK"] = os.environ["OMPI_COMM_WORLD_LOCAL_RANK"]
    os.environ["MASTER_ADDR"] = os.environ["MASTER_IP"]
    os.environ["MASTER_PORT"] = str(master_port)
    os.environ["RANK"] = os.environ["OMPI_COMM_WORLD_RANK"]
    os.environ["WORLD_SIZE"] = os.environ["OMPI_COMM_WORLD_SIZE"]
    # suggested by the cheatsheet linked above, didn't work for me
    #single_node = int(os.environ["OMPI_COMM_WORLD_LOCAL_SIZE"]) == int(
    #    os.environ["WORLD_SIZE"]
    #)
    #if not single_node:
    #    master_node_params = os.environ["AZ_BATCH_MASTER_NODE"].split(":")
    #    os.environ["MASTER_ADDR"] = master_node_params[0]
    #    # Do not overwrite master port with that defined in AZ_BATCH_MASTER_NODE
    #    if "MASTER_PORT" not in os.environ:
    #        os.environ["MASTER_PORT"] = str(master_port)
    #else:
    #    os.environ["MASTER_ADDR"] = os.environ["AZ_BATCHAI_MPI_MASTER_NODE"]
    #    os.environ["MASTER_PORT"] = "54965"
    os.environ["NCCL_SOCKET_IFNAME"] = "^docker*,lo"

    if debug:
        print("\tRANK = {}".format(os.environ["RANK"]))
        print("\tLOCAL_RANK = {}".format(os.environ["LOCAL_RANK"]))
        print("\tWORLD_SIZE = {}".format(os.environ["WORLD_SIZE"]))
        print("\tMASTER_ADDR = {}".format(os.environ["MASTER_ADDR"]))
        print("\tMASTER_PORT = {}".format(os.environ["MASTER_PORT"]))


def get_local_rank():
    return int(os.environ["OMPI_COMM_WORLD_LOCAL_RANK"])


def modify_parser(parser):
    parser.set_defaults(
        **{
            "device_id": get_local_rank(),
        }
    )


if __name__ == "__main__":
    try:
        set_environment_variables()
        cli_main(modify_parser)
    except KeyError as k_err:
        if DEBUG:
            print("Environment variables:" + ", ".join(os.environ.keys()))
        print("MPI environment variables not found, running single-node mode")
        cli_main()
