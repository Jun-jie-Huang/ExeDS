#!/bin/bash

DATADIR=`cat conf.yaml | shyaml get-value split_features.prefix` 
SUFFIX=`cat conf.yaml | shyaml get-value split_features.suffix`
DATADIR="$DATADIR/$SUFFIX"
DAWNDIR=`cat conf.yaml | shyaml get-value dawndir`
PREFIX=`cat conf.yaml | shyaml get-value fairseq_prepare.prefix`
echo $PREFIX
echo $DATADIR
echo $DAWNDIR

declare -a SUFFIXLIST=(
    's_to_d'
    's_to_b'
    's_to_db'
    'd_to_b'
    'd_to_sb'
    'b_to_d'
    'b_to_ds'
    'ds_to_b'
    'sb_to_d'
)

for SUFFIX in "${SUFFIXLIST[@]}"
do
    if [ -z ${VALIDPREF+x} ]; then
        export VALIDPREF="$DATADIR/$PREFIX.val_$SUFFIX"
        export TESTPREF="$DATADIR/$PREFIX.test_$SUFFIX"
    else
        export VALIDPREF="$VALIDPREF,$DATADIR/$PREFIX.val_$SUFFIX" 
        export TESTPREF="$TESTPREF,$DATADIR/$PREFIX.test_$SUFFIX" 
    fi
    echo "$DATADIR/$PREFIX.val_$SUFFIX"
    echo "$DATADIR/$PREFIX.test_$SUFFIX" 
done

fairseq-preprocess \
    --source-lang 'src' \
    --target-lang 'tgt' \
    --trainpref $DATADIR/$PREFIX.train \
    --validpref $VALIDPREF \
    --testpref $TESTPREF \
    --destdir $DATADIR/binary \
    --workers 96
    #--srcdict $DAWNDIR/dict.src.txt \
    #--tgtdict $DAWNDIR/dict.src.txt \
    #--srcdict $DATADIR/binary/dict.methods.txt \
    #--tgtdict $DATADIR/binary/dict.docstring.txt \
    #--joined-dictionary \
