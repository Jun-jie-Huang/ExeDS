"""
split_separate_features.py

author: Colin Clement
date: 2020-04-15


"""

import os
import argparse
from pathlib import Path

from athenadatapipeline.model.utils.python import serialization_mapping
from athenadatapipeline.splitdata import split_serialize_legacy
from athenadatapipeline.config import load_conf


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())

if __name__ == "__main__":
    args = parse_args()
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), args["conf_path"]
    )
    conf = load_conf(path_to_conf)

    DATA_DIR = Path(conf['split_features']['prefix'])
    JSON_GZ = DATA_DIR / conf['split_features']['json_gz']

    datasets = (conf['split_features']['label'],)
    serializers = (serialization_mapping,)
    dir_suffix = conf['split_features']['suffix']

    split_serialize_legacy(
        JSON_GZ,
        crawldirs=CRAWLDIRS,
        datasets=datasets,
        serializers=serializers,
        dir_suffix=dir_suffix,
        keepempty=True,  # so methods without docstrings will be included
    )
