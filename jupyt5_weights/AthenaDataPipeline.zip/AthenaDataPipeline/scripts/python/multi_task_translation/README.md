# Multi-mode or multi-task training

These scripts prepare the method-docstring python data for translation
between pairs of features:
* Signature to docstring
* Body to docstring
* Sig+body to docstring (docstring prediction)
* Body to sig + docstring
* Sig to docstring and body
* Sig to body
* Doc to body
* Doc to sig + body
* Sig + doc to body (method predicition)

These folds were chosen as the mappings between all
pairs of the 3 features [sig, doc, body] which do not map
to themselves, and which do not target purely signatures.

The idea is that the model will learn to more effectively perform
useful tasks like method prediciton and docstring prediction
if it tries to do so using all combinations of features. This also allows
us to use all of the methods, even the ones without docstrings,
to improve docstring related tasks.

## Usage

These scripts require the method-docstring corpus data, e.g.

    python-func-def-docstrings-2020-03-04-2336.json.gz,

a suitably trained tokenizer, and a model checkpoint.
Here I use Dawn's whitespace-enhanced
tokenizer. The only subtlety with this tokenizer is newline characters
'\n' must be replaced with 'NEWLINE' as the pretrained model 
was trainged this way.

### Split data on the repo level

Set the path `DATA_DIR` and `JSON_GZ` to point the script
to the method-docstring corpus. `CRAWLDIRS` is specific to the
dataset and the environment it was generated on, and is used to
split on the repo level. If you use the corpus Colin generated,
do not change this. Set `suffix_dir` in the `split_serialize_data`
invocation, and the split featured data will be saved in that
plath relative to the execution location. Then simply

    python split_serialize_data.py

### Prepare the split data for fairseq-preprocess

`fairseq-preprocess` can accept pre-tokenized data in the form of
newline-separated examples where tokens themselves are separated
by spaces.  The `prepare_for_fairseq.py` script does this for you,
and also adds imperative strings like `# target body` if the source
for that example should be a function body. 

Set the `DIRECTORY` to the directory containing the split data
from the previous step. Set the `DAWNDIR` to the directory
containing Dawn's pretrained tokenizer files which have suffixes 
`-merges.txt` and `-vocab.json`. Set `subdir` in the argument to
the `prepare` function to the location the text files should be saved.
Then simply

    python prepare_for_fairseq.py

### Fairseq-preprocess

I like to run this command on DLTS because it is highly parallelized,
and the 96 cores on DLTS make quick work of preparing the binaries.
To use the pre-process script `fairseq-preprocess`, set
`DATADIR` to the location containing the output from the previous step.
Set `DAWNDIR` to the directory containing the src and tgt dictionaries
required to align the vocabulary of Dawn's pretrained model with the
binarized data this step produces. Set `PREFIX` to the same
file name you've been using representing the method-docstring corpus,
probably `python-func-def-docstrings-2020-03-04-2336`. 
Note that this will save the binarized data, logs and dictionaries
in `$DATADIT/binary`. To use, simply

    ./fairseq_preprocess.sh

### Training script

Unfortunately, `fairseq-preprocess` maps different test/valid set names
to simple integers, so `valid_s_to_b` gets mapped to `valid1`. That is
why `VALIDSUBSET`  contains these names even though we went through
the trouble of giving them useful names. To use this script to start training
a model, set `DATADIR` to the same as the previous script (it also assumes
the binary data is in `$DATADIR/binary`, and set the `SAVEDIR` to the location
you want model checkpoints to be saved, and name the `tensorboard-logdir` to the place
you want tensorboard logs to be saved.
