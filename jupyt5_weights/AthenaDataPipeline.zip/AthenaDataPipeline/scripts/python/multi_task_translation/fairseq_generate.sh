

#export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"
export DATADIR="/smartml-athena/processed-data/fundef-docstrings/split/multi-task-translation/fairseq"
export PREFIX="python-func-def-docstrings-2020-03-04-2336"

export DIR="$DATADIR/binary"
export SAVEDIR="$DATADIR/2020-04-17" 

# sig -> doc
export SUBSET="test"

# sig -> body
#export SUBSET="test1"

# sig + doc -> body
#export SUBSET="test7"

# sig + body -> doc
#export SUBSET="test8"


export CUDA_VISIBLE_DEVICES=0
fairseq-generate $DIR \
    --path $SAVEDIR/checkpoint_best.pt \
    --gen-subset $SUBSET \
    --beam 5 \
    --max-tokens 3300 \
    --results-path $SAVEDIR/generated \
    --num-workers 2 \
    --skip-invalid-size-inputs-valid-test \
    --empty-cache-freq 1 \
    #--batch-size 32 --beam 5 \
