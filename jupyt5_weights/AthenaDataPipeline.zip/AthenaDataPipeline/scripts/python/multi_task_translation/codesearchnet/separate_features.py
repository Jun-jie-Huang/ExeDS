"""
split_separate_features.py

author: Colin Clement
date: 2020-04-15


"""

from pathlib import Path
import json
import gzip

from textwrap import indent

from athenadatapipeline import load_zip_json
from athenadatapipeline.splitdata import split_serialize_data, clean_docstring
from athenadatapipeline.classify_docstrings import get_class

from crawlercrawler.normalization import NORMALIZE_LABEL, normalize
from crawlercrawler.func_def_features import extract_function_definitions

DATA_DIR = Path('/smartml-athena/codesearchnet/python/final/jsonl/test')
JSON_GZ = DATA_DIR / 'python_test_0.jsonl.gz'

def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == '\n':
        return f'"""\n{docstring}\n"""'
    else:
        return f'"""{docstring}"""'

def serialize_sig(dat):
    return dat[0]

def serialize_docstring(dat):
    if not dat[1]:  # empty docstring
        return dat[1]
    cleaned = clean_docstring(dat[1])
    if cleaned:
        return indent(code_format_docstring(cleaned), ' ' * 4)
    return cleaned  # emptied by cleaning

def serialize_body(dat):
    return indent(dat[2], ' ' * 4)

def serialize_sig_and_body(dat):
    return '\n'.join([
        dat[0],
        indent(dat[2], ' ' * 4),
    ])

def serialize_sig_and_docstring(dat):
    docstring = serialize_docstring(dat)
    if not docstring:
        return dat[0]
    return '\n'.join([
        dat[0],
        serialize_docstring(dat)
    ])

def serialize_docstring_and_body(dat):
    body = indent(dat[2], ' ' * 4)
    docstring = serialize_docstring(dat)
    if not docstring:
        return body
    return '\n'.join([
        serialize_docstring(dat),
        body
    ])

FOLD_MAP={
        'sig': serialize_sig,
        'docstring': serialize_docstring,
        'body': serialize_body,
        'sig_and_docstring': serialize_sig_and_docstring,
        'sig_and_body': serialize_sig_and_body,
        'docstring_and_body': serialize_docstring_and_body
}

def serialize_dat(dat):
    return {label: FOLD_MAP[label](dat) for label in FOLD_MAP}

datasets=('sig-docstring-body-features',)
serializers=(serialize_dat,)

if __name__ == '__main__':
    csn_dat = load_zip_json(JSON_GZ)
    dat = []  # put into format matching my own data
    failures = 0
    for d in csn_dat:
        try:
            for method in extract_function_definitions(d['code'])[0]:
                dat.append(method)
        except SyntaxError:
            failures += 1

    #NOTE: CSN data is already split so I will just
    # copy the name split_serialize_data would give it
    # and proceed with saving the serialized features
    with gzip.open(
            DATA_DIR/'python_test_0.test.sig-docstring-body-features.json.gz', 
            'wb'
        ) as fout:
        for d in dat:
            fout.write(
                    (json.dumps(serialize_dat(d)) + "\n").encode('utf-8')
            )

    #split_serialize_data(
    #        JSON_GZ, 
    #        CRAWLDIRS, 
    #        datasets=datasets,
    #        serializers=serializers,
    #        dir_suffix='split/multi-task-translation',
    #        keepempty=True  # so methods without docstrings will be included
    #)
