import os
#os.environ['RAYON_RS_NUM_CPUS'] = "24"  # parallel tokenize
from pathlib import Path
import logging
import argparse
from itertools import product

from athenadatapipeline.model.utils import FOLD_MAP, prepare
from athenadatapipeline.config import load_conf

LOGGER = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())

# strategy: have one training file with all examples, but 
# separate validation files for each 'task'

if __name__ == '__main__':
    args = parse_args()
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), args["conf_path"]
    )
    conf = load_conf(path_to_conf)

    DIRECTORY = Path(conf['split_features']['prefix']) / conf['split_features']['suffix']
    PREFIX = conf['fairseq_prepare']['prefix']
    DAWNDIR = Path(conf['fairseq_prepare']['vocabdir'])
    VOCAB_PREFIX = conf['fairseq_prepare']['vocabprefix']
    VOCAB = DAWNDIR / (VOCAB_PREFIX + '-vocab.json')
    MERGES = DAWNDIR / (VOCAB_PREFIX + '-merges.txt')

    DATA_FILES = [
            DIRECTORY / (PREFIX + f'.{sub}.{typ}.json.gz')
            for sub, typ in product(
                ['train', 'test', 'val'], ['sig-docstring-body-features']
            )
    ]

    FEATURES = list(FOLD_MAP.keys())
    VALID_NAME_MAP = {}
    TASKS = []
    for src in FEATURES:
        for tgt in FEATURES:
            src_set = set(src.split('_'))
            src_set.discard('and')
            tgt_set = set(tgt.split('_'))
            tgt_set.discard('and')
            # not very interested in producing signatures
            if not src_set.intersection(tgt_set) and not tgt_set == set(['sig']):
                TASKS.append((src, tgt))
                VALID_NAME_MAP[(src, tgt)] = '_to_'.join(
                        [''.join([l[0] for l in d_set]) for d_set in (src_set, tgt_set)]
                )
                LOGGER.info(f'Added task {src} -> {tgt}')

    LOGGER.info('Valid/test file abbreviations')
    for key, value in VALID_NAME_MAP.items():
        LOGGER.info(f'{key}: {value}')

    prepare(datafiles=DATA_FILES, 
        vocab=VOCAB, 
        merges=MERGES, 
        tasks=TASKS,
        valid_name_map=VALID_NAME_MAP,
        subdir=DIRECTORY,
        batch_size=conf['fairseq_prepare']['batch_size'])