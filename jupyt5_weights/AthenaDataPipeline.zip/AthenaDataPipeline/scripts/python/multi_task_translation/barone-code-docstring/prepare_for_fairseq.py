import os
#os.environ['RAYON_RS_NUM_CPUS'] = "24"  # parallel tokenize
from pathlib import Path
import logging
from contextlib import ExitStack
from itertools import product
from collections import defaultdict

from tqdm import tqdm
from textwrap import dedent
from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline import load_zip_json
from athenadatapipeline.classify_docstrings import get_class

from separate_features import FOLD_MAP

LOGGER = logging.getLogger(__name__)

DIRECTORY = Path('/home/coclemen/lib/code-docstring-corpus/parallel-corpus')
PREFIX = 'python_test_0'

DAWNDIR = Path('/smartml-athena/processed-data/fundef-docstrings/dawn-py-pretrained/forColin')
VOCAB_PREFIX = 'hacky_byte_level'
VOCAB = DAWNDIR / (VOCAB_PREFIX + '-vocab.json')
MERGES = DAWNDIR / (VOCAB_PREFIX + '-merges.txt')

DATA_FILES = [
        DIRECTORY / (PREFIX + f'.{sub}.{typ}.json.gz')
        for sub, typ in product(
            ['test'], ['sig-docstring-body-features']
        )
]

FEATURES = list(FOLD_MAP.keys())
VALID_NAME_MAP = {}
TASKS = []
for src in FEATURES:
    for tgt in FEATURES:
        src_set = set(src.split('_'))
        src_set.discard('and')
        tgt_set = set(tgt.split('_'))
        tgt_set.discard('and')
        # not very interested in producing signatures
        if not src_set.intersection(tgt_set) and not tgt_set == set(['sig']):
            TASKS.append((src, tgt))
            VALID_NAME_MAP[(src, tgt)] = '_to_'.join(
                    [''.join([l[0] for l in d_set]) for d_set in (src_set, tgt_set)]
            )
            LOGGER.info(f'Added task {src} -> {tgt}')

LOGGER.info('Valid/test file abbreviations')
for key, value in VALID_NAME_MAP.items():
    LOGGER.info(f'{key}: {value}')

# strategy: have one training file with all examples, but
# separate validation files for each 'task'

def decompress_name(filepath):
    nameparts = filepath.name.split('.')
    return '.'.join([n for n in nameparts if not n in ['json', 'gz']])

def prepare(
        datafiles=DATA_FILES,
        vocab=VOCAB,
        merges=MERGES,
        tasks=TASKS,
        valid_name_map=VALID_NAME_MAP,
        subdir='fairseq',
        batch_size=1,
    ):
    tokenizer = ByteLevelBPETokenizer(str(vocab), str(merges))

    for df in tqdm(datafiles, desc='Subset', position=1):
        LOGGER.info(f'Processing {df.name}')
        directory = df.parent / subdir
        if not directory.exists():
            directory.mkdir(parents=True)
        prefix = df.name.split('.')[0]

        with ExitStack() as stack:  # with open block for lists of files
            savestreams = dict()
            subset = df.name.split('.')[1]
            if subset == 'train':
                #NOTE: all features in one training set
                for lab in ('src', 'tgt'):
                    name = f'{prefix}.{subset}.{lab}'
                    savestreams[subset + lab] = stack.enter_context(
                            open(directory / name, 'w')
                    )
                    LOGGER.info(f'Opened {name} for writing')
            else:
                #NOTE: separate src, tgt test/valid files for each 'feature'
                for abbrev in valid_name_map.values():
                    for lab in ('src', 'tgt'):
                        subset_label = subset + '_' + abbrev
                        name = f'{prefix}.{subset_label}.{lab}'
                        savestreams[subset + abbrev + lab] = stack.enter_context(
                                open(directory / name, 'w')
                        )
                        LOGGER.info(f'Opened {name} for writing')

            savedict = defaultdict(list)  # save strings for batch tokenization
            for i, dat in enumerate(tqdm(load_zip_json(df), desc='Examples')):
                for (src_label, tgt_label), abbrev in valid_name_map.items():
                    src = dat[src_label]
                    tgt = dat[tgt_label]

                    # docstring skip task examples with missing docstrings
                    if 'docstring' in src_label + tgt_label:
                        if not dat['docstring']:
                            continue

                    tgt_imperative = f'# target {tgt_label} '
                    if 'docstring' in tgt_label:
                        docstring = dedent(dat['docstring']).replace('"""', '').strip()
                        style = get_class(docstring)
                        tgt_imperative += f'style {style}'

                    src = tgt_imperative + '\n' + src

                    for d, lab in zip([src, tgt], ['src', 'tgt']):
                        #NOTE: DAWN'S TOKENIZER REQUIRES THIS
                        d = d.replace('\n', 'NEWLINE')
                        key = subset + abbrev + lab
                        if subset == 'train':  # all features in one training set
                            key = subset + lab
                        savedict[key].append(d)

                # write results to disk periodically
                if i and i % batch_size == 0:
                    for key in savedict:
                        # parallel tokenization
                        for tok in tokenizer.encode_batch(savedict[key]):
                            savestreams[key].write(' '.join(tok.tokens) + '\n')
                    savedict = defaultdict(list)


if __name__ == '__main__':
    prepare()
