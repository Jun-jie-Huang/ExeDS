"""
split_separate_features.py

author: Colin Clement
date: 2020-04-15


"""

from pathlib import Path
import json
import gzip

from textwrap import indent, dedent

from athenadatapipeline import load_zip_json
from athenadatapipeline.splitdata import split_serialize_data, clean_docstring
from athenadatapipeline.classify_docstrings import get_class

from crawlercrawler.normalization import NORMALIZE_LABEL, normalize
from crawlercrawler.func_def_features import extract_function_definitions


def return_format(code):
    """Undo preprocessing of Barone et al data"""
    out_lines = []
    for line in code.split('DCNL'):
        out_lines.append('   '.join(line.split('DCSP ')))
    return '\n'.join(out_lines)


DATA_DIR = Path('/home/coclemen/lib/code-docstring-corpus/parallel-corpus')

def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == '\n':
        return f'"""\n{docstring}\n"""'
    else:
        return f'"""{docstring}"""'

def serialize_sig(dat):
    return dat[0]

def serialize_docstring(dat):
    if not dat[1]:  # empty docstring
        return dat[1]
    cleaned = clean_docstring(dat[1])
    if cleaned:
        return indent(code_format_docstring(cleaned), ' ' * 4)
    return cleaned  # emptied by cleaning

def serialize_body(dat):
    return indent(dat[2], ' ' * 4)

def serialize_sig_and_body(dat):
    return '\n'.join([
        dat[0],
        indent(dat[2], ' ' * 4),
    ])

def serialize_sig_and_docstring(dat):
    docstring = serialize_docstring(dat)
    if not docstring:
        return dat[0]
    return '\n'.join([
        dat[0],
        serialize_docstring(dat)
    ])

def serialize_docstring_and_body(dat):
    body = indent(dat[2], ' ' * 4)
    docstring = serialize_docstring(dat)
    if not docstring:
        return body
    return '\n'.join([
        serialize_docstring(dat),
        body
    ])

FOLD_MAP={
        'sig': serialize_sig,
        'docstring': serialize_docstring,
        'body': serialize_body,
        'sig_and_docstring': serialize_sig_and_docstring,
        'sig_and_body': serialize_sig_and_body,
        'docstring_and_body': serialize_docstring_and_body
}

def serialize_dat(dat):
    return {label: FOLD_MAP[label](dat) for label in FOLD_MAP}

datasets=('sig-docstring-body-features',)
serializers=(serialize_dat,)

if __name__ == '__main__':
    FEATURES = ['declarations', 'descriptions', 'bodies']
    barone_dat = {}
    for feature in FEATURES:
        with open(DATA_DIR / f'data_ps.{feature}.test') as fout:
            barone_dat[feature] = [return_format(line) for line in fout.readlines()]

    dat = []  # put into format matching my own data
    failures = 0
    for sig, doc, body in zip(*barone_dat.values()):
        method_str = '\n'.join([
            sig.strip(),
            indent(code_format_docstring(doc.strip(""" '" """).strip()), ' ' * 4),
            serialize_body(['', '', dedent(body)]),
        ])

        try:
            for method in extract_function_definitions(method_str)[0]:
                dat.append(method)
        except SyntaxError:
            failures += 1

    #NOTE: Barone data is already split so I will just
    # copy the name split_serialize_data would give it
    # and proceed with saving the serialized features
    with gzip.open(
            DATA_DIR/'python_test_0.test.sig-docstring-body-features.json.gz',
            'wb'
        ) as fout:
        for d in dat:
            fout.write(
                    (json.dumps(serialize_dat(d)) + "\n").encode('utf-8')
            )

    #split_serialize_data(
    #        JSON_GZ,
    #        CRAWLDIRS,
    #        datasets=datasets,
    #        serializers=serializers,
    #        dir_suffix='split/multi-task-translation',
    #        keepempty=True  # so methods without docstrings will be included
    #)
