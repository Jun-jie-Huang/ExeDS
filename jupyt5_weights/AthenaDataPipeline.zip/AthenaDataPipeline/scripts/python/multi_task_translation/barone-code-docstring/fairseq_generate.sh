

#export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"
export MODELDIR="/smartml-athena/processed-data/fundef-docstrings/split/multi-task-translation/fairseq"
export DATADIR="/home/coclemen/lib/code-docstring-corpus/parallel-corpus/fairseq"
export PREFIX="python_test_0"

export DIR="$DATADIR/binary"
export SAVEDIR="$MODELDIR/2020-04-17"

# sig -> doc
#export SUBSET="test"

# sig -> body
#export SUBSET="test1"

# sig + doc -> body
#export SUBSET="test7"

# sig + body -> doc
export SUBSET="test8"

export CUDA_VISIBLE_DEVICES=2
fairseq-generate $DIR \
    --path $SAVEDIR/checkpoint_best.pt \
    --gen-subset $SUBSET \
    --beam 5 \
    --max-tokens 3300 \
    --num-workers 2 \
    --skip-invalid-size-inputs-valid-test \
    --empty-cache-freq 1 \
    >> $SAVEDIR/generated-barone/generate-$SUBSET.txt
    #--results-path $SAVEDIR/generated-barone \
    #--batch-size 32 --beam 5 \
