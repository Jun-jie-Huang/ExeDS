#export DATADIR="/smartml-athena/processed-data/fundef-docstrings/split/multi-task-translation/fairseq"
export DATADIR="/home/coclemen/lib/code-docstring-corpus/parallel-corpus/fairseq"
export DAWNDIR="/smartml-athena/processed-data/fundef-docstrings/dawn-py-pretrained/forColin"
export PREFIX="python_test_0"

#    's_to_d'
declare -a SUFFIXLIST=(
    's_to_b'
    's_to_bd'
    'd_to_b'
    'd_to_sb'
    'b_to_d'
    'b_to_sd'
    'sd_to_b'
    'sb_to_d'
)

export VALIDPREF="$DATADIR/$PREFIX.val_s_to_d"
export TESTPREF="$DATADIR/$PREFIX.test_s_to_d"

for SUFFIX in "${SUFFIXLIST[@]}"
do
    export VALIDPREF="$VALIDPREF,$DATADIR/$PREFIX.val_$SUFFIX"
    echo "$DATADIR/$PREFIX.val_$SUFFIX"
    export TESTPREF="$TESTPREF,$DATADIR/$PREFIX.test_$SUFFIX"
    echo "$DATADIR/$PREFIX.test_$SUFFIX"
done

fairseq-preprocess \
    --source-lang 'src' \
    --target-lang 'tgt' \
    --testpref $TESTPREF \
    --destdir $DATADIR/binary \
    --workers 4 \
    --srcdict $DAWNDIR/use_this_one_dict.src.txt \
    --tgtdict $DAWNDIR/use_this_one_dict.src.txt \
    #--srcdict $DATADIR/binary/dict.methods.txt \
    #--tgtdict $DATADIR/binary/dict.docstring.txt \
    #--joined-dictionary \
