import os
import argparse
from pathlib import Path
from athenadatapipeline.tokenizer import train

from athenadatapipeline.config import load_conf

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())

if __name__ == '__main__':

    args = parse_args()
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), args["conf_path"]
    )
    conf = load_conf(path_to_conf)

    DIRECTORY = Path(conf['tokenizer']['prefix'])
    FILE_NAMES = [
            DIRECTORY / name for name in 
            [
                conf['tokenizer']['json_gz'],
            ]
    ]
    
    train(FILE_NAMES, conf['tokenizer']['size'])
