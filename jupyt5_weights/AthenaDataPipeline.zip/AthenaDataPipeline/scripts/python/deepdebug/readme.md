I (Dawn) built off of Colin's code and added support for skeletons that see the entire focal method, not just its signature or docstring or whatever. The main use case for me is for bugpatching, although we could also use this for unit-test generation, or maybe bug detection or something.

There's an example usage in the helpers.py file from [source-parser](https://devdiv.visualstudio.com/InternalTools/_git/source-parser):
```
from skeletonize.split_serialize import MethodContextCollater
MCC = MethodContextCollater(os.path.dirname(os.path.realpath(__file__)) + '/tokenizer_data/universal_tokenizer')
skel = MCC.skeletonize_schem_method(schem_focal_fun,
                                    schem_file,
                                    tok_budget=1023,
                                   )['sig+doc+body+context'][0]
```