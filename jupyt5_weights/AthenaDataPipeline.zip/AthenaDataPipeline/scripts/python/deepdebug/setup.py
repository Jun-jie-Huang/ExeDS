import setuptools

import os

setuptools.setup(
    name="skeletonize", 
    version="1.0.0",
    author="Microsoft",
    author_email="dawn.drain@microsoft.com",
    description="Colin has this code for create code skeletons for python files. I've added support for skeletons for editing tasks",
    long_description="Colin has this code for create code skeletons for python files. I've added support for skeletons for editing tasks",
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=['skeletonize'],
    py_modules = [],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    scripts=[],
    install_requires=['tokenizers'], 
)
