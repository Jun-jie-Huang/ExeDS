"""
split_serialize.py


"""

import os
import re
import argparse
from pathlib import Path
from itertools import chain, repeat, cycle, islice
from textwrap import indent

from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline.model.utils.python import format_docstring
from athenadatapipeline.model.utils.python.classify_docstrings import (
    get_class,
    is_template,
)
from athenadatapipeline.splitdata import split_serialize
from athenadatapipeline.collater import Collater
from athenadatapipeline.config import load_conf


def roundrobin(*iterables):
    """roundrobin('ABC', 'D', 'EF') --> A D E B F C
    Dawn's version makes the simplifying assumption that the iterables are all about the same length
    Waaaay better for long lists of iterables, since the original roundrobin is quadratic T.T
    and takes 20s *per function* for a large file with 20k functions
    """
    num_rounds = max([len(ible) for ible in iterables])
    for i in range(num_rounds):
        for ible in iterables:
            if i < len(ible):
                yield ible[i]

RE_DUNDER = re.compile('^__[A-Za-z0-9_]+__$')


class MethodContextCollater(Collater):
    """
    This collater reads a single Python source file
    processed into a source-parser schema, finds all
    methods and class methods, and for each it produces
    the 6 strings described in dataset_labels.
        source -> target
        "sig+doc+context" -> "body"
        "sig+body+context" -> "doc"
        "doc+context" -> "sig+body"
    Here, sig = method signature, doc = method docstring,
    body = method body, and context is a combination of file-level
    features which depend on the focal method and the lengths of
    each feature and the token_budget of the target model (usually 1023
    tokens).

    The context is formed by a scoped priority, subject to the
    token budget. After the focal method's own source features
    (including class definition and class attributes if present
    for a class method) we then try to add import statements,
    global assignments, and then loop over every other method in
    the file, first adding signatures, then docstrings, and finally
    if budget allows, code bodies. The final feature added may be
    truncated in-scope to fill the token budget.
    """

    _dataset_labels = (
        "sig+doc+context",  # -> target body
        "sig+body+context",  # -> target doc
        "doc+context",  # -> target sig+body
        "body",
        "doc",
        "sig+body",
        "sig+doc+body+context",
    )

    source_labels = (
        "sig+doc+context",  # -> target body
        "sig+body+context",  # -> target doc
        "doc+context",  # -> target sig+body
        "sig+doc+body+context", # target edit (or unit test, or bug label etc...)
    )
    target_labels = (
        "body",
        "doc",
        "sig+body",
        "body"
    )
    task_label = "context-method-docstring"

    # key - source_labels, value - imperatives
    imperative_templates = {
        "sig+doc+context": "# target body",
        "sig+body+context": "# target doc",
        "doc+context": "# target sig+body",
        "sig+doc+body+context": "# target edit",
    }

    def __init__(
        self, tokenizer_prefix, model_width=1024, method_per_file_limit=200,
    ):
        """
        Parameters
        ----------
        tokenizer_prefix : str
            prefix for tokenizer vocab and merges files
        (optional)
        model_width : int
            the number of tokens allowed in the input/output of the target model
        method_per_file_limit : int
            the maximum number of methods and class methods per file,
            files with greater than this number of methods will be ignored
        """
        super().__init__(tokenizer_prefix)
        # fairseq models add at most 3 control tokens
        assert model_width > 3
        self.token_budget = model_width - 3
        self.method_per_file_limit = method_per_file_limit

    @staticmethod
    def num_methods(file_dict):
        n = len(file_dict['methods'])
        for clss in file_dict['classes']:
            n += len(clss['methods'])
        return n

    @staticmethod
    def get_imports_globals(file_dict, include_dunders=False):
        imports = []
        globes = []

        for ctx in file_dict["contexts"]:
            first = ctx.split()[0]
            if first == 'import' or first == 'from':
                imports.append(ctx)
            # double unders often include spurious license info
            elif include_dunders or not RE_DUNDER.match(first):
                globes.append({  # giving the same feature labels as methods
                    'signature': '\n' + first,
                    'docstring': '',
                    'body': ' '.join(ctx.split()[1:])
                })
        if imports:
            imports.extend([""] * 2)  # to get an extra newline nicely
        if globes:
            globes.append({  # add an empty line after
                    'signature': '\n\n', 'docstring': '', 'body': '',
            })

        return "\n".join(imports), globes

    def schem_method_index(self,focal_method,file_dict):
        """
        Used for indexing into collated
        e.g. index = mcc.schem_method_index(focal_method,file_dict)
             focal_skeleton = collated['sig+doc+body+context'][index]"""
        def get_methods_with_indicies(file_dict):
            """Loop in the same order as in get_mapped_tokenization"""
            _, globes = self.get_imports_globals(file_dict)
            index = len(globes)
            res = []
            for method in file_dict["methods"]:
                if not method["body"].strip().strip('pas'):
                    continue
                res.append((method,index))
                index += 1
            for cls in file_dict["classes"]:
                if not cls['methods']:
                    res.append((cls,index))
                    index += 1
                else:
                    for method in cls['methods']:
                        res.append((method,index))
                        index += 1
            return res
        for method,index in get_methods_with_indicies(file_dict):
            if self.schematized_methods_are_equal(method,focal_method):
                return index
        import pdb; pdb.set_trace()
    
    def get_mapped_tokenization(self, file_dict, indent_str="    "):
        """
        Tokenize the scoped structures of the file and record
        a mapping from file_dict positions to elements of the tokenized
        structures.
        """
        index_map = {"imports": 0}
        imports, globes = self.get_imports_globals(file_dict)
        features = [imports]
        methods = []  # also global assignments and class methods and empty methods

        # global variables are priority 0, they values are priority 2
        for i, globe in enumerate(globes):
            feature_map = {
                "signature": ("globals", i, "signature"),
                "docstring": ("globals", i, "docstring"),  # always empty!
                "body": ("globals", i, "body"),
            }
            for feat in feature_map:
                features.append(globe[feat])
                index_map[feature_map[feat]] = len(index_map)
            methods.append(feature_map)

        for i, method in enumerate(file_dict["methods"]):
            feature_map = {
                "signature": ("methods", i, "signature"),
                "docstring": ("methods", i, "docstring"),
                "body": ("methods", i, "body"),
                "endtarget": ("methods", i, "endtarget"),
            }
            for source_label in self.imperative_templates:
                feature_map[source_label] = ("methods", i, source_label)

            signature = method["signature"] + "\n"

            docstring = ""
            doc_imperative = self.imperative_templates["sig+body+context"]
            if method["docstring"].strip():
                style = get_class(method["docstring"])
                doc_imperative += " style {}".format(style)
                if is_template(method["docstring"], style=style):
                    doc_imperative += " template"
                docstring = format_docstring(method["docstring"]) + "\n"

            body = ""
            if method["body"].strip().strip('pas'):  # ignore pass bodies
                body = indent(method["body"], indent_str) + "\n\n"
            if not body:  # do not keep methods with empty bodies
                continue

            # imperatives
            features.append("\n" + self.imperative_templates["sig+doc+context"] + "\n")
            index_map[("methods", i, "sig+doc+context")] = len(index_map)
            # predict docstring from sig+body+context has style+template imperative
            features.append("\n" + doc_imperative + "\n")
            index_map[("methods", i, "sig+body+context")] = len(index_map)
            features.append("\n" + self.imperative_templates["doc+context"] + "\n")
            index_map[("methods", i, "doc+context")] = len(index_map)
            features.append("\n" + self.imperative_templates["sig+doc+body+context"] + "\n")
            index_map[("methods", i, "sig+doc+body+context")] = len(index_map)

            # method features
            features.append(signature)
            index_map[feature_map["signature"]] = len(index_map)
            features.append(docstring)
            index_map[feature_map["docstring"]] = len(index_map)
            features.append(body)
            index_map[feature_map["body"]] = len(index_map)

            features.append("# end\n\n")
            index_map[feature_map["endtarget"]] = len(index_map)

            methods.append(feature_map)

        classes = []
        for i, class_node in enumerate(file_dict["classes"]):

            index_map[("classes", i, "definition")] = len(index_map)
            features.append('\n' + class_node["definition"] + "\n")

            index_map[("classes", i, "class_docstring")] = len(index_map)
            if class_node["class_docstring"].strip():
                features.append(format_docstring(class_node["class_docstring"]) + "\n")
            else:
                features.append("")

            if "attribute_expressions" in class_node["attributes"]:
                for j, expression in enumerate(
                    class_node["attributes"]["attribute_expressions"]
                ):
                    index_map[
                        ("classes", i, "attributes", "attribute_expressions", j)
                    ] = len(index_map)

                    features.append(indent(expression, indent_str) + "\n")

            if "classes" in class_node["attributes"]:
                for j, cls_node in enumerate(class_node["attributes"]["classes"]):
                    index_map[("classes", i, "attributes", "classes", j)] = len(
                        index_map
                    )
                    # NOTE:  just using the whole class within a class
                    features.append(cls_node["original_string"] + "\n")

            # empty method if class has no methods, so we can still get its context
            if not class_node["methods"]:
                feature_map = {
                    "signature": ("classes", i, "methods", 0, "signature"),
                    "docstring": ("classes", i, "methods", 0, "docstring"),
                    "body": ("classes", i, "methods", 0, "body"),
                }  # no 'endtarget' signals this is a placeholder for downstream
                for key in feature_map.values():
                    features.append('')
                    index_map[key] = len(index_map)
                methods.append(feature_map)

            for j, method in enumerate(class_node["methods"]):
                feature_map = {
                    "signature": ("classes", i, "methods", j, "signature"),
                    "docstring": ("classes", i, "methods", j, "docstring"),
                    "body": ("classes", i, "methods", j, "body"),
                    "endtarget": ("classes", i, "methods", j, "endtarget"),
                }
                for source_label in self.imperative_templates:
                    feature_map[source_label] = (
                        "classes",
                        i,
                        "methods",
                        j,
                        source_label,
                    )

                signature = indent(method["signature"] + "\n", indent_str) #method["signature"] + "\n"

                docstring = ""
                doc_imperative = self.imperative_templates["sig+body+context"]
                if method["docstring"].strip():
                    style = get_class(method["docstring"])
                    doc_imperative += " style {}".format(style)
                    if is_template(method["docstring"], style=style):
                        doc_imperative += " template"
                    docstring = (
                        format_docstring(method["docstring"], n_indents=8) + "\n"
                    )

                body = ""
                if method["body"].strip():
                    body = indent(method["body"], indent_str * 2) + "\n\n"

                # imperatives
                features.append(
                    "\n" + indent_str + self.imperative_templates["sig+doc+context"] + "\n"
                )
                index_map[("classes", i, "methods", j, "sig+doc+context")] = len(
                    index_map
                )
                # predict docstring from sig+body+context has style+template imperative
                features.append("\n" + indent_str + doc_imperative + "\n")
                index_map[("classes", i, "methods", j, "sig+body+context")] = len(
                    index_map
                )
                features.append(
                    "\n" + indent_str + self.imperative_templates["doc+context"] + "\n"
                )
                index_map[("classes", i, "methods", j, "doc+context")] = len(index_map)
                features.append(
                    "\n" + indent_str + self.imperative_templates["sig+doc+body+context"] + "\n"
                )
                index_map[("classes", i, "methods", j, "sig+doc+body+context")] = len(
                    index_map
                )

                # method features
                features.append(signature)
                index_map[feature_map["signature"]] = len(index_map)
                features.append(docstring)
                index_map[feature_map["docstring"]] = len(index_map)
                features.append(body)
                index_map[feature_map["body"]] = len(index_map)

                features.append("    # end\n\n")
                index_map[feature_map["endtarget"]] = len(index_map)

                methods.append(feature_map)

        tokenized_features = [
            enc.tokens for enc in self.tokenizer.encode_batch(features)
        ]

        return tokenized_features, methods, index_map


    def collate_method(self,focal_method,file_dict,interim_features=None,collated=None,tok_budget=None):
        
        if interim_features is None:
            interim_features = self.get_interim_features(file_dict)
        tokenized_features = interim_features['tokenized_features']
        features = interim_features['features']
        methods = interim_features['methods']
        index_map = interim_features['index_map']
        num_tokens_per = interim_features['features']
        num_tokens_per = interim_features['num_tokens_per']

        if 'endtarget' not in focal_method:
            return  # skip placeholder methods for focal method

        if tok_budget is None:
            tok_budget = self.token_budget
        budgets = {label: tok_budget for label in self.datasets}
        focal_collated = {label: [] for label in self.datasets}
        def_classes = {  # key - class number, val - priority set
            label: {} for label in self.datasets
        }

        # craft targets
        for label, feat in zip(
            ["body", "doc", "sig+body",],
            [("body",), ("docstring",), ("signature", "body")],
        ):
            self.update(
                focal_collated,
                label,
                budgets,
                num_tokens_per,
                *self.get_method_indices(focal_method,index_map, *feat)
            )

        # craft sources
        for label, feat in zip(
            ["sig+doc+context", "sig+body+context", "doc+context","sig+doc+body+context"],
            [("signature", "docstring"), ("signature", "body"), ("docstring",), ("signature", "docstring", "body")],
        ):
            # priority -1 imperative!
            self.update(focal_collated, label, budgets, num_tokens_per, index_map[focal_method[label]])

            # priority 0 class definition for class methods
            if focal_method["signature"][0] == "classes":
                class_i = focal_method["signature"][1]
                if not class_i in def_classes[label]:
                    def_classes[label][class_i] = 0  # set priority 0
                    def_ind = index_map[("classes", class_i, "definition")]
                    self.update(focal_collated, label, budgets, num_tokens_per, def_ind)

            # priority 0 focal method source features
            feat_ind = self.get_method_indices(focal_method, index_map, *feat)
            self.update(focal_collated, label, budgets, num_tokens_per, *feat_ind)
            self.update(
                focal_collated, label, budgets, num_tokens_per, index_map[focal_method["endtarget"]]
            )

            # priority 1 add imports
            self.update(focal_collated, label, budgets, num_tokens_per, 0)

            # priority 2 class docstring and attributes
            if focal_method["signature"][0] == "classes":
                class_i = focal_method["signature"][1]
                if def_classes[label][class_i] < 2:  # doc/attr not set
                    def_classes[label][class_i] = 2

                doc_ind = index_map[("classes", class_i, "class_docstring")]
                self.update(focal_collated, label, budgets, num_tokens_per, doc_ind)

                for attr_ind in [
                    index_map[attr] for attr in self.get_class_attrs(class_i,file_dict)
                ]:
                    self.update(focal_collated, label, budgets, num_tokens_per, attr_ind)

        # priority 4, 5, 6: global variables, non-focal method definitions, docstrings, bodies
        # global values are same priority as method bodies
        for method_feature in roundrobin(*features):

            if method_feature in focal_method.values():
                continue  # do not repeat focal method features

            for label in self.source_labels:
                if method_feature[0] == "classes":
                    class_i = method_feature[1]
                    if not class_i in def_classes[label]:
                        def_classes[label][class_i] = 0  # set priority 0
                        def_ind = index_map[("classes", class_i, "definition")]
                        self.update(focal_collated, label, budgets, num_tokens_per, def_ind)

                self.update(focal_collated, label, budgets, num_tokens_per, index_map[method_feature])

                if method_feature[0] == "classes":
                    class_i = method_feature[1]
                    if def_classes[label][class_i] < 2:
                        def_classes[label][class_i] = 2
                        doc_ind = index_map[("classes", class_i, "class_docstring")]
                        self.update(focal_collated, label, budgets, num_tokens_per, doc_ind)
                        
                       
        def append_to_collated(collated,focal_collated,tokenized_features,budgets):
            for src_tgt_labels in zip(self.source_labels, self.target_labels):
                src_tgt = []
                for label in src_tgt_labels:
                    truncated = [tokenized_features[feat] for feat in focal_collated[label]]
                    if budgets[label] < 0:  # truncate last added feature
                        truncated[-1] = truncated[-1][: budgets[label]]
                    src_tgt.append(
                        " ".join(
                            [
                                token
                                for k in sorted(  # argsort
                                    range(len(focal_collated[label])),
                                    key=lambda l: focal_collated[label][l],
                                )
                                for token in truncated[k]
                            ]
                        )
                    )

                for seq, label in zip(src_tgt, src_tgt_labels):
                    collated[label].append(seq)
        if collated is not None:
            append_to_collated(collated,focal_collated,tokenized_features,budgets)
        
        collated_focal_only = {label: [] for label in self.datasets}
        append_to_collated(collated_focal_only,focal_collated,tokenized_features,budgets)
        return collated_focal_only
    
    def get_method_indices(self,focal,index_map, *args):
        return [index_map[focal[typ]] for typ in args]

    def get_features(self,methods):
        return [
            [method[feat] for feat in ("signature", "docstring", "body")]
            for method in methods
        ]

    def get_class_attrs(self,class_i,file_dict):
        class_node = file_dict["classes"][class_i]
        if "attribute_expressions" in class_node["attributes"]:
            return [
                ("classes", class_i, "attributes", "attribute_expressions", j)
                for j, expression in enumerate(
                    class_node["attributes"]["attribute_expressions"]
                )
            ]
        return []

    def update(self,collated, label, budgets, num_tokens_per, *indicies):
        for index in indicies:
            # go over budget then truncate later
            if budgets[label] > 0:  # num_tokens_per[index]:
                collated[label].append(index)
                budgets[label] -= num_tokens_per[index]
                
    
    def _collate(self, file_dict):
        """
        Priorities:
            0 - focal method features ( + class def/doc)
            1 - imports
            2 - class docstring and attributes
            3 - global variables and method signatures
            4 - method docstrings
            5 - global assignments and method bodies
        """
        collated = {label: [] for label in self.datasets}
        if 'url' in file_dict:
            collated['url'] = file_dict['url']
        if self.num_methods(file_dict) > self.method_per_file_limit:
            return collated
        interim_features = self.get_interim_features(file_dict)
        methods = interim_features['methods']
        for focal_method in methods:
            focal_collated = self.collate_method(focal_method,file_dict,interim_features,collated)

        return collated
    
    def get_interim_features(self,file_dict,indent_str="    "):
        tokenized_features, methods, index_map = self.get_mapped_tokenization(file_dict,indent_str=indent_str)
        num_tokens_per = list(map(len, tokenized_features))
        features = self.get_features(methods)
        return {'tokenized_features':tokenized_features,'methods':methods,'index_map':index_map,
                'num_tokens_per':num_tokens_per,'features':features}
    
    def skeletonize_schem_method(self,focal_method,file_dict,interim_features=None,tok_budget=None,indent_str="    "):
        focal_index = self.schem_method_index(focal_method,file_dict)
        if interim_features is None:
            interim_features = self.get_interim_features(file_dict,indent_str=indent_str)
        focal_method = interim_features['methods'][focal_index]
        return self.collate_method(focal_method,file_dict,interim_features=interim_features,tok_budget=tok_budget)

    def schematized_methods_are_equal(self,schematized_method1,schematized_method2):
        #in future will want to add a line number check
        if schematized_method1['original_string'] == schematized_method2['original_string']:
            return True
        else:
            return False   
