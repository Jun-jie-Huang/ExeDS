from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json

from rouge import Rouge
rouge = Rouge()


import glob
import sys



path = sys.argv[1]
output_path = sys.argv[1] + ".out" 
print(path)
print(output_path)

with open(path, "r") as f:
    js = json.loads(f.readline())
    with open(output_path, "w") as fout:
        scores = Rouge().get_scores(js[0],js[1])[0]
        #fout.write(json.dumps("this object"))
        fout.write(json.dumps(scores))
        



#files = glob.glob("/tufanodata/jotimc/manual/docstring/*.json")

# print(files)

# for file in files:
#     with open(file, "r") as f:
#         js = json.loads(f.readline())
#         scores = Rouge().get_scores('\n'.join(hyps_sub), '\n'.join(refs_sub))[0]