python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_english.methods.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_english.docstrings.json"


# for CSN
python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_COMBINED.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_COMBINED.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/manual/csn_docstrings+hyp_thin_1_par_COMBINED.json"

python scripts/compute_bleu.py \
    --plain-text "/tufanodata/jotimc/manual/csn_docstrings+hyp_english_thin_1_par_COMBINED.json"