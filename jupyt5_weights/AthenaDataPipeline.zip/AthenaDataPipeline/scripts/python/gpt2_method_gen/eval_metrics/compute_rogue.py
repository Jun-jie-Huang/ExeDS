from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json

import sys
import numpy as np
import argparse
from rouge import Rouge

parser = argparse.ArgumentParser()
parser.add_argument(
    "--plain-text",
    type=str,
    default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json",
    help="plain text json lines"
)
parser.add_argument(
    "--output-path",
    type=str,
    default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_ROUGE_1024.docstrings.json",
    help="rouge score json output"
)
cli_args = vars(parser.parse_args())
print(cli_args)
PLAIN_TEXT = cli_args["plain_text"]
OUTPUT_PATH = cli_args["output_path"]

N_TRIALS = 14


# load jsons
with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()

jsons = []
for i, line in enumerate(lines):
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)
print(len(jsons))


# === colin-style 4096 concat "document" rouge ===
np.random.seed(9391)
refs, hyps = [], []
for js in jsons:
    src = js[0]
    tgt = js[1]
    
    full_gen = js[8]
    gen = full_gen[len(src):]

    if len(tgt) > 0 and len(gen) > 0:
        refs.append(tgt)
        hyps.append(gen)
print(len(refs))
print(len(hyps))


# build data folds
doc_size = 1024
indices = np.random.permutation(len(refs))
hyps_refs_list = []
for i in range(0,len(refs), doc_size):
    # if i > 1000:
    #      continue
    indices_sub = indices[i:i+doc_size]
    if len(indices_sub) == doc_size:
        #from rouge import Rouge
        hyps_sub = [ hyps[index] for index in indices_sub ]
        refs_sub = [ refs[index] for index in indices_sub ]
        hyps_refs_list.append(['\n'.join(hyps_sub), '\n'.join(refs_sub)])
        #scores = Rouge().get_scores('\n'.join(hyps_sub), '\n'.join(refs_sub))[0]
        #print(scores)
        print(i)
        print(len(refs_sub))
        print(len(hyps_sub))
    else:
        continue
    
print(len(hyps_refs_list))
hyps_refs_list = hyps_refs_list[:N_TRIALS] # only take the first 12
print(len(hyps_refs_list))

def get_rouge(hyps_refs_sub):
    print(len(hyps_refs_sub[0]))
    try:
        scores = Rouge().get_scores(*hyps_refs_sub)[0]
    except:
        return None
    return scores

### in-python multiprocess
from multiprocessing import Pool
#from collections import defaultdict
#pool = Pool()
#results_dict = defaultdict(list)
rs = None
with Pool(processes=N_TRIALS) as pool:
    print("running pool")
    rs = pool.map(get_rouge, hyps_refs_list)
    print("done running pool")

rs2 = []
for r in rs:
    if r is not None:
        rs2.append(r)
rs = rs2
#rs = [ r for r in pool.map(get_rouge, hyps_refs_list)]
print("print rs next")
print("rs = ", rs, "\n")

def flatten_dict(results):
    flatdict = {}
    for metric in ('rouge-1', 'rouge-2', 'rouge-l'):
        flatdict[metric] = {}
        for stat in ('f', 'p', 'r'):
            flatdict[metric][stat] = []
            for r in results:
                flatdict[metric][stat].append(r[metric][stat])
    return flatdict

rs_flat = flatten_dict(rs)

def mean_std_dict(results):
    meandict = {}
    stddict = {}
    for metric in results:
        meandict[metric] = {}
        stddict[metric] = {}
        for stat in results[metric]:
            meandict[metric][stat] = np.mean(results[metric][stat])
            stddict[metric][stat] = np.std(results[metric][stat])
    return meandict, stddict

mean_std_rs = mean_std_dict(rs_flat)

print("mean, std = ",mean_std_rs, "\n")

with open(OUTPUT_PATH, "w") as f:
    f.write("mean, std = " + str(mean_std_rs) + "\n")
    f.write("rs = " + str(rs) + "\n")
    f.write("\n\n json \n\n")
    f.write(json.dumps([mean_std_rs, rs]))

print("done")

