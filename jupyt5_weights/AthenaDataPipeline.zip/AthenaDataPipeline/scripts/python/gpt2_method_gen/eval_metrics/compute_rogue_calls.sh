
python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json" \
    --output-path "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_ROUGE_1024.methods.json"


python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_english.methods.json" \
    --output-path "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_english_ROUGE_1024.methods.json"



python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json" \
    --output-path "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_ROUGE_1024.docstrings.json"


python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_english.docstrings.json" \
    --output-path "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_english_ROUGE_1024.docstrings.json"









# === for CSN ===

python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_COMBINED.json" \
    --output-path "/tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_COMBINED_ROUGE_1024.json"

python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_COMBINED.json" \
    --output-path "/tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_COMBINED_ROUGE_1024.json"



python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/manual/csn_docstrings+hyp_thin_1_par_COMBINED.json" \
    --output-path "/tufanodata/jotimc/manual/csn_docstrings+hyp_thin_1_par_COMBINED_ROUGE_1024.json"

python scripts/compute_rogue.py \
    --plain-text "/tufanodata/jotimc/manual/csn_docstrings+hyp_english_thin_1_par_COMBINED.json" \
    --output-path "/tufanodata/jotimc/manual/csn_docstrings+hyp_english_thin_1_par_COMBINED_ROUGE_1024.json"

