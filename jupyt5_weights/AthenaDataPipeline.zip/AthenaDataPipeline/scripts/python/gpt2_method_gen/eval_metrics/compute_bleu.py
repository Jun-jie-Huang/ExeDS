from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json

import sys
import numpy as np
import argparse
from rouge import Rouge

parser = argparse.ArgumentParser()
parser.add_argument(
    "--plain-text",
    type=str,
    default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json",
    #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json",
    help="plain text json lines"
)
cli_args = vars(parser.parse_args())
print(cli_args)
PLAIN_TEXT = cli_args["plain_text"]


with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()

jsons = []
for i, line in enumerate(lines):
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)
print(len(jsons))

refs, hyps = [], []
for js in jsons:
    src = js[0]
    tgt = js[1]
    
    full_gen = js[8]
    gen = full_gen[len(src):]

    if len(tgt) > 4 and len(gen) > 4:
        refs.append(tgt)
        hyps.append(gen)
print(len(refs))

# === new compute bleu ===
refs_split = list(map(lambda s: [s.split(),], refs))
hyps_split = list(map(lambda s: s.split(), hyps))

b = bleu_score.corpus_bleu(refs_split, hyps_split)
print("bleu = ", b)

# max_index = 90000
# b = bleu_score.corpus_bleu(refs_split[:max_index], hyps_split[:max_index])
# print("bleu = ", b)