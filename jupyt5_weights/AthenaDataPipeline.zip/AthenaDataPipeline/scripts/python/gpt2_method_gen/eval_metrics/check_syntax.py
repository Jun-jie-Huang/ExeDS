from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json

import sys
import numpy as np
import argparse
from rouge import Rouge

parser = argparse.ArgumentParser()
parser.add_argument(
    "--plain-text",
    type=str,
    default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json",
    #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json",
    help="plain text json lines"
)
cli_args = vars(parser.parse_args())
print(cli_args)
PLAIN_TEXT = cli_args["plain_text"]


with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()

jsons = []
for i, line in enumerate(lines):
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)
print(len(jsons))


import ast
def check_syntax(method):
    try:
        ast.parse(method)
        return True
    except SyntaxError:
        return False

cc_count = 0
for i, js in enumerate(jsons):
    code = js[8]
    cc = False
    try:
        cc = check_syntax(code)
    except:
        print("failure")
        #print(code)
    # print(js[8])
    # print(cc)
    if cc:
        cc_count += 1
    #break
    #print(i, cc)
cc_mean = cc_count / len(jsons)
print("fraction syntax correct = ", cc_mean)
    
# def make_hyp(src_hyp_tgt):
#     src, hyp, tgt = src_hyp_tgt
#     return '\n'.join([src, hyp])
# syntactic = [check_syntax(make_hyp(d)) for d in dat_sig_doc_to_body]

