python scripts/check_syntax.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json"

python scripts/check_syntax.py \
    --plain-text "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_english.methods.json"

# for CSN
python scripts/check_syntax.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_COMBINED.json"

python scripts/check_syntax.py \
    --plain-text "/tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_COMBINED.json"