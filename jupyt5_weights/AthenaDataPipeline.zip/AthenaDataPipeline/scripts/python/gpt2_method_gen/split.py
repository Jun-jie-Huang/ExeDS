"""
split_separate_features.py

author: Colin Clement
date: 2020-04-15


"""

from pathlib import Path

from textwrap import indent

from athenadatapipeline.splitdata import split_serialize_data, clean_docstring

# DATA_DIR = Path("/smartml-athena/processed-data/fundef-docstrings/")
# JSON_GZ = DATA_DIR / "python-func-def-docstrings-2020-03-04-2336.json.gz"
DATA_DIR = Path("/tufanodata/jotimc/gpt2experiment_sync/")
JSON_GZ = DATA_DIR / "python-func-def-docstrings-2020-03-04-2336.json.gz"
# must manually create "split/gpt2-method-gen" directory

CRAWLDIRS = [
    "/smartml-athena/src-data/python/ziBjatNZRky2slnfFbZg2A/Git/1.0/",
    "/smartml-athena/all-git-repos",
    "/bigdata/git-repos/python",
]


def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == "\n":
        return f'"""\n{docstring}\n"""'
    return f'"""{docstring}"""'


def serialize_docstring(dat):
    if not dat[1]:  # empty docstring
        return dat[1]
    cleaned = clean_docstring(dat[1])
    if cleaned:
        return indent(code_format_docstring(cleaned), " " * 4)
    return cleaned  # emptied by cleaning

def serialize_docstring_target(dat):
    """ for signature + body => docstring training """
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    #print(docstring)
    #import pdb; pdb.set_trace()
    return "\n".join([dat[0], body , docstring,])

def serialize_method(dat):
    """ for signature + docstring => method training """
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    if not docstring:
        return "\n".join([dat[0], body])
    return "\n".join([dat[0], docstring, body])
def serialize_method_eval_tuple(dat):
    """ for signature + docstring => method testing """
    # copied from serialize_method
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    src = "\n".join([dat[0], docstring])
    tgt = body
    return [src, tgt, dat[0], docstring, body, dat[0], dat[1], dat[2]] # keep the raw for easy processes downstream (if needed)

def serialize_docstring_eval_tuple(dat):
    # copied from serialize_docstring_target
    """ for signature + body => docstring testing """
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    #print(docstring)
    #import pdb; pdb.set_trace()
    src = "\n".join([dat[0], body,])
    tgt = docstring
    return [src, tgt, dat[0], docstring, body, dat[0], dat[1], dat[2]] # keep the raw for easy processes downstream (if needed)


# datasets = ("methods","docstrings",)
# serializers = (serialize_method, serialize_docstring_target,)



# datasets = ("docstrings",)
# serializers = (serialize_docstring_target,)

# if __name__ == '__main__':
#     split_serialize_data(
#         JSON_GZ,
#         CRAWLDIRS,
#         datasets=datasets,
#         serializers=serializers,
#         dir_suffix="split/gpt2-method-gen",
#         # keepempty=True,  # so methods without docstrings will be included
#         keepempty=False, # for signature + body => docstring training
#         #head=100,
#     )


# method gen test set
# datasets = ("methods",)
# serializers = (serialize_method_eval_tuple,)

# if __name__ == '__main__':
#     split_serialize_data(
#         JSON_GZ,
#         CRAWLDIRS,
#         datasets=datasets,
#         serializers=serializers,
#         dir_suffix="split/gpt2-method-gen-eval",
#         keepempty=True,  # so methods without docstrings will be included
#         #head=10,
#     )

# just for python interactive
# from athenadatapipeline import load_zip_json
# import gzip
# import json

# dat = load_zip_json("/home/jotimc/test.csn_python_methods.json.gz")
# with gzip.open("/tufanodata/jotimc/manual/csn_docstrings.json.gz", "wb") as fout:
#     for d in dat:
#         fout.write(
#             (json.dumps(serialize_docstring_eval_tuple(d)) + "\n").encode("utf-8")
#             )

# with gzip.open("/tufanodata/jotimc/manual/csn_methods.json.gz", "wb") as fout:
#     for d in dat:
#         fout.write(
#             (json.dumps(serialize_method_eval_tuple(d)) + "\n").encode("utf-8")
#             )


# docstring gen test set
datasets = ("docstrings",)
serializers = (serialize_docstring_eval_tuple,)

if __name__ == '__main__':
    split_serialize_data(
        JSON_GZ,
        CRAWLDIRS,
        datasets=datasets,
        serializers=serializers,
        dir_suffix="split/gpt2-method-gen-eval",
        keepempty=False, 
        #head=10,
    )