from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json


# === LOAD ===

#lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_checkpoint.methods.json.gz")
# with open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp.methods.json", "r") as f:
#      lines = f.readlines()

PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_2.methods.json"
with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()
    #for line in lines:
    #    line = json.loads(line)
    #lines = json.load(f)
    #missing json load

jsons = []
for i, line in enumerate(lines):
    #print(i)
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)


# === look at train ===
lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/python-func-def-docstrings-2020-03-04-2336.test.docstrings.json.gz")

lines[0]

lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test.methods.json.gz")

lines[0]

lines = load_zip_json("/home/jotimc/mycontainer/jotimc/gpt2experiment/split/gpt2-method-gen/python-func-def-docstrings-2020-03-04-2336.test.methods.json.gz")

lines[1]

# === look at progress with zcat === 
import os
#GZ_FILE = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json.gz"

# GZ_FILE = "/data/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10.methods.json.gz"
# PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json"

GZ_FILE = "/data/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_english.methods.json.gz"
PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test_english.methods.json"
os.system(f'zcat {GZ_FILE} > {PLAIN_TEXT}')

with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()

jsons = []
for i, line in enumerate(lines):
    #print(i)
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)