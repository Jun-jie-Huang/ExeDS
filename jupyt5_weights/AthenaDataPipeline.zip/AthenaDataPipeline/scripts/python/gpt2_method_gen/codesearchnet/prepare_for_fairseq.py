from pathlib import Path
import logging
from itertools import product
from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline import load_zip_json

LOGGER = logging.getLogger(__name__)

DATA_DIR = Path("/smartml-athena/processed-data/fundef-docstrings/")
DIRECTORY = DATA_DIR / 'split/gpt2-method-gen'
PREFIX = 'python-func-def-docstrings-2020-03-04-2336'

VOCAB_PREFIX = 'python-func-def-docstrings-2020-02-21-2026'
VOCAB = DIRECTORY / (VOCAB_PREFIX + '_bytelevelbpe_30000-vocab.json')
MERGES = DIRECTORY / (VOCAB_PREFIX + '_bytelevelbpe_30000-merges.txt')

DATA_FILES = [
        DIRECTORY / (PREFIX + f'.{sub}.{typ}.json.gz')
        for typ, sub in product(['methods'], ['train', 'test', 'val'])
]

def decompress_name(filepath):
    nameparts = filepath.name.split('.')
    return '.'.join([n for n in nameparts if not n in ['json', 'gz']])

def prepare(datafiles=DATA_FILES, vocab=VOCAB, merges=MERGES, subdir='fairseq'):
    tokenizer = ByteLevelBPETokenizer(str(vocab), str(merges))
    for df in datafiles:
        directory = df.parent / subdir
        if not directory.exists():
            directory.mkdir()

        newfile = directory / decompress_name(df)
        with newfile.open('w') as fout:
            for d in load_zip_json(df):
                fout.write(
                        ' '.join(tokenizer.encode(d).tokens) + '\n'
                )

if __name__ == '__main__':
    prepare()
