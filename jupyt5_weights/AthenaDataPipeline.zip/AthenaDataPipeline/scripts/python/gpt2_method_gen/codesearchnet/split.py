"""
split_separate_features.py

author: Colin Clement
date: 2020-04-15


"""

from pathlib import Path
import json
import gzip

from textwrap import indent

from athenadatapipeline import load_zip_json
from athenadatapipeline.splitdata import split_serialize_data, clean_docstring
from crawlercrawler.func_def_features import extract_function_definitions

#DATA_DIR = Path("/smartml-athena/processed-data/fundef-docstrings/")
#JSON_GZ = DATA_DIR / "python-func-def-docstrings-2020-03-04-2336.json.gz"
DATA_DIR = Path('/smartml-athena/codesearchnet/python/final/jsonl/test')
JSON_GZ = DATA_DIR / 'python_test_0.jsonl.gz'


#CRAWLDIRS = [
#    "/smartml-athena/src-data/python/ziBjatNZRky2slnfFbZg2A/Git/1.0/",
#    "/smartml-athena/all-git-repos",
#    "/bigdata/git-repos/python",
#]


def code_format_docstring(docstring):
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == "\n":
        return f'"""\n{docstring}\n"""'
    return f'"""{docstring}"""'


def serialize_docstring(dat):
    if not dat[1]:  # empty docstring
        return dat[1]
    cleaned = clean_docstring(dat[1])
    if cleaned:
        return indent(code_format_docstring(cleaned), " " * 4)
    return cleaned  # emptied by cleaning


def serialize_method(dat):
    body = indent(dat[2], " " * 4)
    docstring = serialize_docstring(dat)
    if not docstring:
        return "\n".join([dat[0], body])
    return "\n".join([dat[0], docstring, body])


datasets = ("methods",)
serializers = (serialize_method,)

if __name__ == '__main__':

    csn_dat = load_zip_json(JSON_GZ)
    dat = []  # put into format matching my own data
    failures = 0
    for d in csn_dat:
        try:
            for method in extract_function_definitions(d['code'])[0]:
                dat.append(method)
        except SyntaxError:
            failures += 1

    #NOTE: CSN data is already split so I will just
    # copy the name split_serialize_data would give it
    # and proceed with saving the serialized features
    with gzip.open(
            DATA_DIR/'python_test_0.test.methods.json.gz', 
            'wb'
        ) as fout:
        for d in dat:
            fout.write(
                    (json.dumps(serialize_method(d)) + "\n").encode('utf-8')
            )

    #split_serialize_data(
    #    JSON_GZ,
    #    CRAWLDIRS,
    #    datasets=datasets,
    #    serializers=serializers,
    #    dir_suffix="split/gpt2-method-gen",
    #    keepempty=True,  # so methods without docstrings will be included
    #)
