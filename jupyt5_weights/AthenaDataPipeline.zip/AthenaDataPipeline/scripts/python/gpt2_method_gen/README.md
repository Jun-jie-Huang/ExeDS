

# Training GPT2

`scripts/gpt2_method_gen/split.py` - create dataset for GPT2 training, use serializers `serialize_docstring_target` and `serialize_method`

`scripts/gpt2_method_gen/prepare_for_fairseq.py` - prepare datasets for fairseq-train

`/nbs/preprocessing_for_gpt2_training_demo.ipynb` - fairseq-preprocess commands and fairseq-train examples (train examples are for local testing; actual train commands run on AML)

<https://devdiv.visualstudio.com/InternalTools/_git/jotimcAML> - training scripts on AML

To prepare dataset & train:

1. `python scripts/gpt2_method_gen/split.py`  ---> splits into train/val/test on repo level, exactly like Colin does
    
    Change `datasets = ("methods",)`

    and `serializers`

    and `keepempty`

2. python `scripts/gpt2_method_gen/prepare_for_fairseq.py`  ---> adds in spaces between tokens (that's how fairseq wants it) and add newlines between examples (it is nice because fairseq will then have "end of sample" tokens for prediction)

3. `/nbs/preprocessing_for_gpt2_training_demo.ipynb` ---> fairseq-preprocess (+ fairseq-train examples) in middle of notebook (first example at `# JUST FOR TEST (for => docstrings, when data on gpt2experiment_sync)`)

4. Move data to blob, so it is accessible on AML.

5. Run AML training scripts <https://devdiv.visualstudio.com/InternalTools/_git/jotimcAML>


# Evaluating GPT2 (generation on test set + metrics)

`scripts/gpt2_method_gen/split.py` - create dataset for GPT2 testing, use serializers `serialize_docstring_eval_tuple` and `serialize_method_eval_tuple`

To prepare dataset:

Same recipe as preparing train dataset (above), steps 1-4.

To generate on test set and evaluate:

## `scripts/gpt2_method_gen/aml_for_evaluation/`

`aml_submitter.py` - for submitting jobs that generate on the test set

`aml_conf_parser.py` - parser for aml config `.yaml`

`aml_test_config.yaml` config file for generating on test set


`aml_submitter_calls.sh` - calls made to `aml_submitter.py`

`combine_after_aml.sh` - combine output files from several AML generation jobs into one file

`eval_gpt2.py` - the script that does the generation (the script that the AML jobs run)

`model_init_test.py` - the modified `model_init.py` to do generation with GPT2 model; adds batch generation; used by `eval_gpt2.py` ---> interestingly, uses `.translate()` still, even though it is GPT2, a language model

`manual_test.py` - generate methods for small set of demo functions

`thinner_cli.py` - thin test set (to make more managable size)

`thinner_cli_calls.sh` - calls to `thinner_cli.py`


## `scripts/gpt2_method_gen/eval_metrics/`
BLEU, ROUGE, syntax check

`.py` files do the calculation; `.sh` files are how `.py` files are called


# Data and model checkpoints
Athena_RnD athenacommon6446656653

azureml-blobstore-429f2228-a25d-48bf-b621-92c5383842e0

jotimc/gpt2experiment

Evaluation dataset (test) in subdirectory `gpt2experiment_sync`; CSN in subdirectory `manual`.

# Other
`scripts/gpt2_method_gen/examine_data.py` - informal ipython inspection of datasets

`scripts/rsync_blob.sh` - rsync for jotimc blobfuse (not consistently used, could be dangerous to run now; possible overwrite of files)

`jotimc_readme.txt` - informal notes





