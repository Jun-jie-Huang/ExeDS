env CUDA_VISIBLE_DEVICES="2" fairseq-generate \
  /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings \
  --task language_modeling \
  --path /home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods/checkpoint_best.pt \
  #--beam 5 \
  # --remove-bpe
   # /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings \
    # /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq \
    #/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq/python-func-def-docstrings-2020-03-04-2336.test.docstrings
    #  /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq \
env CUDA_VISIBLE_DEVICES="3" ipython

env CUDA_VISIBLE_DEVICES="2" python scripts/generate.py \
  /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings \
  --task language_modeling \
  --path /home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods/checkpoint_best.pt \

run scripts/generate.py /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings --path /home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_docstrings/docstrings/checkpoint_best.pt  --task language_modeling    

env CUDA_VISIBLE_DEVICES="2" fairseq-generate \
 /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings \
 --path /home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods/checkpoint_best.pt \
 --batch-size 32 \
 --beam 1 \
 --sampling --sampling-topk 10 \
 --temperature 0.8 \
 --nbest 1 \
 --model-overrides "{'pretrained_checkpoint':'/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods/checkpoint_best.pt'}"