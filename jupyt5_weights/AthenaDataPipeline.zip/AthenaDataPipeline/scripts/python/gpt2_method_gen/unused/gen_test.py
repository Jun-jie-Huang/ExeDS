 s_list = generate_methods([["def print_list(list):", "",""], ["def print_every_other_element(list):","prints every other element in the list",""]], MODEL)
    print(s_list)
