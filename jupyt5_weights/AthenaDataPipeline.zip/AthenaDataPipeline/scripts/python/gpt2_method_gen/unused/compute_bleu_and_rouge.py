from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json


# === LOAD ===

#lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_checkpoint.methods.json.gz")
# with open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp.methods.json", "r") as f:
#      lines = f.readlines()
#PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/newfile"

PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json"

PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test_english.methods.json"

PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json"

PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_english.docstrings.json"



with open(PLAIN_TEXT, "r") as f:
    lines = f.readlines()
    #for line in lines:
    #    line = json.loads(line)
    #lines = json.load(f)
    #missing json load

jsons = []
for i, line in enumerate(lines):
    #print(i)
    try:
        jsons.append(json.loads(line))
    except:
        print('error on line ', i)
print(len(jsons))

#lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/newfile.gz")

# === new preprocess REF AND HYPS ===

refs, hyps = [], []
for js in jsons:
    # #r, h = js[1], js[8]
    # r = js[0] + "\n" + js[1]
    # h = js[8]
    # r = js[1]
    # h = js[8]
    src = js[0]
    tgt = js[1]
    
    full_gen = js[8]
    gen = full_gen[len(src):]

    if len(tgt) > 4 and len(gen) > 4:
        refs.append(tgt)
        hyps.append(gen)
print(len(refs))

# === new compute bleu ===
refs_split = list(map(lambda s: [s.split(),], refs))
hyps_split = list(map(lambda s: s.split(), hyps))

max_index = 90000
b = bleu_score.corpus_bleu(refs_split[:max_index], hyps_split[:max_index])
print("bleu = ", b)

# === new compute rouge ===
from rouge import Rouge
rouge = Rouge()
scores = rouge.get_scores(hyps[:max_index], refs[:max_index], avg=True)
scores

print(scores)

# === colin-style 4096 concat "document" rouge ===
import numpy as np
np.random.seed(9391)

refs, hyps = [], []
for js in jsons:
    src = js[0]
    tgt = js[1]
    
    full_gen = js[8]
    gen = full_gen[len(src):]

    if len(tgt) > 0 and len(gen) > 0:
        refs.append(tgt)
        hyps.append(gen)
print(len(refs))
print(len(hyps))







# build data folds
doc_size = 4096
indices = np.random.permutation(len(refs))
hyps_refs_list = []
for i in range(0,len(refs), doc_size):
    # if i > 1000:
    #      continue
    indices_sub = indices[i:i+doc_size]
    if len(indices_sub) == doc_size:
        from rouge import Rouge
        hyps_sub = [ hyps[index] for index in indices_sub ]
        refs_sub = [ refs[index] for index in indices_sub ]
        hyps_refs_list.append(['\n'.join(hyps_sub), '\n'.join(refs_sub)])
        #scores = Rouge().get_scores('\n'.join(hyps_sub), '\n'.join(refs_sub))[0]
        #print(scores)
        print(i)
    else:
        continue
print(len(hyps_refs_list))
hyps_refs_list = hyps_refs_list[:12] # only take the first 12

from rouge import Rouge
def get_rouge(hyps_refs_sub):
    scores = Rouge().get_scores(*hyps_refs_sub)[0]
    return scores

### in-python multiprocess
from multiprocessing import Pool
from collections import defaultdict
pool = Pool()
results_dict = defaultdict(list)
rs = [ r for r in pool.map(get_rouge, hyps_refs_list)]
    #print(r)
    # results_dict[r[0]].append(r[1])
#rs
def flatten_dict(results):
    flatdict = {}
    for metric in ('rouge-1', 'rouge-2', 'rouge-l'):
        flatdict[metric] = {}
        for stat in ('f', 'p', 'r'):
            flatdict[metric][stat] = []
            for r in results:
                flatdict[metric][stat].append(r[metric][stat])
    return flatdict

rs_flat = flatten_dict(rs)

def mean_std_dict(results):
    meandict = {}
    stddict = {}
    for metric in results:
        meandict[metric] = {}
        stddict[metric] = {}
        for stat in results[metric]:
            meandict[metric][stat] = np.mean(results[metric][stat])
            stddict[metric][stat] = np.std(results[metric][stat])
    return meandict, stddict

print("rs = ", rs, "\n")
print("mean, std = ", mean_std_dict(rs_flat), "\n")




rs_flat['rouge-1']


doc_size = 4096
indices = np.random.permutation(len(refs))
for i in range(0,len(refs), doc_size):
    indices_sub = indices[i:i+doc_size]
    if len(indices_sub) == doc_size:
        from rouge import Rouge
        hyps_sub = [ hyps[index] for index in indices_sub ]
        refs_sub = [ refs[index] for index in indices_sub ]
        with open(f"/tufanodata/jotimc/manual/docstring/rouge_{i}.json", "w") as fout:
            fout.write(json.dumps(['\n'.join(hyps_sub), '\n'.join(refs_sub)]))
        #scores = Rouge().get_scores('\n'.join(hyps_sub), '\n'.join(refs_sub))[0]
        #print(scores)
        print(i)
    else:
        continue




a = [1, 2, 3]



# === compare to colin rouge ===
from rouge import Rouge
scores = Rouge().get_scores('\n'.join(hyps[:max_index]), '\n'.join(refs[:max_index]))[0]
print(scores)




# === PREPROCESS REFS AND HYPS ===
def get_body_from_gen(whole_method):
    spl = whole_method.split('"""')
    return '"""'.join(spl[4:])

refs, hyps = [], []
for js in jsons:
    # #r, h = js[1], js[8]
    # r = js[0] + "\n" + js[1]
    # h = js[8]
    # r = js[1]
    # h = js[8]
    r = js[4]
    h = get_body_from_gen(js[8])
    #print(r)
    if len(r) > 4 and len(h) > 4:
        refs.append(r)
        # hyps look like # target body...
        # remove "# target body"
        #h = h[14:]
        hyps.append(h)



i = 3
print("\n refs[i] = \n", refs[i])
print("\n hyps[i] = \n", hyps[i])
#print("\n jsons[i][8] = \n", jsons[i][8])

hyps[i]
jsons[i][8][len(jsons[i][0]) + 51:]
jsons[i][1]
jsons[i][2]
jsons[i][3]
jsons[i][4]
jsons[i][0]
jsons[i][4]
jsons[i][8]

jsons[i][8].find(jsons[i][3])
jsons[i][8].find(jsons[i][3])
#jsons[i][8].split('"""')[4]

# [src, tgt, dat[0], docstring, body, dat[0], dat[1], dat[2], hyp]


# === BLEU ===

#bleu = bleu_score.corpus_bleu(refs, hyps)

refs_split = list(map(lambda s: [s.split(),], refs))
hyps_split = list(map(lambda s: s.split(), hyps))

max_index = 40000
b = bleu_score.corpus_bleu(refs_split[:max_index], hyps_split[:max_index])
print("bleu = ", b)


# hypothesis = ['It', 'is', 'a', 'cat', 'at', 'room']
# reference = ['It', 'is', 'a', 'cat', 'inside', 'the', 'room']
# hypothesis = hyps_split[0]
# reference = refs_split[0]
# #there may be several references
# BLEUscore = bleu_score.sentence_bleu([reference], hypothesis)
# print(BLEUscore)
# bleu_score.sentence_bleu()
# refs_split[0]
# hyps_split[0]


# bleu_score.corpus_bleu()




# def get_bleu(dat, head=None, thin=None):
#     refs, hyps = [], []
#     if head is not None:
#         dat = dat[:head]
#     if thin is not None:
#         dat = dat[::thin]
#     for d in dat:
#         r, h = d[2].split(), d[1].split()
#         if len(r) > 4 and len(h) > 4:
#             refs.append([r])
#             hyps.append(h)

#     return bleu_score.corpus_bleu(refs, hyps)


# === ROUGE ====
from rouge import Rouge
rouge = Rouge()
scores = rouge.get_scores(hyps[:max_index], refs[:max_index], avg=True)
scores

print(scores)




# scores = rouge.get_scores(hyps, refs)

# # Load some sentences
# with open('./tests/data.json') as f:
#   data = json.load(f)

# hyps, refs = map(list, zip(*[[d['hyp'], d['ref']] for d in data]))


# # or
# scores = rouge.get_scores(hyps, refs, avg=True)


# from rouge import Rouge
# hypothesis = "the #### transcript is a written version of each day 's cnn student news program use this transcript to he    lp students with reading comprehension and vocabulary use the weekly newsquiz to test your knowledge of storie s you     saw on cnn student news"
# reference = "this page includes the show transcript use the transcript to help students with reading comprehension and     vocabulary at the bottom of the page , comment for a chance to be mentioned on cnn student news . you must be a teac    her or a student age # # or older to request a mention on the cnn student news roll call . the weekly newsquiz tests     students ' knowledge of even ts in the news"

# rouge = Rouge()
# #scores = rouge.get_scores([hypothesis,hypothesis,], [reference,reference,])
# scores = rouge.get_scores('\n'.join(hyps[:max_index]), '\n'.join(refs[:max_index]))
# scores = rouge.get_scores(hyps[:max_index], refs[:max_index])
# scores


# def get_rouge(fold):
#     label, (hyp, ref) = fold
#     return fold[0], Rouge().get_scores('\n'.join(hyp), '\n'.join(ref))[0]






# def get_rouge(fold):
#     label, (hyp, ref) = fold
#     return fold[0], Rouge().get_scores('\n'.join(hyp), '\n'.join(ref))[0]