#!/usr/bin/env python

# python aml_submitter.py --experiment_name=TestFairseq --entry_script=train.py --process_count_per_node=4

import logging
import argparse
import os
import azureml.core

print("SDK version:", azureml.core.VERSION)

from azureml.telemetry import set_diagnostics_collection

set_diagnostics_collection(send_diagnostics=True)

from azureml.core import Datastore, Experiment
from azureml.core.workspace import Workspace
from azureml.data.data_reference import DataReference
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.core.runconfig import MpiConfiguration

from azureml.train.dnn import PyTorch



from aml_conf_parser import load_specified_conf



def initialize_workspace():
    ws = Workspace.from_config()
    print(
        "Workspace name: " + ws.name,
        "Azure region: " + ws.location,
        "Subscription id: " + ws.subscription_id,
        "Resource group: " + ws.resource_group,
        sep="\n",
    )
    return ws


# choose a name for your cluster
def get_or_create_cluster(
    ws,
    cluster_name,
    max_nodes=4,
    idle_seconds_before_scaledown=600,
    vm_size="STANDARD_NC24rs_v3",
):
    try:
        compute_target = ComputeTarget(workspace=ws, name=cluster_name)
        print("Found existing compute target.")
    except ComputeTargetException:
        print("Creating a new compute target...")
        compute_config = AmlCompute.provisioning_configuration(
            vm_size=vm_size,
            max_nodes=max_nodes,
            idle_seconds_before_scaledown=idle_seconds_before_scaledown,
        )

        # create the cluster
        compute_target = ComputeTarget.create(ws, cluster_name, compute_config)
        compute_target.wait_for_completion(show_output=True)
    return compute_target


def get_or_create_datastore(
    ws,
    datastore_name=None,
    container_name=None,
    account_name=None,
    account_key=None,
    create_if_not_exists=False,
):
    try:
        ds = Datastore.get_default(ws)
        print("Found existing datastore.")
    except:
        print("Creating a new datastore...")
        ds = Datastore.register_azure_blob_container(
            workspace=ws,
            datastore_name=datastore_name,
            container_name=container_name,
            account_name=account_name,
            account_key=account_key,
            create_if_not_exists=create_if_not_exists,
        )
    return ds


def create_estimator(
    image_name,
    script_params,
    project_folder,
    entry_script,
    use_mpi=False,
    process_count_per_node=4,
    node_count=1,
):

    estimator_args = {
        "use_docker": True,
        "custom_docker_image": image_name,
        "user_managed": True,
        "source_directory": project_folder,
        "script_params": script_params,
        "compute_target": compute_target,
        "entry_script": entry_script,
        "use_gpu": True,
    }
    if use_mpi:
        # Using MPI to execute a distributed run
        mpi = MpiConfiguration()
        mpi.process_count_per_node = process_count_per_node
        estimator_args["node_count"] = node_count
        estimator_args["distributed_training"] = mpi

    estimator = PyTorch(**estimator_args)
    return estimator


def parse_args():
    """
    Parse the args passed from the command line specifiying the specific conf.yaml to load
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cluster_name",
        type=str,
        default="nc24rsv3",
        #default="nc24rsv3-a",
        help="Cluster name, string. Check which clusters are already avaialbe in the AML workspace",
    )
    parser.add_argument(
        "--experiment_name",
        type=str,
        default="prediction",
        help="Experiment name, any name you choose",
    )
    parser.add_argument(
        "--image_name",
        type=str,
        #default="asvyatko/fairseqdev:latest",
        default="asvyatko/fairseqfix:latest",
        #default="asvyatko/fairseqmax:latest",
        help="Docker image name. E.g. asvyatko/fairseqmax:latest",
    )
    parser.add_argument(
        "--entry_script", type=str, required=True, help="Name of the script to submit",
    )
    parser.add_argument(
        "--node_count",
        type=int,
        default=1,
        help="Number of nodes. If greater than 1, MPI will be enabled",
    )
    parser.add_argument(
        "--process_count_per_node",
        type=int,
        default=4,
        help="Number of tasks per node. If your job is serial -- 1, if it is parallel, then up to NGPUs per node (4 in case of NC24_v3 SKU)",
    )


    # Parameters for script
    parser.add_argument(
        "--model_path",
        type=str,
        default="/jotimc/gpt2experiment/fairseq_models/random_init_2/methods",
        help="Path to model dir",
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default="/jotimc/gpt2experiment/fairseq-preprocess-output/methods",
        help="Path to fairseq preprocess output dir",
    )
    parser.add_argument(
        "--tokenizer_prefix",
        type=str,
        default="/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces",
        help="Path to tokenizer dir",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="checkpoint_best.pt",
        help="Which checkpoint, e.g., checkpoint_best.pt",
    )
    parser.add_argument(
        "--test_set_path",
        type=str,
        default="/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test.methods.json.gz",
        help="Data to run prediction on",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_aml.methods.json.gz",
        help="Output path for .json.gz (predictions)"
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="methods",
        help="'methods' or 'docstrings'"
    )


    return vars(parser.parse_args())


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)-15s %(name)-5s %(levelname)-8s %(message)s",
    )
    logger = logging.getLogger("aml_submitter")

    args = parse_args()
    #conf = load_specified_conf(args["config_file"])
    #print(conf)
    node_count = args["node_count"]
    use_mpi = True if node_count > 1 else False
    process_count_per_node = args["process_count_per_node"]

    logger.info("Create or access existing AML workspace")
    ws = initialize_workspace()

    cluster_name = args["cluster_name"]
    compute_target = get_or_create_cluster(ws, cluster_name)
    logger.info(f"Will submit jobs to {cluster_name} compute target")
    logger.info(compute_target.get_status().serialize())

    ds = get_or_create_datastore(ws)

    experiment_name = args["experiment_name"]
    #print("===")
    #print(conf["cluster"]["experiment"]["name"])
    #experiment_name = conf["cluster"]["experiment"]["name"]
    experiment = Experiment(ws, name=experiment_name)

    ## Using a public image published on Dockerhub
    image_name = args["image_name"]

    #
    # FILL THIS SECTION WITH INPUTS SPEICIF TO YOU
    #
    # this should have all the command line arguments that your trainig script takes
    # if there is a lot, create YAML config and pass it as an argument
    logger.info(
        "Create data reference pointing to a folder alexeys/fairseq-data-bin/iwslt14.tokenized.de-en in default AML datastore"
    )
       
    model_path = DataReference(
        datastore=ds,
        data_reference_name="model_path",
        path_on_datastore=args["model_path"],
    )
    data_path = DataReference(
        datastore=ds,
        data_reference_name="data_path",
        path_on_datastore=args["data_path"],
    )
    test_set_path = DataReference(
        datastore=ds,
        data_reference_name="test_set_path",
        path_on_datastore=args["test_set_path"],
    )

    tokenizer_prefix = DataReference(
        datastore=ds,
        data_reference_name="tokenizer_prefix",
        path_on_datastore=args["tokenizer_prefix"],
    )
    output_path = DataReference(
        datastore=ds,
        data_reference_name="output_path",
        path_on_datastore=args["output_path"],
    )

    #script_params = args
    # update paths to be on AML
    script_params = {}
    script_params["--model_path"] = model_path.as_mount()
    script_params["--data_path"] = data_path.as_mount()
    script_params["--test_set_path"] = test_set_path.as_mount()
    script_params["--tokenizer_prefix"] = tokenizer_prefix.as_mount()
    script_params["--output_path"] = output_path.as_mount()
    script_params["--mode"] = args["mode"]
    # may have to add/remove dashes
    print("=========args===")
    print(args)
    print("=========script_params===")
    print(script_params)
    project_folder = "."

    entry_script = args["entry_script"]

    # create estimator
    estimator = create_estimator(
        image_name,
        script_params,
        project_folder,
        entry_script,
        use_mpi=use_mpi,
        process_count_per_node=process_count_per_node,
        node_count=node_count,
    )

    # submit estimator
    run = experiment.submit(estimator)
    logger.info(run)
    print("done")

# Run 2: test local python path add import
# Run 3: fix paths
# Run 4: test imports 
# Run 5: test imports 2
# Run 6: test new fairseqfix docker image
# Run 7: image fix again cython

# Run 8: thin-10 method gen
# Run 9: 