python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10.methods.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10.methods.json.gz" \
    --mode "methods"

python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10.methods.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_english.methods.json.gz" \
    --mode "methods"

python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_4.docstrings.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4.docstrings.json.gz" \
    --mode "docstrings"

python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_4.docstrings.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_english.docstrings.json.gz" \
    --mode "docstrings"


### further split, and single-gpu (at least requested)
for i in {0..7}
do
    echo "submitting $i"
    python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10_par_$i.methods.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_$i.methods.json.gz" \
    --mode "methods" \
    --process_count_per_node 1
done

for i in {0..7}
do
   echo "submitting $i"
    python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10_par_$i.methods.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_${i}english.methods.json.gz" \
    --mode "methods" \
    --process_count_per_node 1
done

for i in {0..7}
do
   echo "submitting $i"
   python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_4_par_$i.docstrings.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_$i.docstrings.json.gz" \
    --mode "docstrings" \
    --process_count_per_node 1
done

for i in {0..7}
do
    echo "submitting $i"
    python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_4_par_$i.docstrings.json.gz" \
    --output_path "jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_${i}_english.docstrings.json.gz" \
    --mode "docstrings" \
    --process_count_per_node 1
done

### for CSN manual

### further split, and single-gpu (at least requested)
for i in {0..3}
do
    echo "submitting $i"
    python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/manual/csn_methods_thin_1_par_${i}.json.gz" \
    --output_path "jotimc/gpt2experiment/manual/csn_methods+hyp_thin_1_par_${i}.json.gz" \
    --mode "methods" \
    --process_count_per_node 1
done

for i in {0..3}
do
    echo "submitting $i"
    python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods" \
    --data_path "/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/manual/csn_methods_thin_1_par_${i}.json.gz" \
    --output_path "jotimc/gpt2experiment/manual/csn_methods+hyp_english_thin_1_par_${i}.json.gz" \
    --mode "methods" \
    --process_count_per_node 1
done


for i in {0..3}
do
   echo "submitting $i"
   python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/random_init_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/manual/csn_docstrings_thin_1_par_${i}.json.gz" \
    --output_path "/jotimc/gpt2experiment/manual/csn_docstrings+hyp_thin_1_par_${i}.json.gz" \
    --mode "docstrings" \
    --process_count_per_node 1
done

for i in {0..3}
do
   echo "submitting $i"
   python scripts/aml_submitter.py --entry_script scripts/eval_gpt2.py \
    --model_path "/jotimc/gpt2experiment/fairseq_models/english_pretrained_docstrings/docstrings" \
    --data_path "/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings" \
    --tokenizer_prefix "/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/jotimc/gpt2experiment/manual/csn_docstrings_thin_1_par_${i}.json.gz" \
    --output_path "/jotimc/gpt2experiment/manual/csn_docstrings+hyp_english_thin_1_par_${i}.json.gz" \
    --mode "docstrings" \
    --process_count_per_node 1
done




### hacking to run on VM
env CUDA_VISIBLE_DEVICES="2" python scripts/eval_gpt2.py \
    --model_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods" \
    --data_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10.methods.json.gz" \
    --output_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10.methods.json.gz" \
    --mode "methods"


env CUDA_VISIBLE_DEVICES="3" python scripts/eval_gpt2.py \
    --model_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods" \
    --data_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10.methods.json.gz" \
    --output_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_english.methods.json.gz" \
    --mode "methods"

# hack to run on VM CSN

env CUDA_VISIBLE_DEVICES="2" python scripts/eval_gpt2.py \
    --model_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods" \
    --data_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/tufanodata/jotimc/manual/csn_methods.json.gz" \
    --output_path "/tufanodata/jotimc/manual/csn_methods+hyp.json.gz" \
    --mode "methods"

env CUDA_VISIBLE_DEVICES="3" python scripts/eval_gpt2.py \
    --model_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods" \
    --data_path "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods" \
    --tokenizer_prefix "/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces" \
    --checkpoint "checkpoint_best.pt" \
    --test_set_path "/tufanodata/jotimc/manual/csn_methods.json.gz" \
    --output_path "/tufanodata/jotimc/manual/csn_methods+hyp_english.json.gz" \
    --mode "methods"