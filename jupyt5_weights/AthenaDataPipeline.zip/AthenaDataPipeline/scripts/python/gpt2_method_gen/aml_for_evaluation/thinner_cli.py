from nltk.translate import bleu, bleu_score
import json

from athenadatapipeline import load_zip_json

import sys
import numpy as np
import argparse
from rouge import Rouge
import gzip

parser = argparse.ArgumentParser()
parser.add_argument(
    "--input-path",
    type=str,
    default="/tufanodata/jotimc/manual/csn_methods.json.gz",
    help="json.gz json lines"
)
parser.add_argument(
    "--output-prefix",
    type=str,
    default="/tufanodata/jotimc/manual/csn_methods",
    help="prefix for par output"
)
parser.add_argument(
    "--thin",
    type=str,
    default=1,
    help="thin amount"
)
parser.add_argument(
    "--n_partitions",
    type=str,
    default=4,
    help="number of partitions"
)
cli_args = vars(parser.parse_args())
print(cli_args)
INPUT_PATH = cli_args["input_path"]
OUTPUT_PREFIX = cli_args["output_prefix"]
THIN = cli_args["thin"]
N_PARTITIONS = cli_args["n_partitions"]

OUTPUT_PATHS = [ OUTPUT_PREFIX + f"_thin_{THIN}_par_{i}.json.gz" for i in range(0,N_PARTITIONS) ]
print("OUTPUT_PATHS = ", OUTPUT_PATHS)

lines = load_zip_json(INPUT_PATH, thin=THIN)

len_par = int(len(lines) / N_PARTITIONS + 1)

lines_par = [ lines[i::N_PARTITIONS] for i in range(N_PARTITIONS) ] # like thinnning

for i in range(0, N_PARTITIONS):
    with gzip.open(OUTPUT_PATHS[i], 'wb')  as fout:
        for line in lines_par[i]:
            fout.write(bytes(json.dumps(line) + '\n', 'utf-8'))

print("done")
