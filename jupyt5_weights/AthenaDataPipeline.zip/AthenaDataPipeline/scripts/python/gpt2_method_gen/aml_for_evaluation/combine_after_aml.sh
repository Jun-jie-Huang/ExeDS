

# docstrings random init 
filelist=""
for i in {0..7}
do
    filelist+=" /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_${i}.docstrings.json.gz "
done


zcat $filelist | gzip > "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json.gz"

# or to plain text
zcat $filelist > "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED.docstrings.json"







# docstrings english pretrain 
filelist=""
for i in {0..7}
do
    filelist+=" /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_${i}_english.docstrings.json.gz "
done

# or to plain text
zcat $filelist > "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_4_par_COMBINED_english.docstrings.json"





# methods random init 
filelist=""
for i in {0..7}
do
    filelist+=" /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_${i}.methods.json.gz "
done

# or to plain text
zcat $filelist > "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED.methods.json"


# methods english pretrain 
filelist=""
for i in {0..7}
do
    filelist+=" /tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_${i}english.methods.json.gz "
done

# or to plain text
zcat $filelist > "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_par_COMBINED_english.methods.json"










### === for CSN ===

# methods random init
filelist=""
for i in {0..3}
do
    filelist+=" /tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_${i}.json.gz "
done

# to plain text
zcat $filelist > "/tufanodata/jotimc/manual/csn_methods+hyp_thin_1_par_COMBINED.json"

# methods english pretrain
filelist=""
for i in {0..3}
do
    filelist+=" /tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_${i}.json.gz "
done

# to plain text
zcat $filelist > "/tufanodata/jotimc/manual/csn_methods+hyp_english_thin_1_par_COMBINED.json"

# docstrings random init
filelist=""
for i in {0..3}
do
    filelist+=" /tufanodata/jotimc/manual/csn_docstrings+hyp_thin_1_par_${i}.json.gz "
done

# to plain text
zcat $filelist > "/tufanodata/jotimc/manual/csn_docstrings+hyp_thin_1_par_COMBINED.json"

# docstrings english
for i in {0..3}
do
    filelist+=" /tufanodata/jotimc/manual/csn_docstrings+hyp_english_thin_1_par_${i}.json.gz "
done

# to plain text
zcat $filelist > "/tufanodata/jotimc/manual/csn_docstrings+hyp_english_thin_1_par_COMBINED.json"














### testing

zcat file1.txt.gz file2.txt.gz | gzip > file33

a=""


cd "/home/jotimc/gzip_combine_test"

gzip "file1.txt"
gzip "file2.txt"






import os

GZ_FILES = []
PLAIN_TEXT_
for i in range(8):
GZ_FILE = "/data/home/jotimc/mycontainer/jotimc/gpt2experiment/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_thin_10_english.methods.json.gz"
PLAIN_TEXT = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test_english.methods.json"
os.system(f'zcat {GZ_FILE} > {PLAIN_TEXT}')