python scripts/thinner_cli.py \
    --input-path "/tufanodata/jotimc/manual/csn_docstrings.json.gz" \
    --output-prefix "/tufanodata/jotimc/manual/csn_docstrings"