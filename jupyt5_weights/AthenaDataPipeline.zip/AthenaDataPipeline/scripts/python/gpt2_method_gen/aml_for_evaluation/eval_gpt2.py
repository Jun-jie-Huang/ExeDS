# set visible devices, within jupyter notebook (do before importing torch, and check that it only sees 1 gpu)
import os
#os.environ["CUDA_VISIBLE_DEVICES"]="3"
import torch
import logging
import argparse
from pathlib import Path
from pprint import pprint


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model_path",
        type=str,
        default="/tufanodata/jotimc/temp/methods",
        #default="/tufanodata/jotimc/temp/docstrings",
        help="Path to model dir"
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default="/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods",
        ## non-existent: default="/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/docstrings",
        #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/docstrings",
        help="Path to fairseq preprocess output dir",
    )
    parser.add_argument(
        "--tokenizer_prefix",
        type=str,
        default="/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces",
        help="Path to tokenizer dir",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="checkpoint_best.pt",
        help="Which checkpoint, e.g., checkpoint_best.pt",
    )
    parser.add_argument(
        "--test_set_path",
        type=str,
        #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test.methods.json.gz",
        default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test_thin_10.methods.json.gz",
        #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test.docstrings.json.gz",
        help="Data to run prediction on",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.methods.json.gz",
        #default="/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_local_test.docstrings.json.gz",
        help="Output path for .json.gz (predictions)"
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="methods",
        help="'methods' or 'docstrings'"
    )
    return vars(parser.parse_args())

cli_args = parse_args()

MODEL_PATH = cli_args["model_path"]
DATA_PATH = cli_args["data_path"]
TOKENIZER_PREFIX = Path(cli_args["tokenizer_prefix"])
CHECKPOINT = cli_args["checkpoint"]

TEST_SET_PATH = cli_args["test_set_path"]
OUTPUT_PATH = cli_args["output_path"]

MODE = cli_args["mode"]
print("OUTPUT_PATH = " , OUTPUT_PATH)

logging.basicConfig(level=os.environ.get("LOGLEVEL", "INFO"))

log = logging.getLogger("Logger")
log.info("Hello, world")

torch.cuda.device_count()
print("num gpus = " + str(torch.cuda.device_count()))

# import model_init_test # ---> module not found error
import sys 
import os
#sys.path.append(os.path.abspath("/home/jotimc/projects/AthenaDataPipeline/scripts"))
sys.path.append(os.path.abspath("./AthenaDataPipeline/scripts"))

#from model_init_test import *
from model_init_test import *

print("after model_init_test import")




# MODEL_PATH = "/tufanodata/jotimc/temp/methods"
# DATA_PATH = "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods"
# TOKENIZER_PREFIX = Path("/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces")
# CHECKPOINT = "checkpoint_best.pt"

args = Args(
        model_name_or_path=MODEL_PATH,
        data_name_or_path=DATA_PATH,
        tokenizer_prefix=TOKENIZER_PREFIX,
        checkpoint_file=CHECKPOINT,
)

MODEL = FairseqModelInterface()
MODEL.load_model(args)

# list of length 3, containing [signature, docstring, body]

if MODE == "methods":
    example = ["def print_arg(arg):", "prints arg.",""]
    s = generate_methods([example,], MODEL)
    print(s)
elif MODE == "docstrings":
    example = ["def print_arg(arg):", "", "    print(arg)"]
    s = generate_docstrings([example,], MODEL)
    print(s)
else:
    print("ERROR, UNKNOWN MODE")
    sys.exit(1)


#####################################
from athenadatapipeline import load_zip_json
import json
import gzip
import numpy as np
import pickle

#lines = load_zip_json("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test.methods.json.gz")
lines = load_zip_json(TEST_SET_PATH)

n_test = len(lines)
print("n_test", n_test)
#indices = np.random.permutation(n_test)
indices = range(0,n_test)


# with open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/indices.pkl","wb") as f:
#     pickle.dump(indices, f)
# with open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/indices.pkl","rb") as f:
#     indices = pickle.load(f)

print(indices)

start_offset = 0 # primarily for debugging; should be 0 for regular run
#with gzip.open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_2.methods.json.gz", 'wb') as fout:
with gzip.open(OUTPUT_PATH, 'wb') as fout:
#with open("/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen-eval/python-func-def-docstrings-2020-03-04-2336.test+hyp_2.methods.json", 'w') as fout:
    batch_size = 8
    for offset in range(start_offset, n_test, batch_size): 
        indices_subset = indices[offset:min(offset + batch_size, n_test)]

        examples = []
        batch_lines = []
        this_batch_size = len(indices_subset)
        for i in indices_subset:
            line = lines[i]
            num_tokens = len(MODEL.tokenizer.encode(MODEL.encode(line[0])).ids)
            if num_tokens >= 1024:
                this_batch_size -= 1
                continue # skip samples longer than 1024 tokens 
            if MODE == "methods":
                #examples.append( [lines[i][2], lines[i][6], ""] ) # give sig and doc
                examples.append( line[0] )
                batch_lines.append(line)
            elif MODE == "docstrings":
                #examples.append( [lines[i][2], "", lines[i][4]] ) # give sig and body
                examples.append( line[0] )
                batch_lines.append(line)

        #examples = [  [lines[i][2], lines[i][3], ""] for i in indices_subset ]
        #generate_methods(examples, MODEL, max_len_a=1, max_len_b=1024)
        if MODE == "methods":
            hypotheses, hypotheses_spaces = generate_methods_simple(examples, MODEL)
        elif MODE == "docstrings":
            hypotheses, hypotheses_spaces = generate_docstrings_simple(examples, MODEL)

        if this_batch_size == 0:
            print("this_batch_size == 0, continuing")
            continue
        if len(hypotheses) < this_batch_size:
            print("skipping batch, offset = ", offset)
            print("details")
            print(examples)
            print(hypotheses)
            print(hypotheses_spaces)
            #break
            continue
        for i, batch_line in enumerate(batch_lines):
            batch_line.append(hypotheses[i])
            batch_line.append(hypotheses_spaces[i])
            fout.write(bytes(json.dumps(batch_line) + '\n', 'utf-8'))
            #fout.write(json.dumps(batch_line) + '\n')
            if offset < 100 or offset % 1000 == 0:
                print("\nsrc = ", batch_line[0])
                print("\ntgt = ", batch_line[1])
                print("\ndef = ", batch_line[5])
                print("\ndoc = ", batch_line[6])
                print("\nbody= ", batch_line[7])
                print("\nhyp = ", batch_line[8])
                print("\nhyps= ", batch_line[9])
                print("\n====================================\n")
                # print(batch_line)
        print(offset)
        #print(hypotheses)
