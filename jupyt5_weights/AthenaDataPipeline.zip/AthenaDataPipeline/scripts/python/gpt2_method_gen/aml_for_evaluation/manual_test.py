import os
os.environ["CUDA_VISIBLE_DEVICES"]="3"

examples = [
    ["def factorial(x: int):",
    """Compute the factorial of x""",
    "",],
    ["def sum_to_n(n: int):",
    """Sums the numbers from 1 to n.""",
    "",],  
    ["def is_palindrome(text: str):",
    """Checks if given string is a palindrome""",
    "",],
    ["def halfway(a: int, b: int):",
    """
    What number is halfway between a and b?
    """,
    "",],
    ["def is_prime(n):",
    """Return true if a given number is prime, and false otherwise.""",
    "",],
    ["def reverse_order_of_words(s):",
"""
Reverses the order of the words in the string s without
reversing the order of the characters within each word.
""",
    "",],
    ["def count_even_numbers_in_list(x):",
"""
Given a list x of numbers, count how many even numbers are in the list.
""",
    "",],
    ["def return_odd_numbers_from_list(l):",
"""
Given a list of integers, return only those which are odd.
""",
    "",],
    ["def return_indices_of_list_elements_that_are_3(l):",
 """Given a list of numbers, returns the indices of the list elements that are 3.""",
 "",],
 ["def any_large_elements(numbers):",
 """Check if any elements of the list are larger than 1000""",
 "",],
 ["def non_zero_elements_indices(numbers):",
 """Find the indices of non-zero elements in a list""",
 "",],
 ["def same_chars(s0: str, s1: str):",
"""
Check if two words have the same characters.
>>> same_chars('abcd', 'dddddddabc')
True
>>> same_chars('dddddddabc', 'abcd')
True
>>> same_chars('eabcd', 'dddddddabc')
False
""",
""],

]

run model_init_test.py

# to be run in ipython after running model_init_test.py
completions = generate_methods(examples, MODEL)

for completion in completions[0]:
    print(completion)

completions = generate_methods(examples, MODEL, beam=7, temperarture=1.)
for completion in completions[0]:
    print(completion)
