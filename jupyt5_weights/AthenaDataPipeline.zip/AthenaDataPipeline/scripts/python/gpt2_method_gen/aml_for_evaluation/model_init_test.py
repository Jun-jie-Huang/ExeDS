"""
docstringify.py

author: Colin Clement
date: 2020-04-07

Container classes for initializing and pre-/post-processing
text for interactively using fairseq/huggingface transformer models
"""

from pathlib import Path
import torch
from textwrap import indent, dedent

from tokenizers import ByteLevelBPETokenizer
from fairseq.models.transformer import TransformerModel

from fairseq.models.huggingface import HuggingFaceGPT2LanguageModel

from collections import namedtuple

Args = namedtuple('Args',
        [
            'model_name_or_path', 
	    'data_name_or_path', 
            'tokenizer_prefix',
            'checkpoint_file'
        ]
)

def code_format_docstring(docstring):
    """Format docstring into indented, triple-quote delimited string"""
    if not docstring:
        return docstring
    if len(docstring.splitlines()) > 1 or docstring[0] == '\n':
        return indent(f'"""\n{docstring}\n"""', ' ' * 4)
    return indent(f'"""{docstring}"""', ' ' * 4)

def generate_method(example, model, beam=5, temperature=1.0):
    """
    Generate method body from signature and docstring using
    a translation model. If signature is empty, only the docstring
    is used to predict the method body and docstring. If docstring
    is empty, only signature is used to predict method body. If both
    are empty, an empty string is returned and no inference occurs.
    NOTE: If a non-empty body is provided, the model will attempt
    to complete the body with that as a prompt!

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    beam : int, optional
    temperature : float, optional

    Returns
    -------
    method_body : str
        predicted body string, indented by four spaces,
        and predicted signature if the signature is not provided
    """
    if example[0]:
        parts = ['# target body', example[0]]
    elif example[1]:  # predict signature too if missing
        parts = ['# target sig_and_body']
    else:
        return ''  # missing essential information
    if example[1]:
        parts.append(code_format_docstring(example[1]))
    # parts = [example[0], example[1]]

    
    inference_step_args = {}
    # partial body complete if signature and non-trivial body present
    if example[0] and example[2]:
        body = indent(example[2], ' ' * 4)
        # Fairseq model encode appends EOS token by default!
        # unsqueeze necessary as fairseq does the same to the prompt
        prefix_tokens = model.model.encode(model.encode(body))[:-1].unsqueeze(0)
        if torch.cuda.is_available():
            prefix_tokens = prefix_tokens.cuda()
        inference_step_args['prefix_tokens'] = prefix_tokens

    encoded_text = model.encode('\n'.join(parts))
    #print(model.model.forward(encoded_text))
    #import pdb; pdb.set_trace()
    return model.translate(
            '\n'.join(parts),
            beam=beam, 
            temperature=temperature,
            inference_step_args=inference_step_args,
    )

DOCSTRING_STYLES = {
        'oneline', 
        'numpydoc', 
        'google', 
        'restructuredtext',
        'javadoc', 
        'oneparagraph', 
        'other'
}

def generate_methods_simple(examples, model, beam=5, temperature=1.0, **kwargs):
    """
    Given preprocessed (cleaned, etc, just like handed to fairseq preprocess) sig + docstring, return sig + docstring + generated body
    examples are list of str (sig + docstring already combined)
    """
    inference_step_args = {}

    encoded_texts = []
    for example in examples:
        encoded_texts.append(example) # not actually encoded
       
    return model.translate_batch(
            encoded_texts,
            beam=beam, 
            temperature=temperature,
            inference_step_args=inference_step_args,
            **kwargs,
    )

def generate_docstrings_simple(examples, model, style='numpydoc'):
    """
    same as generate_methods_simple
    """
    assert style in DOCSTRING_STYLES

    encoded_texts = []
    for example in examples:
        encoded_texts.append(example) # not actually encoded

    return model.translate_batch(encoded_texts, beam=5, temperature=1.)



def generate_methods(examples, model, beam=5, temperature=1.0, **kwargs):
    """
    Generate method body from signature and docstring using
    a translation model. If signature is empty, only the docstring
    is used to predict the method body and docstring. If docstring
    is empty, only signature is used to predict method body. If both
    are empty, an empty string is returned and no inference occurs.
    NOTE: If a non-empty body is provided, the model will attempt
    to complete the body with that as a prompt!

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    beam : int, optional
    temperature : float, optional

    Returns
    -------
    method_body : str
        predicted body string, indented by four spaces,
        and predicted signature if the signature is not provided
    """
    encoded_texts = []
    for example in examples:
        parts = [example[0],]
        # if example[0]:
        #     parts = ['# target body', example[0]]
        # elif example[1]:  # predict signature too if missing
        #     parts = ['# target sig_and_body']
        # else:
        #     return ''  # missing essential information
        if example[1]:
            parts.append(code_format_docstring(example[1]))
        # parts = [example[0], example[1]]

        encoded_text = '\n'.join(parts)
        encoded_texts.append(encoded_text)
    
        inference_step_args = {}
        # partial body complete if signature and non-trivial body present
        # if example[0] and example[2]:
        #     body = indent(example[2], ' ' * 4)
        #     # Fairseq model encode appends EOS token by default!
        #     # unsqueeze necessary as fairseq does the same to the prompt
        #     prefix_tokens = model.model.encode(model.encode(body))[:-1].unsqueeze(0)
        #     if torch.cuda.is_available():
        #         prefix_tokens = prefix_tokens.cuda()
        #     inference_step_args['prefix_tokens'] = prefix_tokens

    return model.translate_batch(
            encoded_texts,
            beam=beam, 
            temperature=temperature,
            inference_step_args=inference_step_args,
            **kwargs,
    )

DOCSTRING_STYLES = {
        'oneline', 
        'numpydoc', 
        'google', 
        'restructuredtext',
        'javadoc', 
        'oneparagraph', 
        'other'
}

def generate_docstrings(examples, model, style='numpydoc'):
    """
    Generate method docstring from signature and docstring using
    a translation model. Can provide signature, signature and method, 
    or method. If element is missing, expects an empty string.

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    style : str, optional
        must be element of DOCSTRING_STYLES, default 'numpydoc'

    Returns
    -------
    docstring : str
        predicted docstring, indented by four spaces and triple quote 
        delimited
    """
    assert style in DOCSTRING_STYLES

    encoded_texts = []
    for example in examples:
        # parts = [f'# target docstring style {style}']
        # if not example[0] and not example[2]:
        #     return ''
        parts = []
        if example[0]:
            parts.append(example[0])
        if example[2]:
            parts.append(dedent(indent(example[2], ' ' * 4)))

        encoded_text = '\n'.join(parts)
        encoded_texts.append(encoded_text)

    return model.translate_batch(encoded_texts, beam=5, temperature=1.)



def generate_docstring(example, model, style='numpydoc'):
    """
    Generate method docstring from signature and docstring using
    a translation model. Can provide signature, signature and method, 
    or method. If element is missing, expects an empty string.

    Parameters
    ----------
    example : List[str]
        list of length 3, containing [signature, docstring, body]
    model : ModelInterface
    style : str, optional
        must be element of DOCSTRING_STYLES, default 'numpydoc'

    Returns
    -------
    docstring : str
        predicted docstring, indented by four spaces and triple quote 
        delimited
    """
    assert style in DOCSTRING_STYLES
    parts = [f'# target docstring style {style}']
    if not example[0] and not example[2]:
        return ''
    if example[0]:
        parts.append(example[0])
    if example[2]:
        parts.append(dedent(indent(example[2], ' ' * 4)))
    return model.translate('\n'.join(parts), beam=7, temperature=1.)


class ModelInterface:
    """
    Contains the skeleton of pre- and post-processing
    for method-docstring translation
    """

    post_replace = {
        "Ġ": " ",
        "Ċ": "\n",
        "ĉ": "\t",
        "NEWLINE": "\n",
        "<user_handle>": "param",
    }
    pre_replace = dict([])

    def encode(self, method_text):
        """pre-process and tokenize to prepare for model"""

    def decode(self, hypothesis):
        """Remove whitespace and other encodings"""
        for src, tgt in self.post_replace.items():
            hypothesis = hypothesis.replace(src, tgt)
        return hypothesis

    def decode_batch(self, hypotheses):
        """Remove whitespace and other encodings"""
        return [ self.decode(hypothesis) for hypothesis in hypotheses ]

    def get_hypothesis(self, encoded, **kwargs):
        """get hypothesis from model using encoded source"""

    def get_hypotheses(self, encodeds, **kwargs):
        """get hypotheses from model using encoded sources"""

    def translate(self, method_text, **kwargs):
        """translate method_text into a docstring"""
        return self.decode(self.get_hypothesis(self.encode(method_text), **kwargs))

    # def translate_batch(self, method_texts, **kwargs):
    #     """translate method_texts into docstrings"""
    #     #import pdb; pdb.set_trace()
    #     encodeds = [ self.encode(method_text) for method_text in method_texts ]
    #     return self.decode_batch(self.get_hypotheses(encodeds, **kwargs))
    def translate_batch(self, method_texts, **kwargs):
        """translate method_texts into docstrings"""
        #import pdb; pdb.set_trace()
        encodeds = [ self.encode(method_text) for method_text in method_texts ]
        hypotheses, hypotheses_spaces = self.get_hypotheses(encodeds, **kwargs)
        return [ self.decode_batch(hypotheses), hypotheses_spaces ]


class FairseqModelInterface(ModelInterface):
    """
    Contains the pre-processing and model loading for
    a fairseq transformer translation model
    """

    def load_model(self, args):
        """
        Initialize fairseq translation model

        Parameters
        ----------
        datadir : str, path
            directory containing the fairseq-preprocessed source and
            target dictionaries
        checkpont : str, path
            path to fairseq checkpoint weights
        tokenizer_prefix : str, path
            prefix path to which '-vocab.json' and '-merges.txt' will
            be appended to find the merges/vocab files for the tokenizer
        pre_replace : dict (optional)
            an optional dict mapping strings to be applied before tokenization
        """
        self.pre_replace = getattr(args, 'pre_replace', dict([]))

        vocab = str(args.tokenizer_prefix) + "-vocab.json"
        merges = str(args.tokenizer_prefix) + "-merges.txt"
        self.tokenizer = ByteLevelBPETokenizer(vocab, merges)

        #self.model = TransformerModel.from_pretrained(
        self.model = HuggingFaceGPT2LanguageModel.from_pretrained(
                args.model_name_or_path,
                checkpoint_file=args.checkpoint_file,
                data_name_or_path=args.data_name_or_path,
        )
        print(type(self.model))
        #import pdb; pdb.set_trace()
        if torch.cuda.is_available():
            self.model.cuda()

    def encode(self, method_text):
        """encode source method_text for model consumption"""
        for src, tgt in self.pre_replace.items():
            method_text.replace(src, tgt)
        return " ".join(self.tokenizer.encode(method_text).tokens)

    def get_hypothesis(self, encoded, **kwargs):
        """obtain hypothesis output from model"""
        if "beam" not in kwargs:
            kwargs["beam"] = 7
        if "temperature" not in kwargs:
            kwargs["temperature"] = 1.0
        
        #import pdb; pdb.set_trace()
        return self.model.translate(encoded, skip_invalid_size_inputs=True, **kwargs).replace(" ", "")
        #return self.model.generate(encoded, **kwargs).replace(" ", "")
    
    def get_hypotheses(self, encodeds, **kwargs):
        """obtain hypothesis output from model"""
        if "beam" not in kwargs:
            kwargs["beam"] = 5
        if "temperature" not in kwargs:
            kwargs["temperature"] = 1.0
        
        #import pdb; pdb.set_trace()
        hypotheses_spaces = self.model.translate(encodeds, skip_invalid_size_inputs=True, **kwargs)
        hypotheses = [ hypothesis.replace(" ", "") for hypothesis in hypotheses_spaces ]
        return hypotheses, hypotheses_spaces
        #return self.model.generate(encoded, **kwargs).replace(" ", "")


if __name__ == "__main__":

    import os
    os.environ["CUDA_VISIBLE_DEVICES"]="3"

    TEST_METHOD = '''def add_insect(self, insect):
    if insect.is_ant:
        if (self.ant is None):
            self.ant = insect
        elif self.ant.can_contain(insect):
            self.ant.ant = insect
        elif insect.can_contain(self.ant):
            insect.ant = self.ant
            self.ant = insect
        else:
            assert (self.ant is None), 'Two ants in {0}'.format(self)
    else:
        self.bees.append(insect)
    insect.place = self'''

    # ROOT = Path(
    #     "/smartml-athena/processed-data/fundef-docstrings/split/"
    #     "translate-method-docstring"
    # )
    #MODEL_PATH = ROOT / "fairseq/2020-02-25/"
    #MODEL_PATH = "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_docstrings/docstrings"
    
    MODEL_PATH = "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq_models/random_init_2/methods"
    # MODEL_PATH = "/tufanodata/jotimc/model_ckpt-model276568283026485455852514477825382606654_vocab302164004049142335615305348341560879148/"

    #DATA_PATH = str(ROOT / "fairseq/binary_javadoc_problems")
    # DATA_PATH = "/tufanodata/jotimc/gpt2experiment_sync/split/gpt2-method-gen/fairseq-preprocess-output/"
    DATA_PATH = "/home/jotimc/mycontainer/jotimc/gpt2experiment/fairseq-preprocess-output/methods"
    # TOKENIZER_PREFIX = str(
    #     ROOT / "python-func-def-docstrings-2020-02-21-2026_bytelevelbpe_30000"
    # )
    TOKENIZER_PREFIX = Path("/home/jotimc/mycontainer/jotimc/universal_tokenizer/universal_tokenizer/roberta_aug_spaces")
    #CHECKPOINT = "jotimc/gpt2experiment/fairseq_models/english_pretrained_2/methods/checkpoint_best.pt"
    CHECKPOINT = "checkpoint_best.pt"
    # CHECKPOINT = "model-1.pt"

    args = Args(
            model_name_or_path=MODEL_PATH,
            data_name_or_path=DATA_PATH,
            tokenizer_prefix=TOKENIZER_PREFIX,
            checkpoint_file=CHECKPOINT,
    )
    #import pdb; pdb.set_trace()
    MODEL = FairseqModelInterface()
    MODEL.load_model(args)

    # list of length 3, containing [signature, docstring, body]
    example = ["def print_arg(arg):", "'''prints arg.'''",""]
    example2 = ["def print_elements_in_list(list):", "'''prints each element in list.'''",""]
    s = generate_method(example, MODEL)
    print(s)
    s2 = generate_method(example2, MODEL)
    print(s2)
    #MODEL.get_hypothesis(MODEL.encode(TEST_METHOD))
    # s3 = MODEL.model.decode(MODEL.encoded("text to encode"))
    # print(s3)




    # MODEL.model.forward(" ".join(MODEL.tokenizer.encode("def test(): \n'''does a test'''").tokens))
    # MODEL.encode("def test(): \n'''does a test'''")     # does the same thing 
    # # MODEL.model.forward()
    # # MODEL.model.encode
    # # MODEL.model.tokenize("klsd ")
    # # MODEL.model.tokenizer.
    # # MODEL.tokenizer.encode().tokens

    # MODEL.model.forward
    # MODEL.model.models[0].forward


    s_list = generate_methods([["def print_list(list):", "",""], ["def print_every_other_element(list):","prints every other element in the list",""]], MODEL)
    print(s_list)


    s_list_2 = generate_methods_simple(['''def print_list(list):\n  """prints \nthe \nlist"""''', '''def print_well():\n """prints well"""'''], MODEL)
    print(s_list_2)

    s_list_3 = generate_methods_simple(['''def factorial(x):\n    """Compute the factorial of x"""''',], MODEL)
    print(s_list_3)
