export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"
export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq/dawn-tokenized-javadoc-problems"
export DAWNDIR="/lustre/colin/data/docstrings/data/dawn-py-pretrained/forColin"
export PREFIX="python-func-def-docstrings-2020-02-21-2026"
# fixed @<user_handle> and javadoc collision
#export PREFIX="python-func-def-docstrings-2020-03-04-2336"

fairseq-preprocess \
    --source-lang 'methods' \
    --target-lang 'docstring' \
    --trainpref $DATADIR/$PREFIX.train \
    --validpref $DATADIR/$PREFIX.val \
    --testpref $DATADIR/$PREFIX.test \
    --destdir $DATADIR/binary \
    --workers 90 \
    --srcdict $DAWNDIR/use_this_one_dict.src.txt \
    --tgtdict $DAWNDIR/use_this_one_dict.src.txt \
    #--srcdict $DATADIR/binary_javadoc_problem/dict.methods.txt \
    #--tgtdict $DATADIR/binary_javadoc_problem/dict.docstring.txt \
    #--joined-dictionary \
