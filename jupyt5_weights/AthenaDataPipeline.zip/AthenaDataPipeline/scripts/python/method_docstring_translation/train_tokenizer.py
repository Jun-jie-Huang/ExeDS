from pathlib import Path
from athenadatapipeline.tokenizer import train


DIRECTORY = Path('/smartml-athena/processed-data/fundef-docstrings/split/translate-method-docstring')
FILE_NAMES = [
        DIRECTORY / name for name in 
        [
            'python-func-def-docstrings-2020-02-21-2026.methods.train.json.gz',
            'python-func-def-docstrings-2020-02-21-2026.docstring.train.json.gz',
        ]
]

train(FILE_NAMES, 30_000)
