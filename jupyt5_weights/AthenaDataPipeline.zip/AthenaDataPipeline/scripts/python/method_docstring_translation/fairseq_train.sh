export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"

export TOTAL_NUM_UPDATES=1300000
export WARMUP_UPDATES=5000
export LR=9.1875e-05
# effectively sets batch_size
export MAX_TOKENS=6600
export MAX_SENTENCES=32
export UPDATE_FREQ=8  # gradient accumulation
export DIR="$DATADIR/dawn-tokenized-javadoc-problems/binary"
export SAVEDIR="$DATADIR/2020-03-29-pretrained/" 

# leave one gpu for eval
export CUDA_VISIBLE_DEVICES="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15"
fairseq-train $DIR \
    --max-tokens $MAX_TOKENS \
    --max-sentences $MAX_SENTENCES \
    --task translation \
    --source-lang methods --target-lang docstring \
    --share-all-embeddings \
    --share-decoder-input-output-embed \
    --arch transformer \
    --dropout 0.2 --relu-dropout 0.2 --attention-dropout 0.2 \
    --encoder-embed-dim 1472 --decoder-embed-dim 1472 \
    --max-target-positions 1024 --max-source-positions 1024 \
    --encoder-ffn-embed-dim 4096 --decoder-ffn-embed-dim 4096 \
    --encoder-attention-heads 8 --decoder-attention-heads 8 \
    --criterion label_smoothed_cross_entropy \
    --label-smoothing 0.1 \
    --dropout 0.1 --attention-dropout 0.1 \
    --weight-decay 0.0001 --optimizer adam \
    --clip-norm 0.1 \
    --lr-scheduler inverse_sqrt --lr $LR --warmup-updates $WARMUP_UPDATES \
    --update-freq $UPDATE_FREQ \
    --skip-invalid-size-inputs-valid-test \
    --save-dir $SAVEDIR \
    --save-interval 1 \
    --fp16 --adam-betas '(0.9,0.98)' --adam-eps 1e-6 \
    --tensorboard-logdir /home/coclemen/tensorboard/fea06dc3-1ec5-4af5-af8d-0067514c1a43/logs/2020-03-29-pretrained \
    --ddp-backend=no_c10d \
    --reset-lr-scheduler \
    --reset-optimizer \
    #--fp16-scale-window 128 \
