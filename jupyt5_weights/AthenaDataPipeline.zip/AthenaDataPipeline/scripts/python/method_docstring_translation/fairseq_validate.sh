export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"

export TOTAL_NUM_UPDATES=1300000
export WARMUP_UPDATES=5000
export LR=9.1875e-05
# effectively sets batch_size
export MAX_TOKENS=6600
export MAX_SENTENCES=32
export UPDATE_FREQ=8  # gradient accumulation
export DIR="$DATADIR/dawn-tokenized-javadoc-problems/binary"
export SAVEDIR="$DATADIR/2020-03-29-pretrained" 

# leave one gpu for eval
#export CUDA_VISIBLE_DEVICES="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15"

fairseq-validate $DIR \
    --path $SAVEDIR/checkpoint153.pt \
    --results-path $SAVEDIR/evaluate \
    --max-tokens $MAX_TOKENS \
    --max-sentences $MAX_SENTENCES \
    --task translation \
    --source-lang methods --target-lang docstring \
    --criterion label_smoothed_cross_entropy \
    --label-smoothing 0.1 \
    --skip-invalid-size-inputs-valid-test \
    #--fp16-scale-window 128 \
