from pathlib import Path
from athenadatapipeline.splitdata import split_serialize_data

DATA_DIR = Path('/smartml-athena/processed-data/fundef-docstrings/')
JSON_GZ = DATA_DIR / 'python-func-def-docstrings-2020-03-04-2336.json.gz'

CRAWLDIRS = [
        '/smartml-athena/src-data/python/ziBjatNZRky2slnfFbZg2A/Git/1.0/',
        '/smartml-athena/all-git-repos',
        '/bigdata/git-repos/python',
    ]

split_serialize_data(JSON_GZ, CRAWLDIRS, dir_suffix='split/translate-method-docstring')
