

#export DATADIR="/lustre/colin/data/docstrings/data/translate-method-docstring/fairseq"
export DATADIR="/smartml-athena/processed-data/fundef-docstrings/split/translate-method-docstring/fairseq"
export PREFIX="python-func-def-docstrings-2020-02-21-2026"

export DIR="$DATADIR/binary_javadoc_problems"
export SAVEDIR="$DATADIR/2020-02-25" 

export CUDA_VISIBLE_DEVICES=0
fairseq-generate $DIR \
    --path $SAVEDIR/checkpoint_best.pt \
    --gen-subset test \
    --batch-size 32 --beam 5 \
    --results-path $SAVEDIR/generated \
    --num-workers 2 \
    --skip-invalid-size-inputs-valid-test \
    --empty-cache-freq 1 \
