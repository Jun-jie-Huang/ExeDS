from pathlib import Path
import logging
from itertools import product
from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline import load_zip_json

LOGGER = logging.getLogger(__name__)

DIRECTORY = Path('/smartml-athena/processed-data/fundef-docstrings/split/translate-method-docstring')
PREFIX = 'python-func-def-docstrings-2020-02-21-2026'

DAWNDIR = Path('/smartml-athena/processed-data/fundef-docstrings/dawn-py-pretrained/forColin')
VOCAB_PREFIX = 'hacky_byte_level'
VOCAB = DAWNDIR / (VOCAB_PREFIX + '-vocab.json')
MERGES = DAWNDIR / (VOCAB_PREFIX + '-merges.txt')

DATA_FILES = [
        DIRECTORY / (PREFIX + f'.{sub}.{typ}.json.gz')
        for typ, sub in product(['docstring', 'methods'], ['train', 'test', 'val'])
]

def decompress_name(filepath):
    nameparts = filepath.name.split('.')
    return '.'.join([n for n in nameparts if not n in ['json', 'gz']])

def prepare(datafiles=DATA_FILES, vocab=VOCAB, merges=MERGES, subdir='dawn-fairseq-javadoc-problems'):
    tokenizer = ByteLevelBPETokenizer(str(vocab), str(merges))
    print("USING DAWN'S TOKENIZER and NEWLINE HACK")
    for df in datafiles:
        directory = df.parent / subdir
        if not directory.exists():
            directory.mkdir()

        newfile = directory / decompress_name(df)
        with newfile.open('w') as fout:
            dat = [d.replace('\n', 'NEWLINE') for d in load_zip_json(df)]
            for tok in tokenizer.encode_batch(dat):
                fout.write(' '.join(tok.tokens) + '\n')

if __name__ == '__main__':
    prepare()
