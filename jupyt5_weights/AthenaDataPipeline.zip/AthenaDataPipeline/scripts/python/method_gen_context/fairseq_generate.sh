#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value storage.root`
RUN_PREFIX=`cat $CONF | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat $CONF | shyaml get-value source.process`
FILEPREFIX=`cat $CONF | shyaml get-value storage.file_prefix`

CHECKPOINT_NAME=`cat $CONF | shyaml get-value generate.checkpoint_name`

CHECKPOINT_DIRNAME=`cat $CONF | shyaml get-value train.checkpoint_dir_name`
GEN_CHECKPOINT_DIRNAME=`cat $CONF | shyaml get-value generate.checkpoint_dir_name 2>/dev/null`
if [[ $? -eq 0 ]]; then
    CHECKPOINT_DIRNAME=$GEN_CHECKPOINT_DIRNAME
else
    CHECKPOINT_DIRNAME=$DATADIR/$CHECKPOINT_DIRNAME
fi

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
DIR="$DATADIR/binary"
SAVEDIR="$CHECKPOINT_DIRNAME"
CHECKPOINT_NAME="$CHECKPOINT_DIRNAME/$CHECKPOINT_NAME"

echo "CHECKPOINT_DIRNAME=$CHECKPOINT_DIRNAME"
echo "DATADIR=$DATADIR"
echo "SAVEDIR=$SAVEDIR"
echo "CHECKPOINT_NAME=$CHECKPOINT_NAME"

SUFFIXLIST=(`cat $CONF | shyaml get-values data.task_labels`)
SUBSETLIST=("test")
for ((i = 1; i < ${#SUFFIXLIST[@]}; i++)); do
    SUBSETLIST+=("test$i")
done

#export CUDA_VISIBLE_DEVICES=`cat $CONF | shyaml get-value generate.cuda_device`
#echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
SUBSET="`cat $CONF | shyaml get-value generate.subset`"

#for SUBSET in "${SUBSETLIST[@]}"; do
for SHARD in {0..3}; do

    #echo "Generating $SUBSET"
    export CUDA_VISIBLE_DEVICES=$SHARD
    echo "Shard $SHARD"
    fairseq-generate $DIR \
      --path $CHECKPOINT_NAME \
      --gen-subset $SUBSET \
      --batch-size 16 \
      --beam 5 \
      --results-path $SAVEDIR/"generated-$SUBSET/shard-$SHARD" \
      --num-workers 4 \
      --skip-invalid-size-inputs-valid-test \
      --num-shards 4 \
      --shard-id $SHARD \
      & \
      #--max-tokens 6000 \
      #--empty-cache-freq 1 \

done
