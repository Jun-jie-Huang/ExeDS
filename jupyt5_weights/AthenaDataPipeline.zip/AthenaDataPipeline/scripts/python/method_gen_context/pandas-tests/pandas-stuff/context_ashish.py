'''
Context to use when executing ground-truth Python program for benchmarks authored by Ashish.
Note that the context is valid Python code, but it also has markers GPT3 needs to identify Q&A pairs.
'''

context_ashish="""
import pandas as pd
import numpy as np
import regex
import datetime

#q: initialize the dataframe a:
df = pd.DataFrame([
    ["10/2/2020", "CA", 29, "(ab)2", 23, 3, 45],
    ["10/9/2020", "FL", 32, "(sd)4", 20, 4, 21],
    ["10/2/2020", "FL", 43, "(ds)5", 18, 9, 32],
    ["10/9/2020", "WA", 53, "(ab)9", 21, 1, 98],
    ["10/9/2020", "", 53, "(ab)9", 21, 1, 98  ] ])

#q: name columns of df as Date, State, Death, Positive, Negative, Pending, Total a:
df.columns = ["Date","State","Death","Positive","Negative","Pending","Total"]

#q:"""
