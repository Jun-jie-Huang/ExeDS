import csv
import re
from pathlib import Path
from collections import defaultdict

from ftfy import fix_text
from textwrap import indent

from tree_sitter import Parser
from athenacommon.tree_sitter import get_language
from source_parser.parsers import PythonParser

CSV_FILE = 'pandas-stuff/gpt3-pandas-filtering.csv'
CSV_BENCHMARK_FILE = 'pandas-stuff/benchmarks/PandasBenchmarkCleaned.csv'
CONTEXT_ASHISH = open('pandas-stuff/context_ashish_exec.py').read()
CONTEXT_ELSE = open('pandas-stuff/context_not_ashish_exec.py').read()

GEN_TESTS_DIR = Path('generated-tests')

PARSER = Parser()
PARSER.set_language(get_language('python'))
PYTHON_PARSER = PythonParser()

def read_csv(csv_file):
    with open(csv_file, newline='') as csvfile:
        return list(csv.reader(csvfile))

def is_assignment(code, parser=PARSER):
    tree = parser.parse(code.encode('utf-8'))
    node = tree.root_node.children[0].children[0]
    if node.type == 'assignment':
        return True
    return False

def modify_to_copy(method):
    lines = method.splitlines()
    lines[-1] = lines[-1].replace('(df)', '(df.copy(deep=True))')
    return '\n'.join(lines)

RE_METHOD_NAME = re.compile('def ([a-zA-Z0-9_]+)\(')

def get_method_name(method):
    return RE_METHOD_NAME.findall(method)[0]


NAME_BLOCK = """

if __name__ == '__main__':
"""

def form_test(benchmark_gen_pair):
    nl = f"#q: {benchmark_gen_pair[1][0]}"
    tgt = benchmark_gen_pair[1][2]
    hyp = nl + '\n' + fix_text(benchmark_gen_pair[1][3])
    hyp_method = '\n'.join(hyp.splitlines()[:-1])
    method_name = get_method_name(hyp)
    file_path = GEN_TESTS_DIR / f"test_{method_name}.py"

    author = benchmark_gen_pair[0][3].casefold()
    if author == 'ashish':
        context = CONTEXT_ASHISH
    else:
        context = CONTEXT_ELSE

    test_segments = [
            context,
            hyp_method,
            NAME_BLOCK,
            f"    ret = {method_name}(df.copy(deep=True))"
    ]

    if is_assignment(tgt):
        test_segments.append(indent(tgt, ' ' * 4))
        test_segments.append("    assert df == ret")
    else:
        test_segments.append(f"    assert {tgt} == ret")
    return '\n'.join(test_segments), file_path


if __name__ == "__main__":
    DATA = read_csv(CSV_FILE)
    HEADER = DATA[0]
    DATA = DATA[2::2]

    BENCHMARKS = read_csv(CSV_BENCHMARK_FILE)
    HEADER_BENCHMARKS = BENCHMARKS[0]
    BENCHMARKS = BENCHMARKS[2::2]

    NL_DICT = defaultdict(list)
    for B in BENCHMARKS:
        NL_DICT[B[0]].append(B)
    for D in DATA:
        NL_DICT[D[0]].append(D)

    NL_LIST = [v for v in NL_DICT.values() if len(v) == 2]
    for PAIR in NL_LIST:
        test, path = form_test(PAIR)
        print(path)
        print(test)
        with path.open('w') as fout:
            fout.write(test)
