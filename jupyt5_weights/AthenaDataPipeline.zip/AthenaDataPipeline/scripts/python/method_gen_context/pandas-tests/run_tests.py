from shlex import split
from pathlib import Path
from subprocess import check_call, CalledProcessError

GEN_TESTS_DIR = Path('generated-tests')
TESTS =[test for test in GEN_TESTS_DIR.iterdir() if test.suffix == '.py']

PASS = 0
for test in TESTS:
    try:
        code = check_call(split(f"python {test}"))
        print(f"test passed")
        PASS += 1
    except CalledProcessError as c_err:
        print(f"test failed")

print(f"{PASS/len(TESTS)*100}% passed")
