"""
split_serialize.py


"""

import os
import re
import argparse
from pathlib import Path
from itertools import chain, repeat, cycle, islice
from textwrap import indent

from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline.model.utils.python import format_docstring
from athenadatapipeline.model.utils.python.classify_docstrings import (
    get_class,
    is_template,
)
from athenadatapipeline.splitdata import split_serialize
from athenadatapipeline.collater import Collater
from athenadatapipeline.config import load_conf


def roundrobin(*iterables):
    """roundrobin('ABC', 'D', 'EF') --> A D E B F C"""
    # Recipe credited to George Sakkis
    num_active = len(iterables)
    nexts = cycle(iter(it).__next__ for it in iterables)
    while num_active:
        try:
            for nxt in nexts:
                yield nxt()
        except StopIteration:
            # Remove the iterator we just exhausted from the cycle.
            num_active -= 1
            nexts = cycle(islice(nexts, num_active))


RE_DUNDER = re.compile('^__[A-Za-z0-9_]+__$')


class MethodContextCollater(Collater):
    """
    This collater reads a single Python source file
    processed into a source-parser schema, finds all
    methods and class methods, and for each it produces
    the 6 strings described in dataset_labels:
        source -> target
        "sig+doc+context" -> "body"
        "sig+body+context" -> "doc"
        "doc+context" -> "sig+body"
    Here, sig = method signature, doc = method docstring,
    body = method body, and context is a combination of file-level
    features which depend on the focal method and the lengths of
    each feature and the token_budget of the target model (usually 102
    tokens).

    The context is formed by a scoped priority, subject to the
    token budget. After the focal method's own source features
    (including class definition and class attributes if present
    for a class method) we then try to add import statements,
    global assignments, and then loop over every other method in
    the file, first adding signatures, then docstrings, and finally
    if budget allows, code bodies. The final feature added may be
    truncated in-scope to fill the token budget.
    """

    # these are the names of each type of source and target
    # Each method for each file will produce all of these feature types
    _dataset_labels = (
        "sig+doc+context",  # -> target body
        "sig+body+context",  # -> target doc
        "doc+context",  # -> target sig+body
        "body",
        "doc",
        "sig+body",
    )

    source_labels = (
        "sig+doc+context",  # -> target body
        "sig+body+context",  # -> target doc
        "doc+context",  # -> target sig+body
    )
    target_labels = (
        "body",
        "doc",
        "sig+body"
    )
    # this becomes part of the file name
    task_label = "context-method-docstring"

    # key - source_label, value - control code imperatives
    imperative_templates = {
        "sig+doc+context": "# target body",
        "sig+body+context": "# target doc",
        "doc+context": "# target sig+body",
    }

    def __init__(
        self, tokenizer_prefix, model_width=1024, method_per_file_limit=200,
    ):
        """
        Parameters
        ----------
        tokenizer_prefix : str
            prefix for tokenizer vocab and merges files
        (optional)
        model_width : int
            the number of tokens allowed in the input/output of the target model
        method_per_file_limit : int
            the maximum number of methods and class methods per file,
            files with greater than this number of methods will be ignored
        """
        super().__init__(tokenizer_prefix)
        # fairseq models add at most 3 control tokens
        assert model_width > 3
        self.token_budget = model_width - 3
        self.method_per_file_limit = method_per_file_limit

    @staticmethod
    def num_methods(file_dict):
        """the number of methods and class methods in file represented by file_dict"""
        n = len(file_dict['methods'])
        for clss in file_dict['classes']:
            n += len(clss['methods'])
        return n

    @staticmethod
    def get_imports_globals(file_dict, include_dunders=False):
        """
        Extract and annotate import statements and global variable assignments

        Parameters
        ----------
        file_dict: dict
            a source_parser schematized source code file
        (optional)
        include_dunders: True/False
            whether to include variable names with double underscores in them
            (usually things like __version__, etc)

        Returns
        -------
        imports, globes: list, list
            imports is a list of strings of individual import statements
                ['import blah', 'from blee import foo', ...]
            globes is a list of dictionaries of 'features' with keys labeled
                as method features to match the priority levels corresponding to method features
                    {
                      'signature': 'global variable name with prepended newline',
                      'docstring': '', # always empty
                      'body': 'assignment expression, = blah'
                    }
        """
        imports = []
        globes = []

        for ctx in file_dict["contexts"]:
            first = ctx.split()[0]
            if first == 'import' or first == 'from':
                imports.append(ctx)
            # double unders often include spurious license info
            elif include_dunders or not RE_DUNDER.match(first):
                globes.append({  # giving the same feature labels as methods
                    'signature': '\n' + first,
                    'docstring': '',
                    'body': ' '.join(ctx.split()[1:])
                })
        if imports:
            imports.extend([""] * 2)  # to get an extra newline nicely
        if globes:
            globes.append({  # add an empty line after
                    'signature': '\n\n', 'docstring': '', 'body': '',
            })

        return "\n".join(imports), globes

    def get_mapped_tokenization(self, file_dict):
        """
        Take a source-parser schema for a single Python file as file_dict,
        partition the file into structures like import statements, signatures,
        docstrings, bodies, classes, global statements, etc, and create a
        mapping between the schema elements and the elements of the partitioned file.
        Then tokenize the partition, so we can ensure we adhere to token budgets.

        NOTE: by feature here I mean any logically or semantically related
        segment of a Python file

        Parameters
        ----------
        file_dict : dict
            source-parser schema dictionary for a single Python file

        Returns
        -------
        tokenized_features, methods, index_map : list, list, dict
            tokenized_features is a list of lists of tokens of the partitioned
                Python file
            methods is a list of keys of index_map corresponding to methods and
                class methods
            index_map is a dictionary with keys as tuples representing elements
                of the file_dict schema, and values are the corresponding
                tokenized feature index of tokenized_features
        """
        index_map = {"imports": 0}
        imports, globes = self.get_imports_globals(file_dict)
        features = [imports]
        methods = []  # also global assignments and class methods and empty methods

        # global variables are priority 0, they values are priority 2
        for i, globe in enumerate(globes):
            feature_map = {
                "signature": ("globals", i, "signature"),
                "docstring": ("globals", i, "docstring"),  # always empty!
                "body": ("globals", i, "body"),
            }
            for feat in feature_map:
                features.append(globe[feat])
                index_map[feature_map[feat]] = len(index_map)
            methods.append(feature_map)

        for i, method in enumerate(file_dict["methods"]):
            feature_map = {
                "signature": ("methods", i, "signature"),
                "docstring": ("methods", i, "docstring"),
                "body": ("methods", i, "body"),
                "endtarget": ("methods", i, "endtarget"),
            }
            for source_label in self.imperative_templates:
                feature_map[source_label] = ("methods", i, source_label)

            signature = method["signature"] + "\n"

            docstring = ""
            doc_imperative = self.imperative_templates["sig+body+context"]
            if method["docstring"].strip():
                style = get_class(method["docstring"])
                doc_imperative += " style {}".format(style)
                if is_template(method["docstring"], style=style):
                    doc_imperative += " template"
                docstring = format_docstring(method["docstring"]) + "\n"

            body = ""
            if method["body"].strip().strip('pas'):  # ignore pass bodies
                body = indent(method["body"], " " * 4) + "\n\n"
            if not body:  # do not keep methods with empty bodies
                continue

            # imperatives
            features.append("\n" + self.imperative_templates["sig+doc+context"] + "\n")
            index_map[("methods", i, "sig+doc+context")] = len(index_map)
            # predict docstring from sig+body+context has style+template imperative
            features.append("\n" + doc_imperative + "\n")
            index_map[("methods", i, "sig+body+context")] = len(index_map)
            features.append("\n" + self.imperative_templates["doc+context"] + "\n")
            index_map[("methods", i, "doc+context")] = len(index_map)

            # method features
            features.append(signature)
            index_map[feature_map["signature"]] = len(index_map)
            features.append(docstring)
            index_map[feature_map["docstring"]] = len(index_map)
            features.append(body)
            index_map[feature_map["body"]] = len(index_map)

            features.append("# end\n\n")
            index_map[feature_map["endtarget"]] = len(index_map)

            methods.append(feature_map)

        classes = []
        for i, class_node in enumerate(file_dict["classes"]):

            # NOTE: indentation conventioned changed in the latest version of
            # the python extended-context dataset, so be sure to check whether 'indent'
            # is necessary
            index_map[("classes", i, "definition")] = len(index_map)
            features.append('\n' + class_node["definition"] + "\n")

            index_map[("classes", i, "class_docstring")] = len(index_map)
            if class_node["class_docstring"].strip():
                features.append(format_docstring(class_node["class_docstring"]) + "\n")
            else:
                features.append("")

            if "attribute_expressions" in class_node["attributes"]:
                for j, expression in enumerate(
                    class_node["attributes"]["attribute_expressions"]
                ):
                    index_map[
                        ("classes", i, "attributes", "attribute_expressions", j)
                    ] = len(index_map)

                    features.append(indent(expression, " " * 4) + "\n")

            if "classes" in class_node["attributes"]:
                for j, cls_node in enumerate(class_node["attributes"]["classes"]):
                    index_map[("classes", i, "attributes", "classes", j)] = len(
                        index_map
                    )
                    # NOTE:  just using the whole class within a class
                    features.append(cls_node["original_string"] + "\n")

            # empty method if class has no methods, so we can still get its context
            if not class_node["methods"]:
                feature_map = {
                    "signature": ("classes", i, "methods", 0, "signature"),
                    "docstring": ("classes", i, "methods", 0, "docstring"),
                    "body": ("classes", i, "methods", 0, "body"),
                }  # no 'endtarget' signals this is a placeholder for downstream
                for key in feature_map.values():
                    features.append('')
                    index_map[key] = len(index_map)
                methods.append(feature_map)

            for j, method in enumerate(class_node["methods"]):
                feature_map = {
                    "signature": ("classes", i, "methods", j, "signature"),
                    "docstring": ("classes", i, "methods", j, "docstring"),
                    "body": ("classes", i, "methods", j, "body"),
                    "endtarget": ("classes", i, "methods", j, "endtarget"),
                }
                for source_label in self.imperative_templates:
                    feature_map[source_label] = (
                        "classes",
                        i,
                        "methods",
                        j,
                        source_label,
                    )

                signature = indent(method["signature"] + "\n", " " * 4)

                docstring = ""
                doc_imperative = self.imperative_templates["sig+body+context"]
                if method["docstring"].strip():
                    style = get_class(method["docstring"])
                    doc_imperative += " style {}".format(style)
                    if is_template(method["docstring"], style=style):
                        doc_imperative += " template"
                    docstring = (
                        format_docstring(method["docstring"], n_indents=8) + "\n"
                    )

                body = ""
                if method["body"].strip():
                    body = indent(method["body"], " " * 8) + "\n\n"

                # imperative control codes are __before__ the method features
                features.append(
                    "\n" + " " * 4 + self.imperative_templates["sig+doc+context"] + "\n"
                )
                index_map[("classes", i, "methods", j, "sig+doc+context")] = len(
                    index_map
                )
                # predict docstring from sig+body+context has style+template imperative
                features.append("\n" + " " * 4 + doc_imperative + "\n")
                index_map[("classes", i, "methods", j, "sig+body+context")] = len(
                    index_map
                )
                features.append(
                    "\n" + " " * 4 + self.imperative_templates["doc+context"] + "\n"
                )
                index_map[("classes", i, "methods", j, "doc+context")] = len(index_map)

                # method features
                features.append(signature)
                index_map[feature_map["signature"]] = len(index_map)
                features.append(docstring)
                index_map[feature_map["docstring"]] = len(index_map)
                features.append(body)
                index_map[feature_map["body"]] = len(index_map)

                # control code indicating the focal method has ended
                features.append("    # end\n\n")
                index_map[feature_map["endtarget"]] = len(index_map)

                methods.append(feature_map)

        tokenized_features = [
            enc.tokens for enc in self.tokenizer.encode_batch(features)
        ]

        return tokenized_features, methods, index_map


    def _collate(self, file_dict):
        """
        After partitioning and tokenizing the Python file in file_dict,
        for each method and class method in the file, this function goes
        down this list of file features, adding things in order to the
        final source/target elements, until the token budget is exceeded.
        Then the last feature added is truncated to fit the token budget.
            1. imperative # target <target feature> (style <style>)
            2. focal method source features (+ class def/doc if class method)
            3. import statements
            4. global assignment names only
            5. all other non-focal methods/global expression
                i. signatures
                ii. docstrings
                iii. bodies and global expression values
        So this order defines a hierarchy with a finite token budget, in which
        higher things on the list are more likely to be included as sources

        Parameters
        ----------
        file_dict : dict
            source-parser schema dictionary for a single Python file

        Returns
        -------
        collated : dict
            collated['source and target labels'] = [
                list of sources and targets for each method in the Python file
            ]
            collated['url'] is the Git repo URL this Python file came from,
            used for splitting the data into train/test/valid sets.
        """
        collated = {label: [] for label in self.datasets}
        collated['url'] = file_dict['url']
        if self.num_methods(file_dict) > self.method_per_file_limit:
            return collated  # ignore super long files
        features, methods, index_map = self.get_mapped_tokenization(file_dict)
        num_tokens_per = list(map(len, features))

        def get_method_indices(focal, *args):
            """
            Return the indices of tokenized_features corresponding to
            the features of the focal method named in *args, e.g.
            get_method(feature_map, ('signature', 'docstring'))
            will return the indicies of the signature and docstring
            of the focal method. feature_map is a dictionary of tuples
            mapping keys like 'signature', 'docstring', and 'body' to
            tuples pointint to their file_dict schema elements.
            """
            return [index_map[focal[typ]] for typ in args]

        def get_features(methods):
            """
            makes a list of lists of the feautures of list of methods
            """
            return [
                [method[feat] for feat in ("signature", "docstring", "body")]
                for method in methods
            ]

        def get_class_attrs(class_i):
            """
            Given class_i index of class i in file_dict, create the feature_map
            for that class's attributes
            """
            class_node = file_dict["classes"][class_i]
            if "attribute_expressions" in class_node["attributes"]:
                return [
                    ("classes", class_i, "attributes", "attribute_expressions", j)
                    for j, expression in enumerate(
                        class_node["attributes"]["attribute_expressions"]
                    )
                ]
            return []

        def update(collated, label, budgets, *indicies):
            """
            Update the collated object for a given focal method
            with indicies of file features for source/target label,
            subtracting added tokens from the budget
            """
            for index in indicies:
                # go over budget then truncate later
                if budgets[label] > 0:  # num_tokens_per[index]:
                    collated[label].append(index)
                    budgets[label] -= num_tokens_per[index]

        for focal_method in methods:

            if 'endtarget' not in focal_method:
                continue  # skip placeholder methods for focal method

            budgets = {label: self.token_budget for label in self.datasets}
            focal_collated = {label: [] for label in self.datasets}
            def_classes = {  # key - class number, val - priority set
                label: {} for label in self.datasets
            }

            # craft targets
            for label, feat in zip(
                ["body", "doc", "sig+body"],
                [("body",), ("docstring",), ("signature", "body")],
            ):
                update(
                    focal_collated,
                    label,
                    budgets,
                    *get_method_indices(focal_method, *feat)
                )

            # craft sources
            for label, feat in zip(
                ["sig+doc+context", "sig+body+context", "doc+context"],
                [("signature", "docstring"), ("signature", "body"), ("docstring",)],
            ):
                # priority -1 imperative!
                update(focal_collated, label, budgets, index_map[focal_method[label]])

                # priority 0 class definition for class methods
                if focal_method["signature"][0] == "classes":
                    class_i = focal_method["signature"][1]
                    if not class_i in def_classes[label]:
                        def_classes[label][class_i] = 0  # set priority 0
                        def_ind = index_map[("classes", class_i, "definition")]
                        update(focal_collated, label, budgets, def_ind)

                # priority 0 focal method source features
                feat_ind = get_method_indices(focal_method, *feat)
                update(focal_collated, label, budgets, *feat_ind)
                update(
                    focal_collated, label, budgets, index_map[focal_method["endtarget"]]
                )

                # priority 1 add imports
                update(focal_collated, label, budgets, 0)

                # priority 2 class docstring and attributes
                if focal_method["signature"][0] == "classes":
                    class_i = focal_method["signature"][1]
                    if def_classes[label][class_i] < 2:  # doc/attr not set
                        def_classes[label][class_i] = 2

                    doc_ind = index_map[("classes", class_i, "class_docstring")]
                    update(focal_collated, label, budgets, doc_ind)

                    for attr_ind in [
                        index_map[attr] for attr in get_class_attrs(class_i)
                    ]:
                        update(focal_collated, label, budgets, attr_ind)

            # priority 4, 5, 6: global variables, non-focal method definitions, docstrings, bodies
            # global values are same priority as method bodies
            for method_feature in roundrobin(*get_features(methods)):

                if method_feature in focal_method.values():
                    continue  # do not repeate focal method features

                for label in self.source_labels:
                    if method_feature[0] == "classes":
                        class_i = method_feature[1]
                        if not class_i in def_classes[label]:
                            def_classes[label][class_i] = 0  # set priority 0
                            def_ind = index_map[("classes", class_i, "definition")]
                            update(focal_collated, label, budgets, def_ind)

                    update(focal_collated, label, budgets, index_map[method_feature])

                    if method_feature[0] == "classes":
                        class_i = method_feature[1]
                        if def_classes[label][class_i] < 2:
                            def_classes[label][class_i] = 2
                            doc_ind = index_map[("classes", class_i, "class_docstring")]
                            update(focal_collated, label, budgets, doc_ind)

            # combine tokenized features selected by the updating process above and
            # truncate the last one to fit within the token budget if it's excedes
            for src_tgt_labels in zip(self.source_labels, self.target_labels):

                src_tgt = []
                for label in src_tgt_labels:
                    truncated = [features[feat] for feat in focal_collated[label]]
                    if budgets[label] < 0:  # truncate last added feature
                        truncated[-1] = truncated[-1][: budgets[label]]
                    src_tgt.append(
                        " ".join(
                            [
                                token
                                for k in sorted(  # get tokenized features in file-order
                                    range(len(focal_collated[label])),
                                    key=lambda l: focal_collated[label][l],
                                )
                                for token in truncated[k]
                            ]
                        )
                    )

                for seq, label in zip(src_tgt, src_tgt_labels):
                    collated[label].append(seq)

        return collated


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())


if __name__ == "__main__":
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "conf.yaml"
    )
    conf = load_conf(path_to_conf)

    if 'combine_training' in conf["data"]:
        conf["data"]["combine_training"] = True
    else:
        conf["data"]["combine_training"] = False
    if 'combine_testval' in conf["data"]:
        conf["data"]["combine_testval"] = True
    else:
        conf["data"]["combine_testval"] = False

    json_zip = (
            Path(conf["storage"]["root"]) / conf["storage"]["file_prefix"]
    ).with_suffix('.json.lz4')

    split_serialize(
        json_zip,
        MethodContextCollater,
        (conf["vocab"]["bpe_prefix"],),
        run_name_prefix=conf['storage']['run_name_prefix'],
        head=conf["data"]["head"] if "head" in conf["data"] else None,
        thin=conf["data"]["thin"] if "thin" in conf["data"] else None,
        combine_training=conf["data"]["combine_training"],
        combine_testval=conf["data"]["combine_testval"],
        proportions=(conf["data"]["train_frac"], conf["data"]["val_frac"])
    )
