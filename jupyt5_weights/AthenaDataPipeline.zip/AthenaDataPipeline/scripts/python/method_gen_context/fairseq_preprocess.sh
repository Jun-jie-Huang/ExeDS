#!/bin/bash
#TODO: generalize to allow preprocessing individual subsets
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh myconf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value storage.root`
RUN_PREFIX=`cat $CONF | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat $CONF | shyaml get-value source.process`
WORKERS=`cat $CONF | shyaml get-value data.workers`
FILEPREFIX=`cat $CONF | shyaml get-value storage.file_prefix`

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
echo $DATADIR

SRC_DICT=`cat $CONF | shyaml get-value vocab.fairseq_src_dict`
TGT_DICT=`cat $CONF | shyaml get-value vocab.fairseq_tgt_dict 2>/dev/null`
if [[ $? -eq 0 ]]; then
    TGT_DICT="--tgtdict $TGT_DICT"
else
    TGT_DICT="--joined-dictionary"
fi

SUFFIXLIST=(`cat $CONF | shyaml get-values data.task_labels`)

for SUFFIX in "${SUFFIXLIST[@]}"
do
    if [ -z ${VALIDPREF+x} ]; then
        export VALIDPREF="$DATADIR/$FILEPREFIX.val_$SUFFIX"
        export TESTPREF="$DATADIR/$FILEPREFIX.test_$SUFFIX"
    else
        export VALIDPREF="$VALIDPREF,$DATADIR/$FILEPREFIX.val_$SUFFIX"
        export TESTPREF="$TESTPREF,$DATADIR/$FILEPREFIX.test_$SUFFIX"
    fi
    echo "$DATADIR/$FILEPREFIX.val_$SUFFIX"
    echo "$DATADIR/$FILEPREFIX.test_$SUFFIX"
done

fairseq-preprocess \
    -s 'src' -t 'tgt' \
    --srcdict $SRC_DICT \
    $TGT_DICT \
    --testpref $TESTPREF \
    --destdir $DATADIR/binary \
    --workers $WORKERS \
    --trainpref $DATADIR/$FILEPREFIX.train \
    --validpref $VALIDPREF \
