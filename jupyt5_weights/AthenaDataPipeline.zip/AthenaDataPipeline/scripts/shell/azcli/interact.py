from pathlib import Path
from athenadatapipeline.config import load_conf
from athenadatapipeline.model_init import FairseqModelInterface, Args


class AzCLIModelInterface(FairseqModelInterface):

    post_replace = {
        "Ġ": " ",
        "Ċ": "\n",
        "ĉ": "\t",
        "NEWLINE": "\n",
    }

    def __init__(self, delimiter, replace_delimiter):
        self.delimiter = delimiter
        self.replace_delimiter = replace_delimiter
        self.post_replace[replace_delimiter] = delimiter

    def encode(self, inpt):
        """encode source method_text for model consumption"""
        for src, tgt in self.pre_replace.items():
            inpt = inpt.replace(src, tgt)

        return f' {self.replace_delimiter} '.join([
            ' '.join(tok.tokens) for tok in self.tokenizer.encode_batch(inpt.split(self.delimiter))
        ])

path_to_conf = Path(__file__).absolute().parent / "conf-bart-large.yaml"
conf = load_conf(path_to_conf)

delimiter = conf["source"]["delimiter"]
replace_delimiter = conf["source"]["replace_delimiter"]
file_prefix = conf["storage"]["file_prefix"]
experiment = Path(conf["storage"]["root"]) / conf["storage"]["run_name_prefix"] / conf["source"]["process"]

args = Args(
        model_name_or_path=str(experiment / conf["interact"]["checkpoints"]),
        data_name_or_path=str(experiment / 'binary'),
        tokenizer_prefix=conf["vocab"]["bpe_prefix"],
        #checkpoint_file='checkpoint_last.pt',
        checkpoint_file='checkpoint_best.pt',
        pre_replace={}
)


if __name__ == "__main__":
    model = AzCLIModelInterface(delimiter, replace_delimiter)
    model.load_model(args)
