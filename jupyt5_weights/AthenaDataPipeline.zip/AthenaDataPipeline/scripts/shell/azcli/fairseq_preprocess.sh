#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value storage.root`
RUN_PREFIX=`cat $CONF | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat $CONF | shyaml get-value source.process`
FILEPREFIX=`cat $CONF | shyaml get-value storage.file_prefix`
SRC_DICT=`cat $CONF | shyaml get-value vocab.fairseq_src_dict`

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
echo $DATADIR

fairseq-preprocess \
    -s src -t tgt \
    --trainpref $DATADIR/$FILEPREFIX.train \
    --validpref $DATADIR/$FILEPREFIX.valid \
    --destdir $DATADIR/binary \
    --workers 6 \
    --srcdict $SRC_DICT \
    --tgtdict $SRC_DICT \
