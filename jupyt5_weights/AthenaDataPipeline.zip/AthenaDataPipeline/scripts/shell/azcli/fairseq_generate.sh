#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value storage.root`
RUN_PREFIX=`cat $CONF | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat $CONF | shyaml get-value source.process`
FILEPREFIX=`cat $CONF | shyaml get-value storage.file_prefix`

CHECKPOINT_DIRNAME=`cat $CONF | shyaml get-value train.checkpoint_dir_name`
CHECKPOINT_NAME=`cat $CONF | shyaml get-value generate.checkpoint_name`
echo "CHECKPOINT_DIRNAME=$CHECKPOINT_DIRNAME"
DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
echo "DATADIR=$DATADIR"
DIR="$DATADIR/binary"
SAVEDIR="$DATADIR/$CHECKPOINT_DIRNAME"
echo "SAVEDIR=$SAVEDIR"
CHECKPOINT_NAME="$SAVEDIR/$CHECKPOINT_NAME"
echo "CHECKPOINT_NAME=$CHECKPOINT_NAME"


export CUDA_VISIBLE_DEVICES=`cat $CONF | shyaml get-value generate.cuda_device`
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
fairseq-generate $DIR \
    --path $CHECKPOINT_NAME \
    --gen-subset valid \
    --beam 5 \
    --max-tokens 6600 \
    --results-path $SAVEDIR/"generated-$SUBSET" \
    --num-workers 2 \
    --skip-invalid-size-inputs-valid-test \
    #--empty-cache-freq 1 \
