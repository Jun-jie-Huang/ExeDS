"""

# bugs:
  * parameter values can be multiple space-seperated instances
    - e.g. az postgres server-logs download --name f1.log f2.log --resource-group testgroup --server-name testsvr
  * I leave off final flags which do not have parameters
    - e.g. az acr repository delete --image hello-world:latest --name -MyRegistry --yes

"""

import sys
sys.path.append('../')

import json
from pathlib import Path
from tqdm import tqdm
from interact import AzCLIModelInterface, delimiter, replace_delimiter, args

JSONFILE = Path('/home/coclemen/temp/knowledge_base_cli.json')
TYPEKEY = 'crawler-crafted'
NEWFILE = JSONFILE.parent / (JSONFILE.stem + '_athena.json')
CHANGEFILE = JSONFILE.parent / (JSONFILE.stem + '_athena_changes.txt')
DAT = json.load(JSONFILE.open())
NEWDAT = []

MODEL = AzCLIModelInterface(delimiter, replace_delimiter)
MODEL.load_model(args)


def mask_parameters(cmd, delimiter=delimiter):
    words = cmd.split()
    for i in range(len(words) - 1):
        if words[i].startswith('--') and not words[i + 1].startswith('--'):
            words[i + 1] = delimiter
    return ' '.join(words)


def new_parameters(cmd, model=MODEL):
    masked_cmd = mask_parameters(cmd)
    params = MODEL.translate(masked_cmd)
    cmd = []
    for word0, word1 in zip(masked_cmd.split(delimiter), params.split(delimiter)):
        cmd.extend([word0.strip(), word1.strip()])
    return ' '.join(cmd)

with CHANGEFILE.open('w') as change_out:
    change_out.write('old\n')
    change_out.write('new\n\n')

    for d in tqdm(DAT):
        if d['type'] == TYPEKEY:
            old = d['answer']
            d['answer'] = new_parameters(old)
            change_out.write(f'{old}\n')
            change_out.write(f"{d['answer']}\n\n")

json.dump(DAT, NEWFILE.open('w'))
