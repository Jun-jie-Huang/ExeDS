#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value storage.root`
RUN_PREFIX=`cat $CONF | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat $CONF | shyaml get-value source.process`
FILEPREFIX=`cat $CONF | shyaml get-value storage.file_prefix`

CHECKPOINT_DIRNAME=`cat $CONF | shyaml get-value train.checkpoint_dir_name`
ARCH=`cat $CONF | shyaml get-value train.arch`
TOTAL_NUM_UPDATES=`cat $CONF | shyaml get-value train.total_num_updates`
WARMUP_UPDATES=`cat $CONF | shyaml get-value train.warmup_steps`
LR=`cat $CONF | shyaml get-value train.lr`
MAX_TOKENS=`cat $CONF | shyaml get-value train.max_tokens`
UPDATE_FREQ=`cat $CONF | shyaml get-value train.update_freq`
LOGDIR_NAME=`cat $CONF | shyaml get-value train.logdir_name`

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
DIR="$DATADIR/binary"
SAVEDIR="$DATADIR/$CHECKPOINT_DIRNAME"

LOGDIR="$SAVEDIR/$LOGDIR_NAME"

export CUDA_VISIBLE_DEVICES=`cat $CONF | shyaml get-value train.cuda_visible_devices`

#TODO: setup conf for checkpointing

FINETUNE_FROM_MODEL=`cat $CONF | shyaml get-value train.finetune_from_model 2>/dev/null`
if [[ $? -eq 0 ]]; then
    FINETUNE_FROM_MODEL="--finetune-from-model $FINETUNE_FROM_MODEL"
else
    FINETUNE_FROM_MODEL=""
fi

export MKL_THREADING_LAYER="GNU"
fairseq-train $DIR \
    --arch $ARCH \
    --save-dir $SAVEDIR \
    --tensorboard-logdir $LOGDIR \
    --max-tokens $MAX_TOKENS \
    --task translation \
    --criterion label_smoothed_cross_entropy \
    --label-smoothing 0.1 \
    --share-all-embeddings \
    --share-decoder-input-output-embed \
    --dropout 0.1 --relu-dropout 0.1 --attention-dropout 0.1 \
    --weight-decay 0.001 --optimizer adam \
    --clip-norm 0.1 \
    --lr-scheduler inverse_sqrt --lr $LR --warmup-updates $WARMUP_UPDATES \
    --update-freq $UPDATE_FREQ \
    --skip-invalid-size-inputs-valid-test \
    --adam-betas '(0.9,0.98)' --adam-eps 1e-6 \
    --valid-subset valid \
    --ddp-backend=no_c10d \
    --fp16 --fp16-scale-window 128 --fp16-init-scale 2 \
    $FINETUNE_FROM_MODEL \
    --no-epoch-checkpoints \
