from pathlib import Path
from itertools import product, repeat
from tokenizers import ByteLevelBPETokenizer
from athenadatapipeline.config import load_conf


def clean(srcfile, tgtfile):
    """Remove empty lines and examples with no source or target"""
    src_tgt_pairs = []
    with open(srcfile) as sin, open(tgtfile) as tin:
        for sline, tline in zip(sin, tin):
            if sline.strip() and tline.strip():
                src_tgt_pairs.append([sline.rstrip(), tline.rstrip()])
    return src_tgt_pairs


def get_permutations(src, tgt, delimiter):
    src_split = src.split()
    tgt_split = tgt.split()
    delimiter_indices = [i for i in range(len(src_split)) if src_split[i] == delimiter]
    params = [t for t in tgt_split if not t == delimiter]
    examples = []
    for masks in product(*repeat([0, 1], len(params))):
        if not any(masks):
            continue  # do not use sample with no masks
        s_split = list(src_split)
        t_split = []
        for i, p, m in zip(delimiter_indices, params, masks):
            if not m:
                s_split[i] = p
            else:
                t_split.append(p)
        examples.append([" ".join(s_split), f" {delimiter} ".join(t_split)])
    return examples


def encode(line, tokenizer, delimiter, replace_delimiter):
    splitup = [
            " ".join(tok.tokens)
            for tok in tokenizer.encode_batch(line.split(delimiter))
    ]
    return f" {replace_delimiter} ".join(splitup) + "\n"


if __name__ == "__main__":

    path_to_conf = Path(__file__).absolute().parent / "conf.yaml"
    conf = load_conf(path_to_conf)

    bpe_prefix = conf["vocab"]["bpe_prefix"]
    tokenizer = ByteLevelBPETokenizer(
        bpe_prefix + "-vocab.json",
        bpe_prefix + "-merges.txt",
    )
    delimiter = conf["source"]["delimiter"]
    replace_delimiter = conf["source"]["replace_delimiter"]
    file_prefix = conf["storage"]["file_prefix"]
    root = Path(conf["storage"]["root"])

    src_tgt = ("src", "tgt")
    subsets = ("train", "valid")  # train first is important for de-duping
    file_pairs = [
        [root / f"{file_prefix}.{subset}.{feature}" for feature in src_tgt]
        for subset in subsets
    ]

    savedir = root / conf["storage"]["run_name_prefix"] / conf["source"]["process"]
    if not savedir.exists():
        savedir.mkdir(parents=True)

    train_set = set([])
    for srcfile, tgtfile in file_pairs:
        src_tgt_pairs = clean(srcfile, tgtfile)
        src_out = savedir / srcfile.name
        tgt_out = savedir / tgtfile.name
        print(srcfile.name, tgtfile.name)
        with src_out.open('w') as s_out, tgt_out.open('w') as t_out:
            for pair in src_tgt_pairs:
                if 'train' in srcfile.name and 'train' in tgtfile.name:
                    train_set.add(tuple(pair))
                else:
                    if tuple(pair) in train_set:
                        continue  # skip saving these pairs to validation set
                for src, tgt in get_permutations(*pair, delimiter):
                    s_out.write(encode(src, tokenizer, delimiter, replace_delimiter))
                    t_out.write(encode(tgt, tokenizer, delimiter, replace_delimiter))
