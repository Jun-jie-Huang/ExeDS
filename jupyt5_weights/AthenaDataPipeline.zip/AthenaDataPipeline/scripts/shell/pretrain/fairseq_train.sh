
#ROOT=`cat conf.yaml | shyaml get-value storage.root`
#RUN_PREFIX=`cat conf.yaml | shyaml get-value storage.run_name_prefix`
#SOURCEPROCESS=`cat conf.yaml | shyaml get-value source.process`
#FILEPREFIX=`cat conf.yaml | shyaml get-value storage.file_prefix`

ROOT="/lustre/colin/data/shell-pretrain/v0.4.2/"
RUN_PREFIX="experiment"
SOURCEPROCESS="verbatim"
FILEPREFIX="reposcrape-shell-context-2020-08-21-0357"

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS

export TOTAL_NUM_UPDATES=1300000
export WARMUP_UPDATES=500000
export LR=9.1875e-05

# effectively sets batch_size
export MAX_TOKENS=6000
export UPDATE_FREQ=8  # gradient accumulation

export DIR="$DATADIR/binary"
export SAVEDIR="$DATADIR/checkpoints-bart"

# leave one gpu for eval
#export CUDA_VISIBLE_DEVICES="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15"
fairseq-train $DIR \
    --arch bart_base \
    --save-dir $SAVEDIR \
    --tensorboard-logdir $SAVEDIR/tensorboard \
    --max-tokens $MAX_TOKENS \
    --task denoising \
    --seed 92089 \
    --mask-length span-poisson --mask 0.25 --rotate 0. \
    --permute 0.1 \
    --criterion cross_entropy \
    --share-all-embeddings \
    --share-decoder-input-output-embed \
    --dropout 0.1 --relu-dropout 0.1 --attention-dropout 0.1 \
    --weight-decay 0.001 --optimizer adam \
    --clip-norm 0.1 \
    --lr-scheduler inverse_sqrt --lr $LR --warmup-updates $WARMUP_UPDATES \
    --update-freq $UPDATE_FREQ \
    --skip-invalid-size-inputs-valid-test \
    --adam-betas '(0.9,0.98)' --adam-eps 1e-6 \
    --no-epoch-checkpoints \
    --valid-subset valid \
    --reset-optimizer \
    --reset-lr-scheduler \
    --sample-break-mode none \
    --ddp-backend=no_c10d \
    --fp16 --fp16-scale-window 128 --fp16-init-scale 2 \
    #--save-interval 1 \
    #--fp16-scale-window 128 \
