"""
split_serialize.py


"""

import os
import re
import argparse
from pathlib import Path
from itertools import islice

from tokenizers import ByteLevelBPETokenizer

from athenadatapipeline.splitdata import split_serialize
from athenadatapipeline.collater import Collater
from athenadatapipeline.config import load_conf


def batch_gen(iterator, bsz):
    iterator = iter(iterator)
    while True:
        nxt = list(islice(iterator, bsz))
        if not nxt:
            break
        yield nxt

class VerbatimCollater(Collater):
    """
    Collater which just tokenizes raw files
    """
    source_labels = (
        "verbatim",  # NO TARGET!
    )
    target_labels = ()
    task_label = "verbatim"

    def __init__(self, tok_prefix, sample_break=False, model_width=1024):
        super().__init__(tok_prefix)
        assert model_width > 3, 'model width must be greater than 3'
        self.sample_break = sample_break  # split samples longer than model_width
        self.model_width = model_width

    def _collate(self, file_dict):
        tokens = self.tokenizer.encode(file_dict['original_string']).tokens
        chunks = [tokens]
        if self.sample_break:
            chunks = list(batch_gen(tokens, self.model_width - 3))

        return {
                'url': file_dict['url'],
                self.source_labels[0]: [' '.join(toks) for toks in chunks]
        }


if __name__ == "__main__":
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "conf.yaml"
    )
    conf = load_conf(path_to_conf)

    json_zip = (
            Path(conf["storage"]["root"]) / conf["storage"]["file_prefix"]
    ).with_suffix('.json.lz4')

    split_serialize(
        json_zip,
        VerbatimCollater,
        (conf["vocab"]["bpe_prefix"],),
        run_name_prefix=conf['storage']['run_name_prefix'],
        head=conf["data"]["head"] if "head" in conf["data"] else None,
        thin=conf["data"]["thin"] if "thin" in conf["data"] else None,
        combine_training=True,
        combine_testval=True,
        proportions=(conf["data"]["train_frac"], conf["data"]["val_frac"]),
        source_only=True,
    )
