#!/bin/bash

ROOT=`cat conf.yaml | shyaml get-value storage.root`
RUN_PREFIX=`cat conf.yaml | shyaml get-value storage.run_name_prefix`
SOURCEPROCESS=`cat conf.yaml | shyaml get-value source.process`
FILEPREFIX=`cat conf.yaml | shyaml get-value storage.file_prefix`

DATADIR=$ROOT/$RUN_PREFIX/$SOURCEPROCESS
echo $DATADIR

SRC_DICT=`cat conf.yaml | shyaml get-value vocab.fairseq_src_dict`

fairseq-preprocess \
    --only-source \
    --trainpref $DATADIR/$FILEPREFIX.train \
    --validpref $DATADIR/$FILEPREFIX.val \
    --testpref $DATADIR/$FILEPREFIX.test \
    --destdir $DATADIR/binary \
    --workers 24 \
    --srcdict $SRC_DICT \
