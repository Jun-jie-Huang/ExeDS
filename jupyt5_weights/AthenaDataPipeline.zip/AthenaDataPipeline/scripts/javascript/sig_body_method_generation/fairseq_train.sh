export CUDA_VISIBLE_DEVICES="0,1,2"
#export MKL_THREADING_LAYER=GNU

# Use non-default anaconda environment
source ~/anaconda3/etc/profile.d/conda.sh
conda activate py36

#export KMP_INIT_AT_FORK="FALSE"

export DATADIR="/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/fairseq/sig_body_method_generation"

export MAX_TOKENS=1100
export MAX_SENTENCES=128
export DIR="$DATADIR/binary"
export SAVEDIR="$DATADIR/2020-07-28-pretrained"
export UPDATE_FREQ=32  # gradient accumulation
export LR=9.1875e-04
#export CUDA_VISIBLE_DEVICES env variable
export WARMUP_UPDATES=5000

fairseq-train $DIR \
    --max-tokens $MAX_TOKENS \
    --max-sentences $MAX_SENTENCES \
    --task translation \
    --source-lang 'signature' --target-lang 'body' \
    --arch bart_large \
    --dropout 0.2 --attention-dropout 0.2 \
    --criterion label_smoothed_cross_entropy \
    --label-smoothing 0.1 \
    --dropout 0.1 --attention-dropout 0.1 \
    --weight-decay 0.0001 --optimizer adam \
    --clip-norm 0.1 \
    --lr-scheduler inverse_sqrt --lr $LR --warmup-updates $WARMUP_UPDATES \
    --update-freq $UPDATE_FREQ \
    --skip-invalid-size-inputs-valid-test \
    --save-dir $SAVEDIR \
    --save-interval 1 \
    --adam-betas '(0.9,0.98)' --adam-eps 1e-6 \
    --tensorboard-logdir /home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/fairseq/sig_method_body_generation/logs/2020-07-28-pretrained \
    --log-interval 5 \
    --reset-lr-scheduler \
    --reset-optimizer \
    --ddp-backend=no_c10d \
    --num-workers 4 \
    #--train-subset test \
    #--fp16 \
    #--fp16-scale-window 128 \
    #--share-all-embeddings \
    #--share-decoder-input-output-embed \
    #--relu-dropout 0.2
