export DATADIR="/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/fairseq/sig_body_method_generation"

export DIR="$DATADIR/binary"
export SAVEDIR="$DATADIR/2020-07-28-pretrained"
# sig -> body
export SUBSET="test"

export CUDA_VISIBLE_DEVICES=0,1,2
fairseq-generate $DIR \
    --path $SAVEDIR/checkpoint_best.pt \
    --gen-subset $SUBSET \
    --beam 5 \
    --max-tokens 1100 \
    --results-path $SAVEDIR/generated \
    --num-workers 2 \
    --skip-invalid-size-inputs-valid-test \
    --empty-cache-freq 1 \



