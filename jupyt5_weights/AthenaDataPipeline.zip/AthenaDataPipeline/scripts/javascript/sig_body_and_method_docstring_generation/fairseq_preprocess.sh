export DATADIR="/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/fairseq/sig_body_method_and_method_docstring_generation"
export PREFIX="javascript-context-2020-07-22-0605"
export DICTDIR="/home/miroge/storage/universal_tokenizer/roberta_aug_spaces_dict.txt"

fairseq-preprocess \
    --source-lang 'source' \
    --target-lang 'target' \
    --trainpref $DATADIR/$PREFIX.train \
    --validpref $DATADIR/$PREFIX.val \
    --testpref $DATADIR/$PREFIX.test \
    --destdir $DATADIR/binary \
    --workers 24 \
    --srcdict $DICTDIR \
    --tgtdict $DICTDIR \