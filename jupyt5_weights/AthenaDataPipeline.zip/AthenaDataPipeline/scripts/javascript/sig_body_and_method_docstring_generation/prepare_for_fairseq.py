from athenadatapipeline.splitdatatemp import split_serialize_data_w_schema
from athenadatapipeline.model.utils import prepare
from athenadatapipeline.model.utils.javascript.collater import JavaScriptSignatureBodyandMethodDocstring

c = JavaScriptSignatureBodyandMethodDocstring()
split_serialize_data_w_schema("/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/javascript-context-2020-07-22-0605.json.lz4", c)
prepare("/home/miroge/storage/Projects/source_parser_folder/data/all-javascript-context/javascript-context-2020-07-22-0605.json.lz4", c, "/home/miroge/storage/universal_tokenizer/roberta_aug_spaces")