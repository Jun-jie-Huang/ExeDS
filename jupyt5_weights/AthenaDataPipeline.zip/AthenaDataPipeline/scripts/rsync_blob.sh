rsync -r --verbose /tufanodata/jotimc/gpt2experiment_sync /home/jotimc/mycontainer/jotimc/gpt2experiment/.
#--dry-run 