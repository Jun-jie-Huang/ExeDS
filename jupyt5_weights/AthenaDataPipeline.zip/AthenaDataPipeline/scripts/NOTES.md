* script does not work when loading previous checkpoint. It gets an error
  when resizing the embedding to the tokenizer size, saying the model object
  does not have such a method...
* I fixed the issue with n_gpu = 1 for distributed models, testing successfully.
* I still cannot load checkpoint weights. I tried not importing the optimizer state,
  I tried turning off the advancing to the state of the checkpoint, and I tried using
  the default config file. I also tried using the checkpoint config file without loading the weights,
  and that worked fine. There really appears to be a problem loading checkpoints....
