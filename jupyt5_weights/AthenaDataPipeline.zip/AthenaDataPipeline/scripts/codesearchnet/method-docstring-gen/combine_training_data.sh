#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh myconf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value source.prefix`
TOKENIZED_DIR=`cat $CONF | shyaml get-value source.save_subdir`
LANGS=(`cat $CONF | shyaml get-values source.langs`)
TASKS=(`cat $CONF | shyaml get-values source.tasks`)
SUBSETS=(`cat $CONF | shyaml get-values source.subsets`)

COMBINED_PREFIX="$ROOT/$TOKENIZED_DIR/combined-langs/csn"
mkdir -p $ROOT/$TOKENIZED_DIR/combined-langs

for LANG in "${LANGS[@]}"
do
    for SUBSET in "${SUBSETS[@]}"
    do
        PREFIX="$ROOT/$TOKENIZED_DIR/$LANG/$LANG-csn.$SUBSET"
        echo "PREFIX=$PREFIX"
        cat "${PREFIX}_${TASKS[0]}.src" "${PREFIX}_${TASKS[1]}.src" >> "${COMBINED_PREFIX}.$SUBSET.src"
        cat "${PREFIX}_${TASKS[0]}.tgt" "${PREFIX}_${TASKS[1]}.tgt" >> "${COMBINED_PREFIX}.$SUBSET.tgt"
    done
done

