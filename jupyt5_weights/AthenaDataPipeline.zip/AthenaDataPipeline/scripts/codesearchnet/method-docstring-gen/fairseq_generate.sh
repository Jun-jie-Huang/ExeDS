#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

MODEL_DIR=`cat $CONF | shyaml get-value train.model_dir`
CHECKPOINT_DIR_NAME=`cat $CONF | shyaml get-value train.checkpoint_dir_name`
CHECKPOINT_NAME=`cat $CONF | shyaml get-value generate.checkpoint_name`
CHECKPOINT_PATH="$MODEL_DIR/$CHECKPOINT_DIR_NAME/$CHECKPOINT_NAME"

echo "CHECKPOINT=$CHECKPOINT_PATH"

PREFIX=`cat $CONF | shyaml get-value source.prefix`
SAVE_SUBDIR=`cat $CONF | shyaml get-value source.save_subdir`
PREFIX=$PREFIX/$SAVE_SUBDIR
DIR=$PREFIX/combined-langs/binary
echo DIR=$DIR

#N_SHARDS=`cat $CONF | shyaml get-value generate.n_shards`
N_SHARDS=`nvidia-smi --query-gpu=name --format=csv,noheader | wc -l`
BATCH_SIZE=`cat $CONF | shyaml get-value generate.batch_size`
BEAM=`cat $CONF | shyaml get-value generate.beam`
SUBSET=`cat $CONF | shyaml get-value generate.subset`
RESULTS_PREFIX=$MODEL_DIR/$CHECKPOINT_DIR_NAME/generated-$SUBSET

echo SUBSET=$SUBSET
echo N_SHARD=$N_SHARDS
echo BATCH_SIZE=$BATCH_SIZE
echo BEAM=$BEAM

for ((SHARD = 0 ; SHARD < N_SHARDS ; SHARD++)); do

    export CUDA_VISIBLE_DEVICES=$SHARD
    echo "Starting shard $SHARD"
    fairseq-generate $DIR \
      --path $CHECKPOINT_PATH \
      --gen-subset $SUBSET \
      --batch-size $BATCH_SIZE \
      --beam $BEAM --nbest $BEAM \
      --sampling \
      --results-path "$RESULTS_PREFIX/shard-$SHARD" \
      --num-workers 4 \
      --skip-invalid-size-inputs-valid-test \
      --num-shards $N_SHARDS \
      --shard-id $SHARD \
      & \

done

wait
cat $RESULTS_PREFIX/shard-*/generate-$SUBSET.txt > $RESULTS_PREFIX/generate-$SUBSET.txt
