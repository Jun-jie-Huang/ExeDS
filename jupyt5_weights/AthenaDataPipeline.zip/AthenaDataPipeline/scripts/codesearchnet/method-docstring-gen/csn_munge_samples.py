import re
import os
import json
import gzip
import argparse
import logging
from pathlib import Path
from tqdm import tqdm
from contextlib import ExitStack

import ray
from tree_sitter import Parser

from athenacommon.tree_sitter import get_language, LanguageId
from source_parser.utils import whitespace_tokenize
from source_parser.parsers.language_parser import traverse_type

from athenadatapipeline.fairseq import iter_parse_generation
from athenadatapipeline.config import load_conf


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)

DOCSTRING_REGEX_TOKENIZER = re.compile(r"[^\s,'\"`.():\[\]=*;>{\}+-/\\]+|\\+|\.+|\(\)|{\}|\[\]|\(+|\)+|:+|\[+|\]+|{+|\}+|=+|\*+|;+|>+|\++|-+|/+")

def tokenize_docstring(docstring):
    return [t for t in DOCSTRING_REGEX_TOKENIZER.findall(docstring) if t is not None and len(t) > 0]

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())


def code_tokenize(tree, blob):
    """
    Tokenize the source file_contents represented by node
    and include whitespace to the right of each token

    Parameters
    ----------
    tree: tree_sitter.Tree
    blob: str

    Returns
    -------
    tokens, types: List, List
        a list of token strings and a list of corresponding
        token tree_sitter types
    """
    file_bytes = blob.encode('utf-8')
    node = tree.root_node
    compound_lits = ("concatenated_string, string_array", "chained_string")

    n_bytes = len(file_bytes)
    tokens = []
    nodes = node.children
    while nodes:
        nxt = nodes.pop(0)
        if not nxt.children or (
            "string" in str(nxt.type)
            and str(nxt.type) not in compound_lits
            or "char" in str(nxt.type)
        ):
            tokens.append(file_bytes[nxt.start_byte:nxt.end_byte].decode("utf-8"))
        nodes = nxt.children + nodes
    return tokens


@ray.remote
class ProcessSample:
    def __init__(self, conf, lang, sample_idx):
        self.lang = lang
        self.parser = Parser()
        self.parser.set_language(get_language(LanguageId(lang)))
        self.dir = (
                Path(conf['source']['prefix']) /
                lang /
                conf['sampled_data']['lang_subdir'] /
                f'sample-{sample_idx}' /
                'train'
        )
        if not self.dir.exists():
            self.dir.mkdir(parents=True)
        self.max_file_count = conf['sampled_data']['max_file_count']
        self.stack = ExitStack()
        self.file_count = -1
        self._rollover()

    def close(self):
        if hasattr(self, 'stream'):
            self.stream.close()

    def _rollover(self):
        self.file_count += 1
        self.filename = self.dir / f'{self.lang}_train_{self.file_count}.jsonl.gz'
        print(f"Opening {self.filename}")
        if hasattr(self, 'stream'):
            self.stream.close()
        self.stream = self.stack.enter_context(gzip.open(self.filename, 'wb'))
        self.count = 0

    def write_schema(self, code, docstring):
        tree = self.parser.parse(code.encode('utf-8'))
        identifiers = []
        traverse_type(tree.root_node, identifiers, {'identifier'})  # NOTE: may not work for all langs
        if identifiers:
            func_name_id = identifiers[0]
            func_name = code.encode('utf-8')[func_name_id.start_byte:func_name_id.end_byte].decode('utf-8')
        else:
            func_name = ''
        schema = {
                'repo': 'SYNTHETIC/FAKE',
                'path': '/not/real',
                'func_name': func_name,
                'original_string': '',
                'language': self.lang,
                'code': code,
                'code_tokens': code_tokenize(tree, code),
                'docstring': docstring,
                'docstring_tokens': tokenize_docstring(docstring),
                'sha': '',
                'partition': 'train',
                'url': '',
        }
        self.stream.write((json.dumps(schema) + '\n').encode('utf-8'))
        self.count += 1
        if self.count == self.max_file_count:
            self._rollover()


def process_sample(src, hyp):
    src_lines = src.splitlines()
    imperative = src_lines[0].split()
    target, lang = imperative[2], imperative[3]
    src = '\n'.join(src_lines[1:])
    if target == 'sig+body':
        return hyp, src, lang  # code, docstring, language
    else:
        return src, hyp, lang


if __name__ == "__main__":
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "csn-conf.yaml"
    )
    conf = load_conf(path_to_conf)

    generate_file = Path(conf['generate'].get('tmp_dir', (
            Path(conf['train']['model_dir']) /
            conf['train']['checkpoint_dir_name'] /
            f"generated-{conf['generate']['subset']}"
            )
    )) / f"generate-{conf['generate']['subset']}.txt"

    hyp_iter = iter_parse_generation(generate_file)

    ray.init()
    actor_pool = {lang: [] for lang in conf['source']['langs']}
    for lang in conf['source']['langs']:
        for i in range(conf['generate']['beam']):
            actor_pool[lang].append(ProcessSample.remote(conf, lang, i))

    for sample_set in tqdm(hyp_iter, total=3_573_598):
        for i, hyp in enumerate(sample_set['hyp']):
            code, docstring, lang = process_sample(sample_set['src'], hyp)
            if lang in conf['source']['langs']:
                actor_pool[lang][i].write_schema.remote(code, docstring)

    # close streams
    for lang in conf['source']['langs']:
        for i in range(conf['generate']['beam']):
            actor_pool[lang][i].close.remote()
