#!/bin/bash
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh conf.yaml"
    exit 1
else
    export CONF=$1
fi

PREFIX=`cat $CONF | shyaml get-value source.prefix`
SUBDIR=`cat $CONF | shyaml get-value sampled_data.lang_subdir`
REPAIR_SUBDIR=`cat $CONF | shyaml get-value sampled_data.repair_subdir`
LANGS=(`cat $CONF | shyaml get-values source.langs`)
BEAM=`cat $CONF | shyaml get-value generate.beam `

for LANG in "${LANGS[@]}"; do
    DIR=$PREFIX/$LANG/$SUBDIR
    NEWDIR=$PREFIX/$LANG/$REPAIR_SUBDIR
    for ((i = 0 ; i < $BEAM ; i++)); do
        SAMPLE_DIR=$DIR/sample-$i/train
        NEW_SAMPLE_DIR=$NEWDIR/sample-$i/train
        mkdir -p $NEW_SAMPLE_DIR
        for ZFILE in $SAMPLE_DIR/*; do
            zcat $ZFILE | gzip > $NEW_SAMPLE_DIR/${ZFILE##*/}
        done
    done
done
