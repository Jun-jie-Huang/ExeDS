#!/bin/bash
#TODO: generalize to allow preprocessing individual subsets
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh myconf.yaml"
    exit 1
else
    export CONF=$1
fi


MODEL_DIR=`cat $CONF | shyaml get-value train.model_dir`
CHECKPOINT_DIR_NAME=`cat $CONF | shyaml get-value train.checkpoint_dir_name`
SAVEDIR=$MODEL_DIR/$CHECKPOINT_DIR_NAME
TBOARD_LOGDIR=$SAVEDIR/`cat $CONF | shyaml get-value train.logdir_name`
FINETUNE_FROM=`cat $CONF | shyaml get-value train.finetune_from_model`

TOTAL_NUM_UPDATES=`cat $CONF | shyaml get-value train.total_num_updates`
WARMUP_UPDATES=`cat $CONF | shyaml get-value train.warmup_steps`
LR=`cat $CONF | shyaml get-value train.lr`

# effectively sets batch_size
MAX_TOKENS=`cat $CONF | shyaml get-value train.max_tokens`
UPDATE_FREQ=`cat $CONF | shyaml get-value train.update_freq`

PREFIX=`cat $CONF | shyaml get-value source.prefix`
SAVE_SUBDIR=`cat $CONF | shyaml get-value source.save_subdir`
PREFIX=$PREFIX/$SAVE_SUBDIR
LANGS=(`cat $CONF | shyaml get-values source.langs`)

echo PREFIX=$PREFIX
#for LANG in "${LANGS[@]}"
#do
#    if [[ -z "$DIR" ]]; then
#        DIR=$PREFIX/$LANG/binary
#    else
#        DIR=${DIR}:$PREFIX/$LANG/binary
#    fi
#done
DIR=$PREFIX/combined-langs/binary

echo DIR=$DIR
echo FINETUNE_FROM=$FINETUNE_FROM
echo SAVEDIR=$SAVEDIR

# leave one gpu for eval
#export CUDA_VISIBLE_DEVICES="1,2,3,4,5,6,7,8,9,10,11,12,13,14,15"
fairseq-train $DIR \
    --arch bart_large \
    --finetune-from-model $FINETUNE_FROM \
    --save-dir $SAVEDIR \
    --tensorboard-logdir $TBOARD_LOGDIR \
    --max-tokens $MAX_TOKENS \
    --task translation \
    --criterion cross_entropy \
    --share-all-embeddings \
    --share-decoder-input-output-embed \
    --dropout 0.1 --relu-dropout 0.1 --attention-dropout 0.1 \
    --weight-decay 0.001 --optimizer adam \
    --clip-norm 1. \
    --lr-scheduler inverse_sqrt --lr $LR --warmup-updates $WARMUP_UPDATES \
    --update-freq $UPDATE_FREQ \
    --skip-invalid-size-inputs-valid-test \
    --adam-betas '(0.9,0.98)' --adam-eps 1e-6 \
    --no-epoch-checkpoints \
    --valid-subset valid \
    --fp16 --fp16-scale-window 256 --fp16-init-scale 2 \
    --ddp-backend=no_c10d \
    #--reset-optimizer \
    #--reset-lr-scheduler \
    #--save-interval 1 \
    #--fp16-scale-window 128 \
    #--criterion label_smoothed_cross_entropy \
    #--label-smoothing 0.1 \
