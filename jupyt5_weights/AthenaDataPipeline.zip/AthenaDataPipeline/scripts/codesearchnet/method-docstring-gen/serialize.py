import os
import argparse
import logging
from pathlib import Path
from contextlib import ExitStack

import tokenizers

from athenadatapipeline import load_zip_json
from athenadatapipeline.config import load_conf


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--conf_path",
        required=True,
        type=str,
        help="Path to configuration file conf.yaml",
    )

    return vars(parser.parse_args())


if __name__ == "__main__":
    path_to_conf = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "csn-conf.yaml"
    )
    conf = load_conf(path_to_conf)

    tok_prefix = conf['vocab']['bpe_prefix']
    tokenizer = tokenizers.ByteLevelBPETokenizer(
            tok_prefix + "-vocab.json", tok_prefix + "-merges.txt"
    )

    prefix = Path(conf['source']['prefix'])
    langs = conf['source']['langs']
    subdir = conf['source']['subdir']
    subsets = conf['source']['subsets']

    save_subdir = prefix / conf['source']['save_subdir']

    for lang in langs:
        for s in subsets:

            savestreams = {}
            with ExitStack() as stack:
                langdir = save_subdir / lang
                if not langdir.exists():
                    langdir.mkdir(parents=True)

                savestreams['method_gen_save_src'] = stack.enter_context(open(langdir / f'{lang}-csn.{s}_doc_to_sig+body.src', 'w'))
                savestreams['method_gen_save_tgt'] = stack.enter_context(open(langdir / f'{lang}-csn.{s}_doc_to_sig+body.tgt', 'w'))
                savestreams['docstring_gen_save_src'] = stack.enter_context(open(langdir / f'{lang}-csn.{s}_sig+body_to_doc.src', 'w'))
                savestreams['docstring_gen_save_tgt'] = stack.enter_context(open(langdir / f'{lang}-csn.{s}_sig+body_to_doc.tgt', 'w'))

                for dat_path in (prefix / lang / subdir/ s).iterdir():
                    LOGGER.info(f'Processing {dat_path}')
                    docstrings = []
                    methods = []
                    for func_dict in load_zip_json(dat_path):
                        docstrings.append(func_dict['docstring'])
                        methods.append(func_dict['code'])

                    # method gen
                    encode_src = tokenizer.encode_batch([f'# target sig+body {lang}\n' + s for s in docstrings])
                    for s in encode_src:
                        savestreams['method_gen_save_src'].write(' '.join(s.tokens) + '\n')
                    encode_tgt = tokenizer.encode_batch(methods)
                    for t in encode_tgt:
                        savestreams['method_gen_save_tgt'].write(' '.join(t.tokens) + '\n')

                    # docstring gen
                    encode_src = tokenizer.encode_batch([f'# target doc {lang}\n' + s for s in methods])
                    for s in encode_src:
                        savestreams['docstring_gen_save_src'].write(' '.join(s.tokens) + '\n')
                    encode_tgt = tokenizer.encode_batch(docstrings)
                    for t in encode_tgt:
                        savestreams['docstring_gen_save_tgt'].write(' '.join(t.tokens) + '\n')

