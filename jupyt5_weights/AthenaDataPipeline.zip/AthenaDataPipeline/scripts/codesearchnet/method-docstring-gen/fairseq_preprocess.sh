#!/bin/bash
#TODO: generalize to allow preprocessing individual subsets
if [[ $# -eq 0 ]]; then
    echo "provide yaml configuration file, e.g. fairseq_train.sh myconf.yaml"
    exit 1
else
    export CONF=$1
fi

ROOT=`cat $CONF | shyaml get-value source.prefix`
echo "ROOT=$ROOT"
TOKENIZED_DIR=`cat $CONF | shyaml get-value source.save_subdir`
echo "TOKENIZED_DIR=$TOKENIZED_DIR"

SRC_DICT=`cat $CONF | shyaml get-value vocab.fairseq_src_dict`
echo "SRC_DICT=$SRC_DICT"
TGT_DICT=`cat $CONF | shyaml get-value vocab.fairseq_tgt_dict 2>/dev/null`
if [[ $? -eq 0 ]]; then
    TGT_DICT="--tgtdict $TGT_DICT"
else
    TGT_DICT="--joined-dictionary"
fi
echo "TGT_DICT=$TGT_DICT"

LANGS=(`cat $CONF | shyaml get-values source.langs`)
echo "LANGS=${LANGS[@]}"
TASKS=(`cat $CONF | shyaml get-values source.tasks`)
echo "TASKS=${TASKS[@]}"

# this preprocesses all the individual languages/tasks/subsets for evaluation
#for LANG in "${LANGS[@]}"
#do
#    DATADIR=$ROOT/$TOKENIZED_DIR/$LANG
#    echo "DATADIR=$DATADIR"
#
#    TRAINPREF="$DATADIR/$LANG-csn.train"
#    TESTPREF="$DATADIR/$LANG-csn.test"
#    VALIDPREF="$DATADIR/$LANG-csn.valid"
#
#    fairseq-preprocess \
#        -s "src" -t "tgt" \
#        --srcdict $SRC_DICT \
#        $TGT_DICT \
#        --testpref "${TESTPREF}_${TASKS[0]},${TESTPREF}_${TASKS[1]}" \
#        --destdir $DATADIR/binary \
#        --workers 24 \
#        --trainpref "$TRAINPREF" \
#        --validpref "${VALIDPREF}_${TASKS[0]},${VALIDPREF}_${TASKS[1]}" \
#
#done

# this preprocesses the aggregate files for training
DATADIR=$ROOT/$TOKENIZED_DIR/combined-langs
fairseq-preprocess \
    -s "src" -t "tgt" \
    --srcdict $SRC_DICT \
    $TGT_DICT \
    --testpref "$DATADIR/csn.test" \
    --destdir $DATADIR/binary \
    --workers 24 \
    --trainpref "$DATADIR/csn.train" \
    --validpref "$DATADIR/csn.valid" \

