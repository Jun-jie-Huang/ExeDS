from sys import argv
import rouge

from athenadatapipeline import load_zip_json

def get_rouge(test_dat_predictions):
    reflist, hyplist = [], []
    for d in load_zip_json(test_dat_predictions):
        reflist.append(d[2].replace('\n', ' '))
        h = '):\n'.join(d[1].split('):\n')[1:])
        hyplist.append(h.replace('\n', ' '))
    return rouge.Rouge().get_scores('\n'.join(hyplist), '\n'.join(reflist))

if __name__ == '__main__':
    print(f'Calculating ROUGE scores for {argv[1]}')
    print(get_rouge(argv[1]))
