OPENAI_CODEGEN_EXAMPLES = {}

OPENAI_CODEGEN_EXAMPLES['factorial'] = [
        'def factorial(x):',
        'Compute the factorial of x',
        '''if x == 0:
            return 1
        return x * factorial(x - 1)
        '''
]

OPENAI_CODEGEN_EXAMPLES['sum_to_n'] = [
        'def sum_to_n(n):',
        'Sums the numbers from 1 to n',
        'return sum(range(1, n + 1))',
]

OPENAI_CODEGEN_EXAMPLES['palindrome'] = [
        'def is_palindrome(text):',
        'Checks if given string is a palindrome',
        '''if text == text[::-1]:
            return True
        return False''',
]

OPENAI_CODEGEN_EXAMPLES['halfway'] = [
        'def halfway(a, b):',
        'What number is halfway between a and b?',
        'return a + ((b - a) / 2)'
]

OPENAI_CODEGEN_EXAMPLES['isprime'] = [
        'def is_prime(n):',
        'Return true is a given number is prime, and false otherwise',
        '''if n < 2:
            return False
        if n == 2:
            return True
        for i in range(3, int(n ** 0.5) + 1, 2):
            if n % i == 0:
                return False
        return True'''
]

OPENAI_CODEGEN_EXAMPLES['count_even_numbers'] = [
        'def count_even_numbers_in_list(x):',
        'Given a list x of numbers, count how many even numbers are in the list',
        'return sum(1 for i in x if i % 2 == 0)',
]

OPENAI_CODEGEN_EXAMPLES['return_odd'] = [
        'def return_odd_numbers_from_list(l):',
        'Given a list of integers, return only those which are odd',
        'return [i for i in l if i%2 == 1]'
]

OPENAI_CODEGEN_EXAMPLES['return_indicies_of_3'] = [
        'def return_indices_of_list_elements_that_are_3(l):',
        'Given a list of numbers, returns the indices of the list elements that are 3.',
        'return [i for i, v in enumerate(l) if v == 3]',
]

OPENAI_CODEGEN_EXAMPLES['any_large'] = [
        'def any_large_elements(numbers):',
        'Check if any elements of the list are larger than 1000',
        'return any(n > 1000 for n in numbers)',
]

OPENAI_CODEGEN_EXAMPLES['non_zero_elements_indicies'] = [
        'def non_zero_elements_indicies(numbers):',
        'Find the indicies of non-zero elements in a list',
        '''non_zero_indicies = []
        for i, number in enumerate(numbers):
            if number != 0:
                non_zero_indicies.append(i)
        return non_zero_elements_indicies'''
]

OPENAI_CODEGEN_EXAMPLES['same_chars'] = [
        'def same_chars(s0, s1):',
        '''Check if two words have the same characters
        >>> same_chars('abcd', 'dddddddabc')
        True
        >>> same_chars('ddddddddabc', 'abcd')
        True
        >>> same_chars('eabcd', 'dddddddddabc')
        False''',
        'return set(s0.lower()) == set(s1.lower())'
]
